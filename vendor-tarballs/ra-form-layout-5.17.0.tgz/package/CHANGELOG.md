# CHANGELOG

## v5.17.0

> 2025-11-12

- Fix `<AutoPersistInStore>` compatibility with `react-hook-form` version 7.65.0 and above
- Bump minimum `react-hook-form` version to 7.65.0

## v5.16.2

> 2025-09-30

- Fix `<LongForm>` might trigger infinite rerenders in `development`
- Fix `<LongFormView>` is not exported

## v5.16.1

> 2025-09-19

- Fix `<DateRangeInput>` does not let users enter a date using their keyboard

## v5.16.0

> 2025-08-01

- Use `@react-admin/ra-core-ee` for headless hooks

## v5.15.1

> 2025-08-20

- Fix peer dependencies to properly allow Material UI v7

## v5.15.0

> 2025-06-25

- Fix `<BulkUpdateFormButton>` middleware implementation does not support optimistic cases
- Fix: remove middleware workaround from `<InputSelectorForm>`
- Upgrade to `react-admin` v5.9.0

## v5.14.2

> 2025-06-18

- Fix `<InputSelectorForm>` does not properly sanitize the submitted values when used with `<BulkUpdateFormButton>`

## v5.14.1

> 2025-06-17

- Fix `<AccordionSection>` does not show its error state when its children are wrapped in other components

## v5.14.0

> 2025-06-16

- Make components compatible with Material UI v7

## v5.13.0

> 2025-05-20

- Add access control on `<CreateInDialogButton>`, `<EditInDialogButton>` and `<ShowInDialogButton>`

## v5.12.0

> 2025-05-05

- Make `<AutoPersistInStore>` save values on change (instead of on unmount).
- Make `<AutoPersistInStore>` delete stored data on the notification's "Cancel" button click

## v5.11.0

> 2025-04-10

- Introduce the `<AutoPersistInStore>` component.

## v5.10.2

> 2025-04-04

- Fix `<CreateDialog>` and `<CreateInDialogButton>` don't render their `title` inside their `CreateContext`

## v5.10.1

> 2025-03-20

- Prevent `<WizardForm>` to move too many steps forward, bypassing validation, when using an async validator.

## v5.10.0

> 2025-03-10

- Introduce the `<EditInDialogButton emptyWhenLoading>` prop.

## v5.9.0

> 2025-02-27

- Warn about unsaved changes with `<AutoSave>`
- Introduce the `<AutoSave disableWarnWhenUnsavedChanges>` prop.

## v5.8.0

> 2025-02-12

- Feat: Dialog components (`<CreateDialog>`, `<EditDialog>`, `<ShowDialog>`, `<CreateInDialogButton>`, `<EditInDialogButton>`, `<ShowInDialogButton>`) now support hiding the title with `title={null}`

## v5.7.0

> 2025-02-03

- Feat: Introduce `<WarnWhenUnsavedChangesInDialog>`

## v5.6.1

> 2025-01-31

- Make `cardinality` prop in `LongFormSectionMenuItemProps` optional  
- Make `WizardFormContext.steps` an array of `ReactElement<WizardFormStepProps>`  

## v5.6.0

> 2025-01-29

- Support React 19 and MUI v6
- Update `react-admin` dependency
- Update `@mui/x-date-pickers` dependencies
- Update `@mui/x-date-pickers-pro` peer dependency

## v5.5.2

> 2025-01-22

- Revert fix `<AutoSave>` should not trigger a save after the form is unmounted

## v5.5.1

> 2025-01-06

- Fix dialogs forms should allow to override their `resource`.

## v5.5.0

> 2025-01-02

- Support `onClick` in the `ButtonsProp`'s prop of `<EditInDialogButton>`, `<CreateInDialogButton>`, `<ShowInDialogButton>`.

## v5.4.2

> 2024-12-20

- Fix `<AutoSave>` should not trigger a save after the form is unmounted 
- Fix `<AutoSave>` should not trigger a save if the form is set back to its pristine state

## v5.4.1

> 2024-12-12

- Fix `<CreateDialog>` refreshes list twice on success 

## v5.4.0

> 2024-12-09

- Add support for access control to `<AccordionForm>`, `<AccordionForm.Panel>` and `<AccordionSection>`
- Add support for access control to `<LongForm>` and `<LongForm.Section>`
- Add support for access control to `<WizardForm>` and `<WizardForm.Step>`

## v5.3.0

> 2024-10-24

- Introduce the `defaultValue` option to `<StackedFilters>` filters.
- Introduce the `defaultValue` option to `<StackedFilters>` operators filters.
- Fix `<StackedFilters>` does not reset the filter value when the filter source is changed.

## v5.2.1

> 2024-10-10

- Fix: `<WizardForm>`'s `<NextButton>` should be enabled even when the form is pristine
- Fix: Remove unusable props `<PreviousButton alwaysEnable>` and `<NextButton alwaysEnable>`

## v5.2.0

> 2024-10-07

- Introduce the `type` option to `<StackedFilters>` operators.
- Fix `<StackedFilters>` may send wrong values to the filters when switching from an operator that accepts single values to one that accepts multiple values.

## v5.1.1

> 2024-09-23

- Separate `<DateRangeInput>` exports to avoid strong dependency on `@mui/x-date-pickers-pro`

```diff
-import { DateRangeInput } from '@react-admin/ra-form-layout';
+import { DateRangeInput } from '@react-admin/ra-form-layout/DateRangeInput';
import { Edit, SimpleForm } from 'react-admin';

export const EventEdit = () => (
    <Edit>
        <SimpleForm>
            <DateRangeInput source="subscription_period" />
        </SimpleForm>
    </Edit>
);
```

## v5.1.0

> 2024-09-06

- Introduce the `<DateRangeInput>` component, a wrapper of the [MUI DateRangePicker](https://mui.com/x/react-date-pickers/date-range-picker/)

## v5.0.1

> 2024-07-25

- Fix `onClick` event propagation to the parent in `<EditDialog>` and `<ShowDialog>` components (e.g. row click in a list)

## v5.0.0

> 2024-07-25

- Upgrade to react-admin v5
- Upgrade to `@mui/x-date-pickers` v7
- Upgrade to `date-fns` v3
- WizardForm: `<NextButton>` won't be disabled anymore if the current step inputs are invalid, and it will be disabled when the form is pristine. This makes its behavior more consistent with `<SaveButton>`.
- `<AccordionSection>` is now `fullWidth` by default
- Remove deprecated `record` prop injection to `FormDialogTitle` (use `useRecordContext` instead)
- Added ability to use `record` fields in `FormDialogTitle` using i18n [interpolation](https://marmelab.com/react-admin/TranslationTranslating.html#interpolation-pluralization-and-default-translation)
- [TypeScript]: `useWizardFormContext` now returns a `Partial<WizardFormContextValue>`
- [TypeScript]: `useFormDialogContext` now returns a `Partial<FormDialogContextType>`
- [TypeScript]: Enable strictNullChecks

## v4.12.3

> 2024-05-07

-   Fix `<InputSelector>` label should be hidden in `<InputSelectorForm>`

## v4.12.2

> 2024-02-27

-   Fix badly positioned label in `<WizardForm>` outlined `<TextField>`

## v4.12.1

> 2024-02-26

-   Fix the `<LongForm>` `RaLongForm` root class is not exposed

## v4.12.0

> 2024-02-08

-   Accept a React element for `<AccordionFormPanel label>`, `<AccordionFormPanel secondary>`, `<AccordionSection label>`, `<AccordionSection secondary>`
-   Accept an `id` prop for `AccordionFormPanel` and `AccordionSection` components

## v4.11.2

> 2024-02-07

-   Add support for `<AccordionFrom sx>` and `<AccordionFromPanel sx>` props.

## v4.11.1

> 2024-01-29

-   Fix `EditDialog` passes the `queryOptions` prop to the MaterialUI `Dialog` component.

## v4.11.0

> 2024-01-15

-   Introduce `<DateInput>`, `<DateTimeInput>` and `<TimeInput>`, date/time picker components based on MUI X.

## v4.10.4

> 2023-12-12

-   Add `<AccordionFormPanel count>` and `<AccordionSection count>` to allow customizing the count displayed in the accordion summary

## v4.10.3

> 2023-12-01

-   Fix `<BulkUpdateFormButton>` does not disable the save button while saving

## v4.10.2

> 2023-10-27

-   Fix `lodash` import to avoid bundling the entire library

## v4.10.1

> 2023-10-09

-   Update documentation to explain how to use `<StackedFilters>` well.

## v4.10.0

> 2023-10-05

-   Add support for `className` and `sx` props to `<StackedFilters>`, `<StackedFiltersForm>` and `<StackedFiltersActions>` components.

## v4.9.7

> 2023-10-03

-   Fix `<InputSelectorForm>` briefly displays a validation error notification after submitting the form with React 18

## v4.9.6

> 2023-10-03

-   Fix `<InputSelectorForm>` briefly displays a validation error after submitting the form
-   Fix `<BulkUpdateFormButton>` does not close the dialog when providing a custom `onSuccess` callback

## v4.9.5

> 2023-10-02

-   Fix redirection in custom `onSuccess` is ignored by `<CreateDialog>` and `<EditDialog>`

## v4.9.4

> 2023-09-05

-   Fix passing custom onSuccess does not close the dialog

## v4.9.3

> 2023-08-30

-   Fix Dialogs don't pass MUI onClose arguments to their `close` handler

## v4.9.2

> 2023-08-10

-   Fix `<EditInDialogButton>` causes console warning when using the `transform` prop

## v4.9.1

> 2023-08-03

-   Fix `<WizardForm/>` makes it hard to override the progress margins.

## v4.9.0

> 2023-07-06

-   Introduce `<BulkUpdateButton>`
-   Introduce `<InputSelectorForm>`

## v4.8.3

> 2023-06-19

-   Fix `<WizardForm>` to support middlewares.

## v4.8.2

> 2023-06-16

-   Fix exports that are problematic with some bundlers

## v4.8.1

> 2023-06-14

-   Fix `<StackedFilters>` uses an incorrect translation key for the Filters button label (`ra-form-layout.stacked_filters.filters_button_label` is now `ra-form-layout.filters.filters_button_label`)
-   Fix labels in the `<StackedFiltersForm>` now have a hard-coded label supporting translations:
    -   `ra-form-layout.filters.source`
    -   `ra-form-layout.filters.operator`
    -   `ra-form-layout.filters.value`

## v4.8.0

> 2023-05-05

-   Add `<AutoSave>` component to automatically save a form when the user stops typing.
-   Add `useAutoSave` hook
-   Add `<PreviousButton>` for customizing the `<WizardForm>` toolbar.
-   Add `<WizardForm.Step>` shortcut to `<WizardFormStep>`
-   Add `<AccordionForm.Panel>` shortcut to `<AccordionFormPanel>`

This version requires react-admin version 4.11.0 or higher.

## v4.7.1

> 2023-05-30

-   Fix compatibility with latest react-hook-form versions (>= 7.43), and hence with react-admin >= v4.11

## v4.7.0

> 2023-05-24

-   Upgraded to react-admin `4.10.6`

## v4.6.2

> 2023-03-17

-   Fix usage of `cloneElement` by ensuring children are React elements.

## v4.6.1

> 2023-03-02

-   Fix `<EditDialog>` ignores `redirect` prop when passing custom `mutationOptions`
-   Fix MUI warning when passing `mutationMode` to `<EditDialog>`

## v4.6.0

> 2023-02-01

-   Added the `<StackedFilters>` component.

## v4.5.3

> 2023-01-25

-   Fix React warnings about unknown or invalid props

## v4.5.2

> 2022-10-28

-   (fix) Fix `WizardForm` next button `disabled` status
-   (doc) Fix `WizardForm` custom toolbar example

## v4.5.1

> 2022-10-24

-   (fix) Add missing exports for `CreateInDialogButton`, `EditInDialogButton` and `ShowInDialogButton`

## v4.5.0

> 2022-10-12

-   Feat: Add ability to use `CreateDialog`, `EditDialog` and `ShowDialog` standalone, without routing

## v4.4.0

> 2022-08-29

-   Feat: Provide record in context for their title to `EditDialog` & `ShowDialog`

## v4.3.0

> 2022-08-25

-   Remove `<JsonSchemaForm>` component. (new location in `ra-json-schema-form`)

## v4.2.0

> 2022-07-29

-   Add `<JsonSchemaForm>` component.

## v4.1.5

> 2022-07-21

-   Fix `redirect` prop is ignored by `<CreateDialog>` and `<EditDialog>`

## v4.1.4

> 2022-07-01

-   Fix `<AccordionSection>` style (summary height, bottom border, etc.)

## v4.1.3

> 2022-06-29

-   Fix: Replace `classnames` with `clsx`

## v4.1.2

> 2022-06-21

-   Fix `<EditDialog>` not calling `dataProvider.update` when `mutationMode` is undefined
-   Fix Dialog Forms not working properly with `<TabbedForm>`
-   Doc: Add `hasCreate` in the Dialog Forms examples

## v4.1.1

> 2022-06-20

-   Fix Dialog Forms are not displayed when `<Admin>` has its `basename` prop set.

## v4.1.0

> 2022-06-16

-   Add `<LongForm>` component

## v4.0.3

> 2022-06-10

-   (fix) Fix `<EditDialog>` and `<CreateDialog>` scroll to top on submit and on cancel

## v4.0.2

> 2022-06-10

-   (fix) Fix `<WizardForm>` does not trigger save action

## v4.0.1

> 2022-06-08

-   (fix) Update peer dependencies ranges (support React 18)

## v4.0.0

> 2022-06-07

-   Upgrade to react-admin v4

## v1.9.0

> 2022-01-05

-   (feat) Add `<ShowDialog>` component

## v1.8.1

> 2021-12-17

-   (fix) Fix sanitize mutationMode out of WizardFormView
-   (fix) Fix change justify for justifyContent prop

## v1.8.0

> 2021-11-12

-   (feat) Add ability to pass custom `<Stepper>` props to `<WizardProgress>`

## v1.7.0

> 2021-08-03

-   (feat) Add translation key support for the `label` prop of the `<WizardFormStep>`

## v1.6.2

> 2021-07-06

-   (doc) Add an example of summary step for the `<WizardForm>`

## v1.6.1

> 2021-06-29

-   (fix) Update peer dependencies ranges (support react 17)

## v1.6.0

> 2021-05-17

-   (chore) Update `AccordionForm` to use `FormGroupContext` for error tracking.
-   (feat) Ensure `AccordionFormPanel`, `AccordionFormToolbar` and `FormDialogTitle` styles are overridable through Material UI theme by providing it a key (`RaAccordionFormPanel`, `RaAccordionFormToolbar` and `RaFormDialogTitle`).

## v1.5.5

> 2021-04-29

-   (fix) Allow additional properties on `AccordionSection` component

## v1.5.4

> 2021-01-29

-   (fix) Fix wizard form does not handle submit on enter correctly

## v1.5.3

> 2021-01-18

-   (fix) Fix dialog forms

## v1.5.2

> 2020-11-04

-   (fix) Fix dialog forms prop interfaces

## v1.5.1

> 2020-11-03

-   (fix) Fix providing sub-components (`Accordion`, `<AccordionSummary>` and `<AccordionDetails>`) should not be required.

## v1.5.0

> 2020-11-02

-   (feat) Allow customizing the accordion sub-components (`Accordion`, `<AccordionSummary>` and `<AccordionDetails>`) by providing your own.

## v1.4.0

> 2020-10-26

-   (feat) Allow customizing the accordion sub-components (`Accordion`, `<AccordionSummary>` and `<AccordionDetails>`)
-   (feat) Add types for the `<AccordionSection>`

## v1.3.0

> 2020-10-05

-   (deps) Upgrade react-admin to v3.9.0

## v1.2.0

> 2020-10-01

-   (feat) Dialog Form (CreateDialog & EditDialog)

## v1.1.0

> 2020-09-28

-   (feat) Wizard Form

## v1.0.1

> 2020-09-22

-   (fix) Fix Storybook error on `history.replace`

## v1.0.0

> 2020-09-22

-   First release
