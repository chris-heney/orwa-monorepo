import { RaFormLayoutTranslationMessages } from './RaFormLayoutTranslationMessages';

export const raFormLayoutLanguageEnglish: RaFormLayoutTranslationMessages = {
    'ra-form-layout': {
        action: {
            next: 'Next',
            previous: 'Previous',
            bulk_update: 'Update selected %{resource}',
        },
        autosave: {
            last_saved_at: 'All changes saved',
            saving: 'Saving...',
            error: 'Server error, changes are not saved: %{error}',
        },
        auto_persist_in_store: {
            applied_changes: 'Applied previous unsaved changes',
        },
        filters: {
            apply_filters: 'Apply',
            remove_all_filters: 'Remove all filters',
            filters_button_label: 'Filters',
            source: 'Source',
            operator: 'Operator',
            value: 'Value',
            operators: {
                q: 'Contains',
                eq: 'Equals',
                neq: 'Not equals',
                gt: 'Greater than',
                lt: 'Less than',
                eq_any: 'Equals any',
                neq_any: 'Not equals any',
                boolean: 'Is true',
                inc: 'Includes',
                inc_any: 'Includes any',
                ninc_any: 'Includes none',
            },
        },
        input_selector_form: {
            select_inputs: 'Select fields',
            select_values: 'Select values',
        },
    },
};
