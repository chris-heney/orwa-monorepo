import * as React from 'react';
import { useCallback, useMemo, useRef } from 'react';
import { useEvent } from 'react-admin';
import debounce from 'lodash/debounce';
import { DebouncedFunc } from 'lodash';

// allow the hook to work in SSR
const useLayoutEffect =
    typeof window !== 'undefined' ? React.useLayoutEffect : React.useEffect;

/**
 * Hook somewhat equivalent to useEvent, but with a debounce
 * Returns a debounced callback which will not change across re-renders unless the
 * callback or delay changes
 * @see https://reactjs.org/docs/hooks-faq.html#how-to-read-an-often-changing-value-from-usecallback
 * @see https://github.com/facebook/react/issues/14099#issuecomment-440013892
 */
export const useDebouncedEvent = <Args extends unknown[], Return>(
    callback: (...args: Args) => Return,
    delay: number
): [
    (...args: Args) => Return | undefined,
    { cancel: () => void; flush: () => void },
] => {
    // Create a ref that stores the debounced callback
    const debouncedCallbackRef = useRef<(...args: Args) => Return | undefined>(
        () => {
            throw new Error('Cannot call an event handler while rendering.');
        }
    );

    // Keep a stable ref to the callback (in case it's an inline function for instance)
    const stableCallback = useEvent(callback);

    // Whenever callback or delay changes, we need to update the debounced callback
    useLayoutEffect(() => {
        debouncedCallbackRef.current = debounce(stableCallback, delay);
    }, [stableCallback, delay]);

    const cancel = useCallback(() => {
        if (debouncedCallbackRef.current) {
            (debouncedCallbackRef.current as DebouncedFunc<any>).cancel();
        }
    }, []);
    const flush = useCallback(() => {
        if (debouncedCallbackRef.current) {
            (debouncedCallbackRef.current as DebouncedFunc<any>).flush();
        }
    }, []);

    const debouncedCallback = useCallback(
        (...args: Args) => debouncedCallbackRef.current(...args),
        []
    );

    return useMemo(
        () => [
            debouncedCallback,
            {
                cancel,
                flush,
            },
        ],
        [cancel, debouncedCallback, flush]
    );
};
