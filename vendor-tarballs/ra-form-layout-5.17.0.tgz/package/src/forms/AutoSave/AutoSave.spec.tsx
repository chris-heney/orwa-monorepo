import * as React from 'react';
import { DataProvider, HttpError, testDataProvider } from 'react-admin';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import expect from 'expect';
import {
    InSimpleForm as InSimpleFormOptimistic,
    FullApp as FullAppOptimistic,
} from '../../../stories/AutoSave.optimistic.stories';
import {
    InSimpleForm as InSimpleFormPessimistic,
    FullApp as FullAppPessimistic,
} from '../../../stories/AutoSave.pessimistic.stories';

window.confirm = jest.fn();
const wait = (time: number) =>
    new Promise(resolve => setTimeout(resolve, time));

const getDataProvider = (dataProvider?: Partial<DataProvider>) => {
    return testDataProvider({
        // @ts-ignore
        getOne: jest.fn((resource, params) =>
            Promise.resolve({
                data:
                    params.id == 1
                        ? {
                              id: 1,
                              first_name: 'John',
                              last_name: 'Doe',
                              dob: new Date('1966-09-05'),
                              sex: 'male',
                              employer_id: 2,
                          }
                        : {
                              id: 2,
                              first_name: 'Jane',
                              last_name: 'Doe',
                              dob: new Date('1966-09-05'),
                              sex: 'female',
                              employer_id: 2,
                          },
            })
        ),
        // @ts-ignore
        getList: jest.fn(() =>
            Promise.resolve({
                data: [
                    {
                        id: 1,
                        first_name: 'John',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                    {
                        id: 2,
                        first_name: 'Jane',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'female',
                        employer_id: 2,
                    },
                ],
                total: 2,
            })
        ),
        // @ts-ignore
        update: jest.fn(() => Promise.resolve({ data: { id: 1 } })),
        // @ts-ignore
        getMany: jest.fn(() => Promise.resolve({ data: [] })),
        ...dataProvider,
    });
};

describe('AutoSave', () => {
    describe('optimistic', () => {
        it('should autosave at the specified interval if the form is dirty and valid', async () => {
            const dataProvider = getDataProvider();
            render(
                <InSimpleFormOptimistic
                    dataProvider={dataProvider}
                    debounce={50}
                    confirmationDuration={50}
                />
            );

            await wait(300);
            // Not called because the form is not dirty
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: '' },
            });

            await wait(300);
            // Not called because the form is not valid
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'Hello' },
            });

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
        });

        it('should autosave only once per change', async () => {
            const dataProvider = getDataProvider();
            render(
                <InSimpleFormOptimistic
                    dataProvider={dataProvider}
                    debounce={50}
                    confirmationDuration={50}
                />
            );

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'Hello' },
            });

            await waitFor(() => {
                expect(dataProvider.update).toHaveBeenCalledWith(
                    'customers',
                    expect.objectContaining({
                        data: {
                            id: 1,
                            first_name: 'Hello',
                            last_name: 'Doe',
                            dob: new Date('1966-09-05'),
                            sex: 'male',
                            employer_id: 2,
                        },
                    })
                );
            });
            expect(dataProvider.update).toHaveBeenCalledTimes(1);

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledTimes(1);
        });

        it('should display an error message when the update failed and restart saving after a change', async () => {
            const dataProvider = testDataProvider({
                // @ts-ignore
                getOne: jest.fn(() =>
                    Promise.resolve({
                        data: {
                            id: 1,
                            first_name: 'John',
                            last_name: 'Doe',
                            dob: new Date('1966-09-05'),
                            sex: 'male',
                            employer_id: 2,
                        },
                    })
                ),
                // @ts-ignore
                update: jest.fn((resource, { data }) => {
                    return new Promise((resolve, reject) => {
                        setTimeout(() => {
                            if (data.first_name === 'test') {
                                return reject(
                                    new HttpError('Forbidden name', 400)
                                );
                            }
                            // @ts-ignore
                            resolve({ data: { id: 1 } });
                        }, 50);
                    });
                }),
            });
            render(
                <InSimpleFormOptimistic
                    dataProvider={dataProvider}
                    debounce={50}
                    confirmationDuration={50}
                />
            );

            await wait(300);

            const consoleError = jest
                .spyOn(console, 'error')
                .mockImplementation(() => undefined);
            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'test' },
            });

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'test',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );

            await screen.findByText(
                'Server error, changes are not saved: Forbidden name'
            );

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'Hello' },
            });

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
            // make sure the error message is not displayed anymore
            expect(
                screen.queryByText(
                    'Server error, changes are not saved: Forbidden name'
                )
            ).toBeNull();
            consoleError.mockRestore();
            // see test-setup
            restoreConsoleError();
        });

        it('should save if users leave the form', async () => {
            const dataProvider = getDataProvider();
            render(
                <FullAppOptimistic dataProvider={dataProvider} debounce={50} />
            );
            fireEvent.click(await screen.findByText('John'));
            fireEvent.change(await screen.findByDisplayValue('John'), {
                target: { value: 'Hello' },
            });
            fireEvent.click(screen.getByText('Customers'));
            // wait for more than the debounce time
            await wait(100);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
        });

        it('should save if users navigate to another record', async () => {
            const dataProvider = getDataProvider();
            render(
                <FullAppOptimistic dataProvider={dataProvider} debounce={250} />
            );
            fireEvent.click(await screen.findByText('John'));
            await screen.findByText('1 / 2');
            fireEvent.change(await screen.findByDisplayValue('John'), {
                target: { value: 'Hello' },
            });
            // Let react-hook-form update its state
            await new Promise(resolve => setTimeout(resolve, 25));
            fireEvent.click(await screen.findByLabelText('Go to next page'));
            // Ensure the next record is loaded and its firstName value is the correct one
            await waitFor(() => {
                screen.getByDisplayValue('Jane');
            });
            // wait for more than the debounce time
            await wait(100);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                    previousData: {
                        id: 1,
                        first_name: 'John',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
        });

        it('should not autosave if the form is changed back to being pristine', async () => {
            const dataProvider = getDataProvider();
            render(
                <InSimpleFormOptimistic
                    dataProvider={dataProvider}
                    debounce={100}
                    confirmationDuration={100}
                />
            );

            await wait(300);
            // Not called because the form is not dirty
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            const input = screen.getByLabelText('First name *');
            fireEvent.change(input, {
                target: { value: 'changed' },
            });
            await wait(50);
            fireEvent.change(input, {
                target: { value: 'John' },
            });
            await wait(300);
            // Not called because the form is back to being pristine
            expect(dataProvider.update).toHaveBeenCalledTimes(0);
        });
    });

    describe('pessimistic', () => {
        it('should autosave at the specified interval if the form is dirty and valid', async () => {
            const dataProvider = getDataProvider();
            render(
                <InSimpleFormPessimistic
                    dataProvider={dataProvider}
                    debounce={50}
                    confirmationDuration={50}
                />
            );

            await wait(300);
            // Not called because the form is not dirty
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: '' },
            });

            await wait(300);
            // Not called because the form is not valid
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'Hello' },
            });

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
        });

        it('should autosave only once per change', async () => {
            const dataProvider = getDataProvider();
            render(
                <InSimpleFormPessimistic
                    dataProvider={dataProvider}
                    debounce={50}
                    confirmationDuration={50}
                />
            );

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'Hello' },
            });

            await waitFor(() => {
                expect(dataProvider.update).toHaveBeenCalledWith(
                    'customers',
                    expect.objectContaining({
                        data: {
                            id: 1,
                            first_name: 'Hello',
                            last_name: 'Doe',
                            dob: new Date('1966-09-05'),
                            sex: 'male',
                            employer_id: 2,
                        },
                    })
                );
            });

            expect(dataProvider.update).toHaveBeenCalledTimes(1);

            await wait(300);
            expect(dataProvider.update).toHaveBeenCalledTimes(1);
        });

        it('should display an error message when the update failed and restart saving after a change', async () => {
            const dataProvider = testDataProvider({
                // @ts-ignore
                getOne: jest.fn(() =>
                    Promise.resolve({
                        data: {
                            id: 1,
                            first_name: 'John',
                            last_name: 'Doe',
                            dob: new Date('1966-09-05'),
                            sex: 'male',
                            employer_id: 2,
                        },
                    })
                ),
                // @ts-ignore
                update: jest.fn((resource, { data }) => {
                    return new Promise((resolve, reject) => {
                        setTimeout(() => {
                            if (data.first_name === 'test') {
                                return reject(
                                    new HttpError('Forbidden name', 400)
                                );
                            }
                            // @ts-ignore
                            resolve({ data: { id: 1 } });
                        }, 50);
                    });
                }),
            });
            const consoleError = jest
                .spyOn(console, 'error')
                .mockImplementation(() => undefined);
            render(
                <InSimpleFormPessimistic
                    dataProvider={dataProvider}
                    debounce={50}
                    confirmationDuration={50}
                />
            );

            // findByDisplayValue ensures the record has been loaded and applied on the form
            fireEvent.change(await screen.findByDisplayValue('John'), {
                target: { value: 'test' },
            });

            await waitFor(() =>
                expect(dataProvider.update).toHaveBeenCalledWith(
                    'customers',
                    expect.objectContaining({
                        data: {
                            id: 1,
                            first_name: 'test',
                            last_name: 'Doe',
                            dob: new Date('1966-09-05'),
                            sex: 'male',
                            employer_id: 2,
                        },
                    })
                )
            );

            await screen.findByText(
                'Server error, changes are not saved: Forbidden name'
            );

            fireEvent.change(screen.getByLabelText('First name *'), {
                target: { value: 'Hello' },
            });

            await waitFor(() =>
                expect(dataProvider.update).toHaveBeenCalledWith(
                    'customers',
                    expect.objectContaining({
                        data: {
                            id: 1,
                            first_name: 'Hello',
                            last_name: 'Doe',
                            dob: new Date('1966-09-05'),
                            sex: 'male',
                            employer_id: 2,
                        },
                    })
                )
            );
            consoleError.mockRestore();
            restoreConsoleError();
        });

        it('should save if users leave the form', async () => {
            const dataProvider = getDataProvider();
            render(
                <FullAppPessimistic dataProvider={dataProvider} debounce={50} />
            );
            fireEvent.click(await screen.findByText('John'));
            fireEvent.change(await screen.findByDisplayValue('John'), {
                target: { value: 'Hello' },
            });
            fireEvent.click(screen.getByText('Customers'));
            // wait for more than the debounce time
            await wait(75);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
        });

        it('should save if users navigate to another record', async () => {
            const dataProvider = getDataProvider();
            render(
                <FullAppPessimistic dataProvider={dataProvider} debounce={50} />
            );
            fireEvent.click(await screen.findByText('John'));
            await screen.findByText('1 / 2');
            fireEvent.change(await screen.findByDisplayValue('John'), {
                target: { value: 'Hello' },
            });
            // Let react-hook-form update its state
            await new Promise(resolve => setTimeout(resolve, 50));
            fireEvent.click(await screen.findByLabelText('Go to next page'));
            // Ensure the next record is loaded and its firstName value is the correct one
            await screen.findByDisplayValue('Jane');
            // wait for more than the debounce time
            await wait(75);
            expect(dataProvider.update).toHaveBeenCalledWith(
                'customers',
                expect.objectContaining({
                    data: {
                        id: 1,
                        first_name: 'Hello',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                    previousData: {
                        id: 1,
                        first_name: 'John',
                        last_name: 'Doe',
                        dob: new Date('1966-09-05'),
                        sex: 'male',
                        employer_id: 2,
                    },
                })
            );
        });

        it('should not autosave if the form is changed back to being pristine', async () => {
            const dataProvider = getDataProvider();
            render(
                <InSimpleFormPessimistic
                    dataProvider={dataProvider}
                    debounce={100}
                    confirmationDuration={100}
                />
            );

            await wait(300);
            // Not called because the form is not dirty
            expect(dataProvider.update).toHaveBeenCalledTimes(0);

            const input = screen.getByLabelText('First name *');
            fireEvent.change(input, {
                target: { value: 'changed' },
            });
            await wait(50);
            fireEvent.change(input, {
                target: { value: 'John' },
            });
            await wait(300);
            // Not called because the form is back to being pristine
            expect(dataProvider.update).toHaveBeenCalledTimes(0);
        });
    });
});

// see test-setup, we silence some errors
const restoreConsoleError = () => {
    const originalError = console.error;
    jest.spyOn(console, 'error').mockImplementation((...args) => {
        if (/Warning.*not wrapped in act/.test(args[0])) {
            return;
        }
        originalError.call(console, ...args);
    });
};
