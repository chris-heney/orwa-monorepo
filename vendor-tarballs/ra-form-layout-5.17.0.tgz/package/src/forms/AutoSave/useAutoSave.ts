import { useEffect, useRef, useState } from 'react';
import {
    HttpError,
    OnError,
    OnSuccess,
    TransformData,
    setSubmissionErrors,
    useEvent,
    useNotify,
    useSaveContext,
    useTranslate,
} from 'react-admin';
import { useFormContext } from 'react-hook-form';
import { useBlocker, Location, useNavigate } from 'react-router';
import { useDebouncedEvent } from './useDebouncedEvent';
import isEqual from 'lodash/isEqual';

/**
 * Automatically save the form at a regular interval.
 * @param {Object} options
 * @param {number} options.debounce The interval in ms between two saves. Defaults to 3000 (3s).
 * @param {Function} options.onSuccess A callback to call when the save request succeeds.
 * @param {Function} options.onError A callback to call when the save request fails.
 * @param {Function} options.transform A function to transform the data before saving.
 * @example
 * import { useAutoSave } from '@react-admin/ra-form-layout';
 * import { Edit, SaveButton, SimpleForm, TextInput, Toolbar } from 'react-admin';
 *
 * const AutoSave = () => {
 *     const [lastSave, setLastSave] = useState();
 *     const [error, setError] = useState();
 *     useAutoSave({
 *         interval: 5000,
 *         onSuccess: () => setLastSave(new Date()),
 *         onError: (error) => setError(error)
 *     });
 *     return (
 *         <div>
 *             {lastSave && <p>Saved at {lastSave.toLocaleString()}</p>}
 *             {error && <p>Error: {error}</p>}
 *         </div>
 *     );
 * };
 *
 * const AutoSaveToolbar = () => (
 *    <Toolbar>
 *       <SaveButton />
 *       <AutoSave />
 *   </Toolbar>
 * );
 *
 * const PostEdit = () => (
 *     <Edit mutationMode="optimistic">
 *         <SimpleForm toolbar={AutoSaveToolbar} resetOptions={{ keepDirtyValues: true }}>
 *             <TextInput source="title" />
 *             <TextInput source="teaser" />
 *         </SimpleForm>
 *     </Edit>
 * );
 */
export const useAutoSave = (options: UseAutoSaveParams = {}) => {
    const {
        debounce = 3000,
        onSuccess = noop,
        onError = noop,
        transform,
        disableWarnWhenUnsavedChanges = false,
    } = options;
    const form = useFormContext();
    const saveContext = useSaveContext();
    const translate = useTranslate();
    const handleSuccess = useEvent(onSuccess);
    const handleError = useEvent(onError);
    const hasFormChanged = useRef(false);
    // RHF formState.isSubmitSuccessful is unreliable so we track submit success ourselves
    const hasSubmitFailed = useRef(false);
    const isAutoSaving = useRef(false);
    if (!form || !saveContext) {
        throw new Error('Cannot use useAutoSave outside of a react-admin form');
    }
    if (saveContext.mutationMode === 'undoable') {
        throw new Error(
            'The useAutoSave hook cannot be used in undoable Edit views. Use <Edit mutationMode="optimistic"> or <Edit mutationMode="pessimistic"> instead.'
        );
    }

    const { formState, getValues, handleSubmit, setError, trigger, watch } =
        form;
    const { defaultValues, isDirty, isValid, errors, isSubmitting } = formState;

    const shouldBlock =
        !disableWarnWhenUnsavedChanges &&
        (!isValid || hasFormChanged.current || hasSubmitFailed.current);

    const [shouldNotify, setShouldNotify] = useState(false);
    const nextLocationRef = useRef<Location<any> | null>(null);
    const navigate = useNavigate();
    const notify = useNotify();
    const blockedOnce = useRef(false);

    const blocker = useBlocker(({ nextLocation }) => {
        nextLocationRef.current = nextLocation;
        if (!shouldBlock) return false;

        // Only in pessimistic mode, we want to block navigation while the form is saving to ensure
        // users don't loose their changes if the save fails
        // Only in pessimistic mode, if the form is saving, we want to block navigation to avoid data loss in case of server errors
        if (
            saveContext.mutationMode === 'pessimistic' &&
            (hasFormChanged.current || saveContext?.saving || isSubmitting)
        ) {
            // Except if users already tried to navigate away once
            if (blockedOnce.current && blocker.state === 'blocked') {
                blocker.proceed();
                return false;
            }
            // Except if the save was triggered manually as it would prevent the default redirection in Create/Edit
            if (isSubmitting && !isAutoSaving.current) {
                return false;
            }
            // Track that we blocked the navigation once
            blockedOnce.current = true;
            return true;
        }

        // TODO: make the formRootPathname available from context in OSS to allow usage in a Form that have sub routes
        // Also check if the new location is inside the form
        // const initialLocation = formRootPathname || currentLocation.pathname;
        // const newLocationIsInsideCurrentLocation =
        //     nextLocation.pathname.startsWith(initialLocation);
        // const newLocationIsShowView = nextLocation.pathname.startsWith(
        //     `${initialLocation}/show`
        // );
        // const newLocationIsInsideForm =
        //     newLocationIsInsideCurrentLocation && !newLocationIsShowView;
        // if (newLocationIsInsideForm) return false;

        if (
            saveContext.mutationMode !== 'pessimistic' &&
            // If the form is dirty and not valid, we want to block navigation to avoid data loss
            !isValid &&
            isDirty
        ) {
            return true;
        }

        return (
            saveContext.mutationMode === 'pessimistic' && !isValid && isDirty
        );
    });

    const submitEvent = useEvent(() => {
        if (!isDirty || Object.keys(errors).length > 0) {
            return;
        }
        const submitCallback = async values => {
            let serverErrors;
            if (
                saveContext?.save &&
                !saveContext.saving &&
                !isSubmitting &&
                isValid
            ) {
                isAutoSaving.current = true;
                // Because isDirty is not always up-to-date when reverting an input to its initial value
                // we have to check whether the record is actually different from the defaultValues
                if (isEqual(defaultValues, values)) return;

                serverErrors = await saveContext.save(values, {
                    onSuccess: (response, variables, context) => {
                        blockedOnce.current = false;
                        hasFormChanged.current = false;
                        hasSubmitFailed.current = false;
                        isAutoSaving.current = false;
                        // In pessimistic mode, the navigation might have been blocked because the form was saving
                        // We need to proceed now that the save is done
                        if (blocker.state === 'blocked') {
                            blocker.reset();
                            // If we blocked a navigation, we need to navigate now that the save is done
                            setTimeout(() => {
                                if (nextLocationRef.current) {
                                    navigate(nextLocationRef.current);
                                    nextLocationRef.current = null;
                                }
                            });
                        }
                        if (handleSuccess) {
                            handleSuccess(response, variables, context);
                        }
                    },
                    onError: error => {
                        isAutoSaving.current = false;
                        blockedOnce.current = false;
                        hasSubmitFailed.current = true;
                        if (handleError) {
                            handleError(error);
                        }
                        // TODO: Duplicated code from useEditController. We probably could export a function/hook from OSS for this
                        const validationErrors = (error as HttpError)?.body
                            ?.errors;
                        const hasValidationErrors =
                            !!validationErrors &&
                            Object.keys(validationErrors).length > 0;
                        if (
                            !hasValidationErrors ||
                            saveContext.mutationMode !== 'pessimistic'
                        ) {
                            notify(
                                typeof error === 'string'
                                    ? error
                                    : (error as Error).message ||
                                          'ra.notification.http_error',
                                {
                                    type: 'error',
                                    messageArgs: {
                                        _:
                                            typeof error === 'string'
                                                ? error
                                                : error instanceof Error ||
                                                    (typeof error ===
                                                        'object' &&
                                                        error !== null &&
                                                        error.hasOwnProperty(
                                                            'message'
                                                        ))
                                                  ? // @ts-ignore
                                                    error.message
                                                  : undefined,
                                    },
                                }
                            );
                        }
                    },
                    transform,
                });
            }

            if (serverErrors != null) {
                setSubmissionErrors(serverErrors, setError);
            } else {
                setSubmissionErrors({}, setError);
            }
        };
        return handleSubmit(submitCallback)();
    });

    const [save, { cancel }] = useDebouncedEvent(submitEvent, debounce);

    useEffect(() => {
        const { unsubscribe } = watch((value, { type }) => {
            if (type) {
                // Because isDirty is not always up-to-date when reverting an input to its initial value
                // we have to check whether the record is actually different from the defaultValues
                // Checking it here ensures we don't prevent closing the tab when the form has been reverted to its initial values
                hasFormChanged.current = !isEqual(defaultValues, getValues());
                save();
            }
        });
        return () => unsubscribe();
    }, [defaultValues, getValues, save, watch]);

    useEffect(() => {
        if (blocker.state === 'blocked') {
            // Corner case: the blocker might be triggered by a redirect in the onSuccess side effect,
            // happening during the same tick the form is reset after a successful save.
            // In that case, the blocker will block but shouldNotBlock will be true one tick after.
            // If we are in that case, we can proceed immediately.
            const isSaving =
                saveContext.mutationMode === 'pessimistic' &&
                (saveContext?.saving || isSubmitting);
            if (hasFormChanged.current && !isSaving) {
                submitEvent();
            } else if ((!shouldBlock || isValid) && !isSaving) {
                blocker.proceed();
                return;
            }

            // We don't want to notify users if the changes they made are valid
            // as we're going to save them automatically
            setShouldNotify(!isValid);
        }
        // This effect should only run when the blocker state changes, not when shouldNotBlock changes.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [blocker.state]);

    useEffect(() => {
        if (shouldNotify) {
            setShouldNotify(false);
            const shouldProceed = window.confirm(
                translate('ra.message.unsaved_changes')
            );
            if (shouldProceed) {
                blocker.proceed && blocker.proceed();
            } else {
                blocker.reset && blocker.reset();
            }
        }
        // Can't use blocker in the dependency array because it is not stable across rerenders
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [shouldNotify, translate]);

    useEffect(() => {
        const handleBeforeUnload = (event: BeforeUnloadEvent) => {
            if (shouldBlock) {
                event.preventDefault();
                // Included for legacy support, e.g. Chrome/Edge < 119
                event.returnValue = true;
                // Trigger a save immediately (we don't call save which is debounced) to avoid data loss
                submitEvent();
            }
        };
        window.addEventListener('beforeunload', handleBeforeUnload);

        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
        };
    }, [shouldBlock, submitEvent]);

    useEffect(() => {
        // When the parent component unmount, trigger a save immediately (we don't call save which is debounced) to avoid data loss
        return () => {
            trigger().then(() => {
                submitEvent();
                cancel();
            });
        };
    }, [cancel, submitEvent, trigger]);

    return saveContext?.saving || isSubmitting;
};

// eslint-disable-next-line @typescript-eslint/no-empty-function
const noop = () => {};

export interface UseAutoSaveParams {
    debounce?: number;
    onSuccess?: OnSuccess;
    onError?: OnError;
    transform?: TransformData;
    disableWarnWhenUnsavedChanges?: boolean;
}
