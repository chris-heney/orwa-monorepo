import * as React from 'react';
import { ComponentType, ReactNode, useState } from 'react';
import clsx from 'clsx';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
    FormGroupContextProvider,
    InputProps,
    Loading,
    useCanAccess,
    useFormGroup,
    useResourceContext,
    useTranslate,
} from 'react-admin';
import { useFormState } from 'react-hook-form';
import get from 'lodash/get';
import {
    Accordion as MuiAccordion,
    AccordionDetails as MuiAccordionDetails,
    AccordionSummary as MuiAccordionSummary,
    AccordionProps,
    AccordionDetailsProps,
    AccordionSummaryProps,
    Typography,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { useAuthorizedChildren } from '@react-admin/ra-core-ee';

/**
 * Renders children (Inputs) inside a MUI <Accordion> element without a Card style.
 *
 * To be used as child of a <SimpleForm> or a <TabbedForm> element.
 *
 * @param {string | ReactNode} label The main label used as the accordion summary. Appears in red when the accordion has errors
 * @param {string | ReactNode} secondary Optional. The secondary label used as the accordion summary
 * @param {string} id Optional. Set an id for this Accordion to be used for CSS classes
 * @param {boolean} fullWidth Optional. If true, the Accordion take the entire form width.
 * @param {string} className Optional. A class name to style the underlying <Accordion>.
 * @param {object} classes Optional. Override styles of the <Accordion>, the <AccordionSummary> and the <AccordionDetails> internal components.
 * @param {boolean} defaultExpanded Optional. Set to true to have the accordion expanded by default.
 * @param {boolean} disabled Optional. If true, the accordion will be displayed in a disabled state.
 * @param {boolean} square Optional. If true, rounded corners are disabled.
 * @param {ReactElement} TransitionComponent Optional. The MUI component used for the transition.
 * @param {object} TransitionProps Optional. If true, rounded corners are disabled.
 *
 * @example
 *
 * import { Edit, TextField, TextInput, DateInput, SelectInput, ArrayInput, SimpleForm, SimpleFormIterator, BooleanInput } from 'react-admin';
 * import { AccordionSection } from '@react-admin/ra-form-layout';
 *
 * const CustomerEdit = () => (
 *     <Edit component="div">
 *         <SimpleForm>
 *              <Labeled label="id">
 *                  <TextField source="id" />
 *             </Labeled>
 *             <TextInput source="first_name" validate={required()} />
 *             <TextInput source="last_name" validate={required()} />
 *             <DateInput source="dob" label="born" validate={required()} />
 *             <SelectInput source="sex" choices={sexChoices} />
 *             <AccordionSection label="Occupations">
 *                 <ArrayInput source="occupations" label="">
 *                     <SimpleFormIterator>
 *                         <TextInput source="name" validate={required()} />
 *                         <DateInput source="from" validate={required()} />
 *                         <DateInput source="to" />
 *                     </SimpleFormIterator>
 *                 </ArrayInput>
 *             </AccordionSection>
 *             <AccordionSection label="Preferences">
 *                 <SelectInput
 *                     source="language"
 *                     choices={languageChoices}
 *                     defaultValue="en"
 *                 />
 *                 <BooleanInput source="dark_theme" />
 *                 <BooleanInput source="accepts_emails_from_partners" />
 *             </AccordionSection>
 *         </SimpleFormForm>
 *     </Edit>
 * );
 *
 */
export const AccordionSection = (props: AccordionSectionProps) => {
    const [defaultId] = useState(
        () => 'id' + Math.random().toFixed(10).slice(2)
    );

    const id =
        props.id !== undefined
            ? props.id
            : typeof props.label === 'string'
              ? props.label
              : defaultId;

    return (
        <FormGroupContextProvider name={id}>
            <AccordionFormSectionView id={id} {...props} />
        </FormGroupContextProvider>
    );
};

const AccordionFormSectionView = (
    props: AccordionSectionProps & {
        id: string;
    }
) => {
    const {
        accessDenied = null,
        Accordion = DefaultAccordion,
        AccordionDetails = DefaultAccordionDetails,
        AccordionSummary = DefaultAccordionSummary,
        authorizationError = null,
        children,
        className,
        count,
        defaultExpanded = false,
        disabled = false,
        enableAccessControl = false,
        fullWidth = true,
        label,
        loading = DefaultLoading,
        secondary,
        id,
        square,
        TransitionComponent,
        TransitionProps,
        ...rest
    } = props;
    const [expanded, setExpanded] = useState<boolean>(defaultExpanded);
    const resource = useResourceContext(props);
    const translate = useTranslate();
    const { isSubmitted } = useFormState();
    const { canAccess, error, isPending } = useCanAccess({
        action: 'write',
        resource: `${resource}.section.${id ?? label}`,
        enabled: enableAccessControl,
    });

    const formGroup = useFormGroup(id);

    const hasErrors =
        !formGroup.isValid && (formGroup.isTouched || isSubmitted);
    const handleChange = (): void => {
        setExpanded(expanded => !expanded);
    };
    let tabLabel =
        typeof label === 'string' ? (
            <>{translate(label, { _: label })}</>
        ) : (
            label
        );
    if (count !== undefined) {
        tabLabel = (
            <span>
                {tabLabel} ({count})
            </span>
        );
    }

    const {
        authorizedChildren,
        error: errorAuthorizedChildren,
        isPending: isPendingAuthorizedChildren,
    } = useAuthorizedChildren({
        children,
        enabled: enableAccessControl,
    });

    if (error) {
        return authorizationError;
    }

    if (enableAccessControl && isPending) {
        return loading;
    }

    if (enableAccessControl && !canAccess) {
        return accessDenied;
    }

    return (
        <Accordion
            {...rest}
            expanded={expanded}
            onChange={handleChange}
            disabled={disabled}
            square={square}
            className={clsx(className, {
                [AccordionSectionClasses.fullWidth]: fullWidth,
            })}
            TransitionComponent={TransitionComponent}
            TransitionProps={TransitionProps}
        >
            <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`panel-${id}-content`}
                id={`panel-${id}-header`}
                className={AccordionSectionClasses.summary}
            >
                <Typography
                    component="div"
                    sx={{
                        color: hasErrors ? 'error.main' : 'text.primary',
                    }}
                    className={AccordionSectionClasses.heading}
                >
                    {tabLabel}
                </Typography>
                <Typography
                    component="div"
                    className={AccordionSectionClasses.secondaryHeading}
                >
                    {secondary && typeof secondary === 'string'
                        ? translate(secondary, { _: secondary })
                        : secondary}
                </Typography>
            </AccordionSummary>
            <AccordionDetails className={AccordionSectionClasses.detail}>
                {errorAuthorizedChildren
                    ? authorizationError
                    : enableAccessControl && isPendingAuthorizedChildren
                      ? loading
                      : authorizedChildren}
            </AccordionDetails>
        </Accordion>
    );
};

export const hasInputsWithError = (
    children: React.ReactNode,
    errors: unknown
): boolean =>
    React.Children.toArray(children).some(
        input =>
            React.isValidElement(input) &&
            get(errors, (input as React.ReactElement<InputProps>).props.source)
    );

const PREFIX = 'RaAccordionSection';

export const AccordionSectionClasses = {
    heading: `${PREFIX}-heading`,
    secondaryHeading: `${PREFIX}-secondaryHeading`,
    summary: `${PREFIX}-summary`,
    detail: `${PREFIX}-detail`,
    fullWidth: `${PREFIX}-fullWidth`,
};

const StyledAccordion = styled(MuiAccordion, {
    name: PREFIX,
    overridesResolver: (props, styles) => styles.root,
})(({ theme }) => ({
    [`& .${AccordionSectionClasses.heading}`]: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '33.33%',
        flexShrink: 0,
    },
    [`& .${AccordionSectionClasses.secondaryHeading}`]: {
        fontSize: theme.typography.pxToRem(15),
        color: theme.palette.text.secondary,
    },
    [`& .${AccordionSectionClasses.summary}`]: {},
    [`& .${AccordionSectionClasses.detail}`]: {
        display: 'block',
    },
    [`&.${AccordionSectionClasses.fullWidth}`]: {
        width: '100%',
    },
}));

const DefaultAccordion = styled(StyledAccordion)(({ theme }) => ({
    width: theme.spacing(55),
    marginBottom: -1,
    border: '1px solid rgba(0, 0, 0, .125)',
    boxShadow: 'none',
    '&:last-child.Mui-expanded': {
        marginBottom: theme.spacing(2),
    },
    '&:before': {
        display: 'none',
    },
    expanded: {},
}));

const DefaultAccordionSummary = styled(MuiAccordionSummary)(() => ({
    backgroundColor: 'rgba(0, 0, 0, .03)',
    marginBottom: -1,
    '&.Mui-expanded': {
        backgroundColor: 'rgba(0, 0, 0, .05)',
        borderBottom: '1px solid rgba(0, 0, 0, .125)',
    },
    '&, &.Mui-expanded': {
        minHeight: 56,
        '.MuiAccordionSummary-content': {
            margin: 0,
        },
    },
    expanded: {},
}));

const DefaultAccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
    root: {
        padding: theme.spacing(2),
    },
}));
const DefaultLoading = <Loading />;

export interface AccordionSectionProps extends Omit<AccordionProps, 'classes'> {
    accessDenied?: ReactNode;
    Accordion?: ComponentType<AccordionProps>;
    AccordionDetails?: ComponentType<AccordionDetailsProps>;
    AccordionSummary?: ComponentType<AccordionSummaryProps>;
    authorizationError?: ReactNode;
    count?: ReactNode;
    enableAccessControl?: boolean;
    label?: string | ReactNode;
    loading?: ReactNode;
    secondary?: string | ReactNode;
    id?: string;
    fullWidth?: boolean;
    record?: any;
    resource?: any;
}

export default AccordionSection;
