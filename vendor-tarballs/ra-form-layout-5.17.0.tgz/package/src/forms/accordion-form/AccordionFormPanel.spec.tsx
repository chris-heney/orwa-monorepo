import * as React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import {
    AutoClose,
    AutoCloseWithReactNodeLabel,
    Basic,
    ReactNodeLabelAndSecondary,
    ReactNodeLabelAndSecondaryWithId,
} from '../../../stories/accordionForm.stories';

describe('AccordionFormPanel', () => {
    it('should set the section id and aria-controls with the label', async () => {
        render(<Basic />);
        const accordion = await screen.findByLabelText('Identity');
        expect(accordion).toHaveProperty('id', 'panel-Identity-content');
        expect(accordion.getAttribute('aria-labelledby')).toBe(
            'panel-Identity-header'
        );
    });
    it('should set the section id and aria-controls with the id', async () => {
        render(<ReactNodeLabelAndSecondaryWithId />);
        await screen.findByRole('region');
        const accordion = screen.getByRole('region');
        expect(accordion).toHaveProperty('id', 'panel-idIdentity-content');
        expect(accordion.getAttribute('aria-labelledby')).toBe(
            'panel-idIdentity-header'
        );
    });
    it('should set the section id and aria-controls with an generated id', async () => {
        render(<ReactNodeLabelAndSecondary />);
        await screen.findByRole('region');
        const accordion = screen.getByRole('region');
        expect(accordion.id).toMatch(/panel-id[0-9]+-content/);
        expect(accordion.getAttribute('aria-labelledby')).toMatch(
            /panel-id[0-9]+-header/
        );
        expect(accordion.getAttribute('aria-labelledby')?.slice(6, -7)).toEqual(
            accordion.id.slice(6, -8)
        );
        expect(accordion.id.slice(6, -8)).toHaveLength(12);
    });
    it('should switch between the different accordions with autoclose prop', async () => {
        render(<AutoClose />);

        await screen.findByText('Identity');
        expect(
            screen
                .getByText('Identity')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('true');
        expect(
            screen
                .getByText('Occupations')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Preferences')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');

        fireEvent.click(
            screen.getByText('Occupations').closest('[role=button]')!
        );
        fireEvent.click(await screen.findByLabelText('Add'));
        expect(
            screen
                .getByText('Identity')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Occupations')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('true');
        expect(
            screen
                .getByText('Preferences')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');

        fireEvent.click(
            screen.getByText('Preferences').closest('[role=button]')!
        );
        await screen.findByText('English');
        expect(
            screen
                .getByText('Identity')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Occupations')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Preferences')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('true');
    }, 35000);
    it('should switch between the different accordions with autoclose prop when label is a react node', async () => {
        render(<AutoCloseWithReactNodeLabel />);

        await screen.findByText('Identity');

        expect(
            screen
                .getByText('Identity')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('true');
        expect(
            screen
                .getByText('Occupations')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Preferences')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');

        fireEvent.click(
            screen.getByText('Occupations').closest('[role=button]')!
        );
        await screen.findByLabelText('Add');
        expect(
            screen
                .getByText('Identity')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Occupations')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('true');
        expect(
            screen
                .getByText('Preferences')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');

        fireEvent.click(
            screen.getByText('Preferences').closest('[role=button]')!
        );
        await screen.findByText('English');
        expect(
            screen
                .getByText('Identity')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Occupations')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('false');
        expect(
            screen
                .getByText('Preferences')
                .closest('[role=button]')!
                .getAttribute('aria-expanded')
        ).toBe('true');
    }, 35000);
});
