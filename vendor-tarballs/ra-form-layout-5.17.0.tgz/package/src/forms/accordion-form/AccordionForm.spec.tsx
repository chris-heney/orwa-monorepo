import * as React from 'react';
import { render, screen } from '@testing-library/react';
import {
    AccessControl,
    AccessControlOnTabsOnly,
} from '../../../stories/accordionForm.stories';

describe('AccordionForm', () => {
    it('should apply access control to the panels if enableAccessControl is true', async () => {
        const { rerender } = render(
            <AccessControl
                canAccessBornInput={false}
                canAccessPreferences={false}
            />
        );

        await screen.findByText('Identity', undefined, { timeout: 4000 });
        await screen.findByText('Occupations');
        expect(screen.queryByText('Preferences')).toBeNull();

        rerender(
            <AccessControl
                canAccessBornInput={false}
                canAccessPreferences={true}
            />
        );
        await screen.findByText('Identity', undefined, { timeout: 4000 });
        await screen.findByText('Occupations');
        await screen.findByText('Preferences');
    });
    it('should apply access control only to the panels if enableAccessControl is true but is overridden on panels', async () => {
        const { rerender } = render(
            <AccessControlOnTabsOnly
                canAccessBornInput={false}
                canAccessPreferences={false}
            />
        );

        await screen.findByText('Identity');
        // Should be displayed even though the permission would return false if checked as
        // the panels have enableAccessControl set to false
        await screen.findByLabelText('born *');
        await screen.findByText('Occupations');
        expect(screen.queryByText('Preferences')).toBeNull();

        rerender(
            <AccessControlOnTabsOnly
                canAccessBornInput={false}
                canAccessPreferences={true}
            />
        );
        await screen.findByText('Identity');
        // Should be displayed even though the permission would return false if checked as
        // the panels have enableAccessControl set to false
        await screen.findByLabelText('born *');
        await screen.findByText('Occupations');
        await screen.findByText('Preferences');
    });
});
