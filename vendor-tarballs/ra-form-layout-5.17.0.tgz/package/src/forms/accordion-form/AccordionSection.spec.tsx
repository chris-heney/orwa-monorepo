import * as React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import expect from 'expect';
import {
    Basic,
    ReactNodeLabelAndSecondary,
    ReactNodeLabelAndSecondaryWithId,
} from '../../../stories/accordionSection.stories';
import { AccessControl } from '../../../stories/accordionForm.stories';

describe('AccordionSection', () => {
    it('should set the section id and aria-controls with the label', async () => {
        render(<Basic />);
        fireEvent.click(await screen.findByText('Occupations'));
        const accordion = await screen.findByLabelText('Occupations');
        expect(accordion).toHaveProperty('id', 'panel-Occupations-content');
        expect(accordion.getAttribute('aria-labelledby')).toBe(
            'panel-Occupations-header'
        );
    });
    it('should set the section id and aria-controls with the id', async () => {
        render(<ReactNodeLabelAndSecondaryWithId />);
        (await screen.findByText('Occupations')).click();
        await screen.findByRole('region');
        const accordion = screen.getByRole('region');
        expect(accordion).toHaveProperty('id', 'panel-idOccupations-content');
        expect(accordion.getAttribute('aria-labelledby')).toBe(
            'panel-idOccupations-header'
        );
    });
    it('should set the section id and aria-controls with an generated id', async () => {
        render(<ReactNodeLabelAndSecondary />);
        (await screen.findByText('Occupations')).click();
        await screen.findByRole('region');
        const accordion = screen.getByRole('region');
        expect(accordion.id).toMatch(/panel-id[0-9]+-content/);
        expect(accordion.getAttribute('aria-labelledby')).toMatch(
            /panel-id[0-9]+-header/
        );
        expect(accordion.getAttribute('aria-labelledby')?.slice(6, -7)).toEqual(
            accordion.id.slice(6, -8)
        );
        expect(accordion.id.slice(6, -8)).toHaveLength(12);
    });
    it('should apply access control to the inputs if enableAccessControl is true', async () => {
        const { rerender } = render(
            <AccessControl
                canAccessBornInput={false}
                canAccessPreferences={false}
            />
        );

        await screen.findByLabelText('First name *', undefined, {
            timeout: 4000,
        });
        expect(screen.queryByLabelText('born *')).toBeNull();

        rerender(
            <AccessControl
                canAccessBornInput={true}
                canAccessPreferences={false}
            />
        );
        await screen.findByLabelText('born *', undefined, { timeout: 4000 });
    });
});
