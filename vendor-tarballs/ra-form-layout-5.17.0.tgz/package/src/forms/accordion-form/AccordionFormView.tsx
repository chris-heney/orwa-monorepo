import * as React from 'react';
import { Children, isValidElement, ReactElement, ReactNode } from 'react';
import { Loading, Toolbar } from 'react-admin';
import { SxProps, Box } from '@mui/material';
import get from 'lodash/get';
import {
    useAuthorizedChildren,
    UseAuthorizedChildrenFilterChildren,
    UseAuthorizedChildrenGetResourceKey,
} from '@react-admin/ra-core-ee';

import { AccordionFormPanelProps } from './AccordionFormPanel';

export const AccordionFormView = ({
    authorizationError = null,
    autoClose = false,
    children,
    className,
    enableAccessControl = false,
    loading = DefaultLoading,
    resource,
    toolbar = DefaultToolbar,
    sx,
}: AccordionFormViewProps) => {
    const childrenArray = Children.toArray(children);
    const { authorizedChildren, isPending, error } = useAuthorizedChildren({
        children,
        action: 'write',
        getResourceKey,
        filterChildren,
        enabled: enableAccessControl,
    });
    const firstPanel =
        childrenArray.length > 0
            ? (childrenArray[0] as ReactElement<AccordionFormPanelProps>)
            : null;
    if (!isValidElement(firstPanel)) {
        throw new Error(
            'AccordionForm must only contain AccordionForm.Panel elements'
        );
    }
    const firstPanelId = firstPanel?.props.id
        ? firstPanel.props.id
        : typeof firstPanel.props.label === 'string'
          ? firstPanel.props.label
          : null;

    const [expanded, setExpanded] = React.useState<string | false>(
        firstPanelId ?? false
    );

    const handleChange =
        (panel: string) =>
        (event: React.ChangeEvent<unknown>, isExpanded: boolean): void => {
            setExpanded(isExpanded ? panel : false);
        };

    if (error) {
        return authorizationError;
    }

    if (enableAccessControl && isPending) {
        return loading;
    }

    return (
        <Box className={className} sx={sx}>
            <div>
                {Children.map(
                    authorizedChildren,
                    (accordionPanel: ReactElement<AccordionFormPanelProps>) =>
                        React.isValidElement(accordionPanel)
                            ? React.cloneElement(accordionPanel, {
                                  autoClose,
                                  expanded:
                                      expanded ===
                                      (accordionPanel.props.id
                                          ? accordionPanel.props.id
                                          : accordionPanel.props.label),
                                  onChange: handleChange(
                                      accordionPanel.props.id
                                          ? accordionPanel.props.id
                                          : accordionPanel.props.label!.toString()
                                  ),
                                  resource,
                                  enableAccessControl:
                                      accordionPanel.props
                                          .enableAccessControl ??
                                      enableAccessControl,
                              })
                            : null
                )}
            </div>
            {toolbar}
        </Box>
    );
};

const DefaultToolbar = <Toolbar sx={{ backgroundColor: 'transparent' }} />;
const DefaultLoading = <Loading />;
const getResourceKey: UseAuthorizedChildrenGetResourceKey = (
    child,
    resource
) => {
    return `${resource}.section.${child.props.id ?? child.props.label}`;
};
const filterChildren: UseAuthorizedChildrenFilterChildren = child => {
    if (child.props.id == null && child.props.label == null) {
        if (process.env.NODE_ENV === 'development') {
            console.warn(
                `You enabled access control on the AccordionForm but didn't provide an id nor a label to its panels. Access control cannot be enforced on some panels.`
            );
        }
        return false;
    }
    return true;
};

export interface AccordionFormViewProps {
    autoClose?: boolean;
    authorizationError?: ReactNode;
    children?: ReactNode;
    className?: string;
    enableAccessControl?: boolean;
    loading?: ReactNode;
    resource?: string;
    submitOnEnter?: boolean;
    toolbar?: ReactElement;
    sx?: SxProps;
}

export const findAccordionsWithErrors = (
    children: ReactNode,
    errors
): string[] =>
    Children.toArray(children).reduce<string[]>((acc, child) => {
        if (!isValidElement<any>(child)) {
            return acc;
        }
        const childAsElement = child as ReactElement<any>;

        const inputs = Children.toArray(childAsElement.props.children);

        if (
            inputs.some(
                input =>
                    isValidElement<any>(input) &&
                    get(errors, (input as ReactElement<any>).props.source)
            )
        ) {
            return [...acc, childAsElement.props.label as string];
        }

        return acc;
    }, []);
