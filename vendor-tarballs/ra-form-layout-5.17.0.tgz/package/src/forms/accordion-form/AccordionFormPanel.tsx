import * as React from 'react';
import { useState, ReactNode } from 'react';
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Typography,
    SxProps,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import {
    FormGroupContextProvider,
    Loading,
    RaRecord,
    useFormGroup,
    useTranslate,
} from 'react-admin';
import { useFormState } from 'react-hook-form';
import { useAuthorizedChildren } from '@react-admin/ra-core-ee';

/**
 * Renders children (Inputs) inside a MUI <Accordion> element.
 *
 * To be used as child of an <AccordionForm> element.
 *
 * @param {string | ReactNode} label The main label used as the accordion summary. Appears in red when the accordion has errors
 * @param {string | ReactNode} secondary Optional. The secondary label used as the accordion summary
 * @param {string} id Optional. Set an id for this Accordion to be used in the `useFormGroup` hook and for CSS classes
 * @param {boolean} defaultExpanded Optional. Set to true to have the accordion expanded by default (except if autoClose = true on the parent)
 * @param {boolean} disabled Optional. If true, the accordion will be displayed in a disabled state.
 * @param {boolean} square Optional. If true, rounded corners are disabled.
 *
 * @example
 *
 * import { Edit, TextField, TextInput, DateInput, SelectInput, ArrayInput, SimpleFormIterator, BooleanInput } from 'react-admin';
 * import { AccordionForm, AccordionFormPanel } from '@react-admin/ra-form-layout';
 *
 * // don't forget the component="div" prop on the main component to disable the main Card
 * const CustomerEdit = () => (
 *     <Edit component="div">
 *         <AccordionForm>
 *             <AccordionFormPanel label="Identity" defaultExpanded>
 *                 <TextField source="id" />
 *                 <TextInput source="first_name" validate={required()} />
 *                 <TextInput source="last_name" validate={required()} />
 *                 <DateInput source="dob" label="born" validate={required()} />
 *                 <SelectInput source="sex" choices={sexChoices} />
 *             </AccordionFormPanel>
 *             <AccordionFormPanel label="Occupations">
 *                 <ArrayInput source="occupations" label="">
 *                     <SimpleFormIterator>
 *                         <TextInput source="name" validate={required()} />
 *                         <DateInput source="from" validate={required()} />
 *                         <DateInput source="to" />
 *                     </SimpleFormIterator>
 *                 </ArrayInput>
 *             </AccordionFormPanel>
 *             <AccordionFormPanel label="Preferences">
 *                 <SelectInput
 *                     source="language"
 *                     choices={languageChoices}
 *                     defaultValue="en"
 *                 />
 *                 <BooleanInput source="dark_theme" />
 *                 <BooleanInput source="accepts_emails_from_partners" />
 *             </AccordionFormPanel>
 *         </AccordionForm>
 *     </Edit>
 * );
 */

export const AccordionFormPanel = (props: AccordionFormPanelProps) => {
    if (
        props.id == undefined &&
        typeof props.label !== 'string' &&
        props.autoClose
    ) {
        throw new Error(
            'AccordionFormPanel does not support React Element as label without an id prop. Please provide an id prop.'
        );
    }

    const [defaultId] = useState(
        () => 'id' + Math.random().toFixed(10).slice(2)
    );

    const id =
        props.id !== undefined
            ? props.id
            : typeof props.label === 'string'
              ? props.label
              : defaultId;

    return (
        <FormGroupContextProvider name={id}>
            <AccordionFormPanelView id={id} {...props} />
        </FormGroupContextProvider>
    );
};

const AccordionFormPanelView = (
    props: AccordionFormPanelProps & { id: string }
) => {
    const {
        authorizationError = null,
        children,
        count,
        defaultExpanded = false,
        disabled = false,
        enableAccessControl = false,
        label,
        loading = DefaultLoading,
        secondary,
        id,
        square,
        // injected by the parent
        autoClose = false,
        onChange,
        expanded,
        className,
        sx,
    } = props;
    const [innerExpanded, setExpanded] = useState<boolean>(defaultExpanded);

    const handleChange = (): void => {
        setExpanded(expanded => !expanded);
    };

    const accordionParams = autoClose
        ? {
              expanded,
              onChange,
          }
        : {
              expanded: innerExpanded,
              onChange: handleChange,
          };

    const translate = useTranslate();
    const formGroup = useFormGroup(id);
    const { isSubmitted } = useFormState();
    const hasErrors =
        !formGroup.isValid && (formGroup.isTouched || isSubmitted);
    let tabLabel =
        typeof label === 'string' ? (
            <>{translate(label, { _: label })}</>
        ) : (
            label
        );
    if (count !== undefined) {
        tabLabel = (
            <span>
                {tabLabel} ({count})
            </span>
        );
    }

    const { authorizedChildren, error, isPending } = useAuthorizedChildren({
        children,
        enabled: enableAccessControl,
    });

    if (error) {
        return authorizationError;
    }

    if (enableAccessControl && isPending) {
        return loading;
    }

    return (
        <StyledAccordion
            {...accordionParams}
            disabled={disabled}
            square={square}
            className={className}
            sx={sx}
        >
            <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`panel-${id}-content`}
                id={`panel-${id}-header`}
            >
                <Typography
                    component="div"
                    className={AccordionFormPanelClasses.heading}
                    sx={{
                        color: hasErrors ? 'error.main' : 'text.primary',
                    }}
                >
                    {tabLabel}
                </Typography>
                <Typography
                    component="div"
                    className={AccordionFormPanelClasses.secondaryHeading}
                >
                    {secondary && typeof secondary === 'string'
                        ? translate(secondary, { _: secondary })
                        : secondary}
                </Typography>
            </AccordionSummary>
            <AccordionDetails className={AccordionFormPanelClasses.detail}>
                {authorizedChildren}
            </AccordionDetails>
        </StyledAccordion>
    );
};

const DefaultLoading = <Loading />;

export interface AccordionFormPanelProps {
    authorizationError?: ReactNode;
    children: ReactNode;
    count?: ReactNode;
    defaultExpanded?: boolean;
    disabled?: boolean;
    enableAccessControl?: boolean;
    label: string | ReactNode;
    loading?: ReactNode;
    secondary?: string | ReactNode;
    id?: string;
    square?: boolean;
    // injected by the parent
    autoClose?: boolean;
    onChange?: (event: React.ChangeEvent<unknown>, isExpanded: boolean) => void;
    record?: RaRecord;
    resource?: string;
    expanded?: boolean;
    className?: string;
    sx?: SxProps;
}

const PREFIX = 'RaAccordionFormPanel';

export const AccordionFormPanelClasses = {
    heading: `${PREFIX}-heading`,
    secondaryHeading: `${PREFIX}-secondaryHeading`,
    detail: `${PREFIX}-detail`,
};

const StyledAccordion = styled(Accordion, {
    name: PREFIX,
    overridesResolver: (props, styles) => styles.root,
})(({ theme }) => ({
    [`& .${AccordionFormPanelClasses.heading}`]: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '33.33%',
        flexShrink: 0,
    },
    [`& .${AccordionFormPanelClasses.secondaryHeading}`]: {
        fontSize: theme.typography.pxToRem(15),
        color: theme.palette.text.secondary,
    },
    [`& .${AccordionFormPanelClasses.detail}`]: {
        alignItems: 'flex-start',
        display: 'flex',
        flexDirection: 'column',
    },
}));
