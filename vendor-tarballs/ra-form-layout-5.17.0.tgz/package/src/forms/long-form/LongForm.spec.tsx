/* eslint-disable jest/expect-expect */
import * as React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import {
    AccessControl,
    AccessControlOnSectionsOnly,
    Basic,
} from '../../../stories/longForm.stories';

describe('LongForm', () => {
    const listItemSelector = { selector: 'li' };
    const headerSelector = { selector: 'h4' };

    it('should render children of all sections', async () => {
        render(<Basic />);

        const firstName = (await screen.findByLabelText(
            /First name/
        )) as HTMLInputElement;
        expect(firstName.value).toBe('Alan');
        const occupation = (
            await screen.findAllByLabelText(/Name/)
        )[0] as HTMLInputElement;
        expect(occupation.value).toBe('Construction manager');
        const acceptEmails = (await screen.findByLabelText(
            'Accepts emails from partners'
        )) as HTMLInputElement;
        expect(acceptEmails.value).toBe('on');
    });

    it('should render all section headers', async () => {
        render(<Basic />);

        await screen.findByText('Identity', headerSelector);
        await screen.findByText('Occupations', headerSelector);
        await screen.findByText('Preferences', headerSelector);
    });

    it('should render TOC', async () => {
        render(<Basic />);

        await screen.findByText('Identity', listItemSelector);
        await screen.findByText('Occupations', listItemSelector);
        await screen.findByText('Preferences', listItemSelector);
    });

    it('should scroll to the relevant section when clicking TOC item', async () => {
        const scrollToSpy = jest.fn();
        global.scrollTo = scrollToSpy;
        render(<Basic />);

        const tocListItem = await screen.findByText(
            'Occupations',
            listItemSelector
        );
        fireEvent.click(tocListItem);
        expect(scrollToSpy).toHaveBeenCalledTimes(1); // Actual positions in px are not supported so we can't test much more than this

        scrollToSpy.mockClear();
    });

    it('should apply access control to the sections if enableAccessControl is true', async () => {
        const { rerender } = render(
            <AccessControl
                canAccessBornInput={false}
                canAccessPreferences={false}
            />
        );

        await screen.findByText('Identity', listItemSelector);
        await screen.findByText('Identity', headerSelector);
        expect(screen.queryByLabelText('born *')).toBeNull();

        await screen.findByText('Occupations', listItemSelector);
        await screen.findByText('Occupations', headerSelector);
        expect(screen.queryByText('Preferences', listItemSelector)).toBeNull();
        expect(screen.queryByText('Preferences', headerSelector)).toBeNull();

        rerender(
            <AccessControl
                canAccessBornInput={true}
                canAccessPreferences={true}
            />
        );
        await screen.findByText('Identity', listItemSelector);
        await screen.findByText('Identity', headerSelector);
        await screen.findByLabelText('born *');
        await screen.findByText('Occupations', listItemSelector);
        await screen.findByText('Occupations', headerSelector);
        await screen.findByText('Preferences', listItemSelector);
        await screen.findByText('Preferences', headerSelector);
    });
    it('should apply access control only to the sections if enableAccessControl is true but is overridden on sections', async () => {
        const { rerender } = render(
            <AccessControlOnSectionsOnly
                canAccessBornInput={false}
                canAccessPreferences={false}
            />
        );

        await screen.findByText('Identity', listItemSelector, {
            timeout: 4000,
        });
        await screen.findByText('Identity', headerSelector);
        // Should be displayed even though the permission would return false if checked as
        // the sections have enableAccessControl set to false
        await screen.findByLabelText('born *');
        await screen.findByText('Occupations', listItemSelector);
        await screen.findByText('Occupations', headerSelector);
        expect(screen.queryByText('Preferences', listItemSelector)).toBeNull();
        expect(screen.queryByText('Preferences', headerSelector)).toBeNull();

        rerender(
            <AccessControlOnSectionsOnly
                canAccessBornInput={false}
                canAccessPreferences={true}
            />
        );
        await screen.findByText('Identity', listItemSelector);
        await screen.findByText('Identity', headerSelector);
        // Should be displayed even though the permission would return false if checked as
        // the sections have enableAccessControl set to false
        await screen.findByLabelText('born *');
        await screen.findByText('Occupations', listItemSelector);
        await screen.findByText('Occupations', headerSelector);
        await screen.findByText('Preferences', listItemSelector);
        await screen.findByText('Preferences', headerSelector);
    }, 10000);
});
