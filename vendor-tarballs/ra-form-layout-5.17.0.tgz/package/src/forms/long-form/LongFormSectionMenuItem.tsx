import * as React from 'react';
import { useTranslate, useFormGroup, useEvent } from 'react-admin';
import { MenuItem, MenuItemProps } from '@mui/material';
import { LongFormViewClasses } from './LongFormView';

export const LongFormSectionMenuItem = (
    props: MenuItemProps & {
        cardinality?: number;
        index: number;
        name: string;
        sectionRefs: React.RefObject<(HTMLElement | undefined)[]>;
    }
) => {
    const { cardinality, index, name, sectionRefs, ...rest } = props;
    const translate = useTranslate();
    const { isValid } = useFormGroup(name);
    const handleClick = useEvent(() => {
        if (sectionRefs.current && sectionRefs.current[index]) {
            window.scrollTo(0, sectionRefs.current[index].offsetTop - 60);
        }
    });

    return (
        <MenuItem
            {...rest}
            onClick={handleClick}
            className={!isValid ? LongFormViewClasses.error : ''}
        >
            {translate(name, {
                _: name,
            })}
            {cardinality ? ` (${cardinality})` : null}
        </MenuItem>
    );
};
