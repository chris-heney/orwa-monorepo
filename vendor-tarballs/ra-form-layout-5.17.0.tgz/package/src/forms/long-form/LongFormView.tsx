import * as React from 'react';
import {
    Children,
    cloneElement,
    isValidElement,
    ReactElement,
    ReactNode,
    useRef,
} from 'react';
import { Loading, Toolbar, useResourceContext } from 'react-admin';
import { Card, CardContent, MenuList, SxProps } from '@mui/material';
import { styled } from '@mui/material/styles';
import {
    useAuthorizedChildren,
    UseAuthorizedChildrenFilterChildren,
    UseAuthorizedChildrenGetResourceKey,
} from '@react-admin/ra-core-ee';

import { useScrollSpy } from './useScrollSpy';
import { LongFormSectionProps } from './LongFormSection';
import { LongFormSectionMenuItem } from './LongFormSectionMenuItem';

/**
 * Form layout for long forms.
 *
 * Renders a fixed table of contents and toolbar, as well as section headers.
 * Expects `<LongForm.Section>` as children, each having a label.
 *
 * @example
 * import { LongForm } from '@react-admin/ra-form-layout';
 *
 * const CustomerEdit = () => (
 *     <Edit component="div">
 *         <LongForm>
 *             <LongForm.Section label="Identity">
 *                 <Labeled label="id">
 *                     <TextField source="id" />
 *                 </Labeled>
 *                 <TextInput source="first_name" validate={required()} />
 *                 <TextInput source="last_name" validate={required()} />
 *                 <DateInput source="dob" label="born" validate={required()} />
 *                 <SelectInput source="sex" choices={sexChoices} />
 *             </LongForm.Section>
 *             <LongForm.Section label="Occupations">
 *                 <ArrayInput source="occupations" label="">
 *                     <SimpleFormIterator>
 *                         <TextInput source="name" validate={required()} />
 *                         <DateInput source="from" validate={required()} />
 *                         <DateInput source="to" />
 *                     </SimpleFormIterator>
 *                 </ArrayInput>
 *             </LongForm.Section>
 *             <LongForm.Section label="Preferences">
 *                 <SelectInput
 *                     source="language"
 *                     choices={languageChoices}
 *                     defaultValue="en"
 *                 />
 *                 <BooleanInput source="dark_theme" />
 *                 <BooleanInput source="accepts_emails_from_partners" />
 *             </LongForm.Section>
 *         </LongForm>
 *     </Edit>
 * );
 */
export const LongFormView = ({
    authorizationError = null,
    children,
    enableAccessControl = false,
    loading = DefaultLoading,
    sx,
    toolbar,
}: LongFormViewProps) => {
    const { authorizedChildren, isPending, error } = useAuthorizedChildren({
        children,
        action: 'write',
        getResourceKey,
        filterChildren,
        enabled: enableAccessControl,
    });
    // section refs allow to build the table of contents automatically
    const nbSections = Children.count(authorizedChildren);
    const sectionRefs = useRef<(HTMLElement | undefined)[]>(
        new Array(nbSections)
    );
    const sectionsSignature = useRef<string | undefined>(undefined);
    const resource = useResourceContext();

    React.useEffect(() => {
        if (!enableAccessControl) return;
        if (!authorizedChildren) return;
        // We only want to reset the section refs when the children actually change
        // To ensure that, we compute a signature of the children and compare it to the previous one
        const newSectionSignature = Children.map(authorizedChildren, child =>
            isValidElement(child) ? getResourceKey(child, resource ?? '') : ''
        )?.join();

        if (
            sectionsSignature.current &&
            sectionsSignature.current === newSectionSignature
        )
            return;

        sectionsSignature.current = newSectionSignature;
        const newNbSections = Children.count(authorizedChildren);
        // To avoid losing already set refs, we only add new ones if necessary
        if (newNbSections > sectionRefs.current.length) {
            sectionRefs.current.push(undefined);
        }
    }, [authorizedChildren, enableAccessControl, resource]);

    // track the scroll to highlight the current section
    const activeSection = useScrollSpy({
        sectionElements: sectionRefs.current,
        offsetPx: -80,
    });

    if (error) {
        return authorizationError;
    }

    if (enableAccessControl && isPending) {
        return loading;
    }

    return (
        <Root sx={sx} className={LongFormViewClasses.root}>
            <Card className={LongFormViewClasses.toc}>
                <MenuList>
                    {Children.map(
                        authorizedChildren,
                        (formSection, index: number) =>
                            isValidElement(formSection) ? (
                                <LongFormSectionMenuItem
                                    key={index}
                                    selected={activeSection === index}
                                    name={
                                        (
                                            formSection as ReactElement<LongFormSectionProps>
                                        ).props.label
                                    }
                                    index={index}
                                    cardinality={
                                        (
                                            formSection as ReactElement<LongFormSectionProps>
                                        ).props.cardinality
                                    }
                                    sectionRefs={sectionRefs}
                                />
                            ) : null
                    )}
                </MenuList>
            </Card>
            <Card className={LongFormViewClasses.main}>
                <CardContent>
                    {Children.map(
                        authorizedChildren,
                        (formSection, index: number) =>
                            isValidElement<LongFormSectionProps>(formSection)
                                ? cloneElement<any>(formSection, {
                                      ref: ref => {
                                          if (ref == null) {
                                              return;
                                          }
                                          sectionRefs.current[index] = ref;
                                      },
                                      key: index,
                                      enableAccessControl:
                                          formSection.props
                                              .enableAccessControl ??
                                          enableAccessControl,
                                  })
                                : null
                    )}
                </CardContent>
                {toolbar ? (
                    cloneElement<any>(toolbar, {
                        className: LongFormViewClasses.toolbar,
                    })
                ) : (
                    <Toolbar className={LongFormViewClasses.toolbar} />
                )}
            </Card>
        </Root>
    );
};

const DefaultLoading = <Loading />;
const getResourceKey: UseAuthorizedChildrenGetResourceKey = (
    child,
    resource
) => {
    return `${resource}.section.${child.props.id ?? child.props.label}`;
};
const filterChildren: UseAuthorizedChildrenFilterChildren = child => {
    if (child.props.id == null && child.props.label == null) {
        if (process.env.NODE_ENV === 'development') {
            console.warn(
                `You enabled access control on the LongForm but didn't provide an id nor a label to its sections. Access control cannot be enforced on some sections.`
            );
        }
        return false;
    }
    return true;
};

export interface LongFormViewProps {
    authorizationError?: ReactNode;
    children?: ReactNode;
    className?: string;
    enableAccessControl?: boolean;
    loading?: ReactNode;
    sx?: SxProps;
    toolbar?: ReactElement<any>;
}

const PREFIX = 'RaLongForm';

export const LongFormViewClasses = {
    root: `${PREFIX}-root`,
    toc: `${PREFIX}-toc`,
    main: `${PREFIX}-main`,
    toolbar: `${PREFIX}-toolbar`,
    error: `${PREFIX}-error`,
};

const Root = styled('div', {
    name: PREFIX,
    overridesResolver: (props: any, styles) => styles.root,
})(({ theme }) => ({
    [`& .${LongFormViewClasses.toc}`]: { position: 'fixed', width: 200 },
    [`& .${LongFormViewClasses.main}`]: {
        marginLeft: '220px',
        overflow: 'visible',
    },
    [`& .${LongFormViewClasses.toolbar}`]: {
        position: 'sticky',
        bottom: 0,
        zIndex: 2,
    },
    [`& .${LongFormViewClasses.error}`]: {
        color: theme.palette.error.main,
    },
}));
