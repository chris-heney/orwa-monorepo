import * as React from 'react';
import {
    Admin,
    Button,
    Resource,
    TextInput,
    DateInput,
    SelectInput,
    required,
    DateField,
    Edit,
    SelectField,
    SimpleForm,
    DataTable,
    List,
    TestMemoryRouter,
    ReferenceManyField,
} from 'react-admin';

import { EditDialog } from './';

import { sexChoices, getDataProvider } from '../../../stories/common';

const CustomerList = () => (
    <>
        <List sort={{ field: 'id', order: 'DESC' }}>
            <DataTable rowClick="edit">
                <DataTable.Col source="id" />
                <DataTable.Col source="first_name" />
                <DataTable.Col source="last_name" />
                <DataTable.Col label="born">
                    <DateField source="dob" label="born" />
                </DataTable.Col>
                <DataTable.Col source="sex">
                    <SelectField source="sex" choices={sexChoices} />
                </DataTable.Col>
            </DataTable>
        </List>
        <EditDialog fullWidth maxWidth="md">
            <CustomerForm />
        </EditDialog>
    </>
);

const CustomerForm = () => (
    <SimpleForm>
        <TextInput source="first_name" validate={required()} />
        <TextInput source="last_name" validate={required()} />
        <DateInput source="dob" label="born" validate={required()} />
        <SelectInput source="sex" choices={sexChoices} />
    </SimpleForm>
);

export const Basic = () => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()}>
            <Resource name="customers" list={CustomerList} hasCreate />
        </Admin>
    </TestMemoryRouter>
);

const EmployerList = () => (
    <List empty={false}>
        <DataTable rowClick="edit">
            <DataTable.NumberCol source="id" />
            <DataTable.Col source="name" />
            <DataTable.Col source="address" />
            <DataTable.Col source="city" />
        </DataTable>
    </List>
);

const EmployerEdit = () => {
    const [record, setRecord] = React.useState<any>(undefined);
    const closeDialog = React.useCallback(() => {
        setRecord(undefined);
    }, []);
    return (
        <Edit>
            <SimpleForm>
                <TextInput source="name" validate={required()} />
                <TextInput source="address" validate={required()} />
                <TextInput source="city" validate={required()} />
                <ReferenceManyField
                    label="Customers"
                    reference="customers"
                    target="employer_id"
                >
                    <DataTable>
                        <DataTable.Col source="id" />
                        <DataTable.Col source="first_name" />
                        <DataTable.Col source="last_name" />
                        <DataTable.Col label="born">
                            <DateField source="dob" label="born" />
                        </DataTable.Col>
                        <DataTable.Col source="sex">
                            <SelectField source="sex" choices={sexChoices} />
                        </DataTable.Col>
                        <DataTable.Col
                            render={record => (
                                <Button
                                    label="Edit customer"
                                    onClick={() => setRecord(record)}
                                />
                            )}
                        />
                    </DataTable>
                </ReferenceManyField>
                <EditDialog
                    fullWidth
                    maxWidth="md"
                    record={record}
                    isOpen={!!record}
                    close={closeDialog}
                    resource="customers"
                >
                    <CustomerForm />
                </EditDialog>
            </SimpleForm>
        </Edit>
    );
};

export const Standalone = () => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()}>
            <Resource
                name="employers"
                list={EmployerList}
                edit={EmployerEdit}
            />
        </Admin>
    </TestMemoryRouter>
);

export default {
    title: 'ra-form-layout/DialogForm/EditDialog',
};
