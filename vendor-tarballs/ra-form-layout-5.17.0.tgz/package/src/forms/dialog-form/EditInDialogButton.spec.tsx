import {
    fireEvent,
    render,
    screen,
    waitFor,
    within,
} from '@testing-library/react';
import React from 'react';
import { StandaloneInSimpleForm } from '../../../stories/dialogForm.stories';
import {
    AccessControl,
    Basic,
    OnClick,
    WarnWhenUnsavedChanges,
    WithCustomTitle,
} from './EditInDialogButton.stories';

describe('EditInDialogButton', () => {
    it('should open the dialog on click on the button, and close it on click on the close button', async () => {
        render(<StandaloneInSimpleForm />);
        fireEvent.click(await screen.findByText('Acme'));
        await screen.findByText('Employer Acme');
        fireEvent.click((await screen.findAllByText('Edit'))[0]);
        await screen.findByText('Customer #4');
        const dialog = screen.getByTestId('edit-dialog');
        within(dialog).getByLabelText('First name *');
        within(dialog).getByDisplayValue('Anita');
        within(dialog).getByLabelText('Last name *');
        within(dialog).getByDisplayValue('Johnson');
        fireEvent.click(screen.getByLabelText('Close'));
        await waitFor(() => {
            expect(screen.queryByText('Customer #4')).toBeNull();
        });
    });

    it('should open the dialog on click on the button, and close it on click on the save button', async () => {
        render(<StandaloneInSimpleForm />);
        fireEvent.click(await screen.findByText('Acme'));
        await screen.findByText('Employer Acme');
        fireEvent.click((await screen.findAllByText('Edit'))[0]);
        await screen.findByText('Customer #4');
        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'Roger' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'Moore' },
        });
        fireEvent.click(screen.getByText('Informations'));
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1927-10-14' },
        });
        fireEvent.click(screen.getAllByText('Save')[1]); // we need the 2nd save button (the one inside the dialog)
        await waitFor(() => {
            expect(screen.queryByText('Customer #4')).toBeNull();
        });
        await screen.findByText('Roger');
        await screen.findByText('Moore');
    });

    it('should stop propagation of the click event and not handle parent event', async () => {
        render(<Basic />);

        const editButtons = await screen.findAllByText('Edit');
        fireEvent.click(editButtons[0]);
        await screen.findByText('Employer Acme');
        fireEvent.click(screen.getByLabelText('Name'));
        expect(screen.queryByText('Show Acmes')).toBeNull();
        fireEvent.click(screen.getByLabelText('Close'));
        expect(screen.queryByText('Show Acmes')).toBeNull();

        fireEvent.click(editButtons[0]);
        await screen.findByText('Employer Acme');
        const backdrop = screen.getByLabelText('backdrop');
        fireEvent.click(backdrop);
        expect(screen.queryByText('Show Acmes')).toBeNull();

        fireEvent.click(editButtons[0]);
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'Skynet' },
        });
        fireEvent.click(screen.getByText('Save'));
        expect(screen.queryByText('Show Acmes')).toBeNull();
    });

    it('should accept an "onClick" in the "ButtonProps"\'s prop', async () => {
        const onClick = jest.fn();
        render(<OnClick onClick={onClick} />);

        const editButtons = await screen.findAllByText('Edit');
        fireEvent.click(editButtons[0]);

        expect(onClick).toHaveBeenCalled();
    });

    it.each([
        ['component', 'Edit employer Acme'],
        ['componentWithContext', 'Employer Acme'],
        ['string', 'Edit employer'],
        ['undefined', 'Employer Acme'],
    ])(
        'should display custom title with title of type %s',
        async (titleType, expectedTitle) => {
            render(
                <WithCustomTitle
                    title={titleType as 'component' | 'string' | 'undefined'}
                />
            );
            fireEvent.click((await screen.findAllByText('Edit'))[0]);

            await waitFor(() => {
                expect(screen.queryByText(expectedTitle)).not.toBeNull();
            });
        }
    );
    it('should not display title if title is null', async () => {
        render(<WithCustomTitle title="null" />);
        fireEvent.click((await screen.findAllByText('Edit'))[0]);

        await screen.findByLabelText('Name');
        expect(screen.queryByText('Employer Acme')).toBeNull();
    });

    describe('WarnWhenUnsavedChanges', () => {
        it('should close the dialog when clicking the close button when the form is pristine', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.click(screen.getByLabelText('Close'));
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            expect(window.confirm).not.toHaveBeenCalled();
        });

        it('should close the dialog when clicking outside the dialog when the form is pristine', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            const backdrop = screen.getByLabelText('backdrop');
            fireEvent.click(backdrop);
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            expect(window.confirm).not.toHaveBeenCalled();
        });

        it('should not close the dialog when clicking the close button when the form is dirty and user clicks Cancel', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Close'));
            // wait for a bit
            await new Promise(res => setTimeout(res, 50));
            expect(window.confirm).toHaveBeenCalled();
            // dialog should still be open
            screen.getByTestId('edit-dialog');
        });

        it('should not close the dialog when clicking outside the dialog when the form is dirty and user clicks Cancel', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            const backdrop = screen.getByLabelText('backdrop');
            fireEvent.click(backdrop);
            // wait for a bit
            await new Promise(res => setTimeout(res, 50));
            expect(window.confirm).toHaveBeenCalled();
            // dialog should still be open
            screen.getByTestId('edit-dialog');
        });

        it('should close the dialog when clicking the close button when the form is dirty and user clicks Ok', async () => {
            window.confirm = jest.fn().mockReturnValue(true);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Close'));
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            expect(window.confirm).toHaveBeenCalled();
        });

        it('should close the dialog when clicking outside the dialog when the form is dirty and user clicks Ok', async () => {
            window.confirm = jest.fn().mockReturnValue(true);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Close'));
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            expect(window.confirm).toHaveBeenCalled();
        });

        it('should close the dialog when clicking the Save button in undoable mode', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges mutationMode="undoable" />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Save'));
            await screen.findByText('Element updated');
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            // window.confirm should not have been called
            expect(window.confirm).not.toHaveBeenCalled();
        });

        it('should close the dialog when clicking the Save button in optimistic mode', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges mutationMode="optimistic" />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Save'));
            await screen.findByText('Element updated');
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            // window.confirm should not have been called
            expect(window.confirm).not.toHaveBeenCalled();
        });

        it('should close the dialog when clicking the Save button in pessimistic mode', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges mutationMode="pessimistic" />);
            await screen.findByText('Acme');
            fireEvent.click((await screen.findAllByText('Edit'))[0]);
            await screen.findByText('Employer Acme');
            screen.getByTestId('edit-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Save'));
            await screen.findByText('Element updated');
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('edit-dialog')).toBeNull();
            });
            // window.confirm should not have been called
            expect(window.confirm).not.toHaveBeenCalled();
        });
    });

    describe('Access Control', () => {
        it('should not be displayed if the user does not have edit access to the resource', async () => {
            const { rerender } = render(
                <AccessControl
                    authorizedActionsEmployers={['list']}
                    authorizedActionsCustomers={[]}
                />
            );
            await waitFor(() => {
                expect(screen.queryByText('Edit')).toBeNull();
            });

            rerender(
                <AccessControl
                    authorizedActionsEmployers={['list', 'edit']}
                    authorizedActionsCustomers={[]}
                />
            );
            await screen.findByText('Edit');
        });
    });

    it('should not be displayed if the user does not have edit access to the resource passed by props', async () => {
        const { rerender } = render(
            <AccessControl
                authorizedActionsEmployers={['list', 'edit']}
                authorizedActionsCustomers={[]}
            />
        );
        fireEvent.click((await screen.findAllByText('Edit'))[0]);
        await screen.findByText('JOHNSON Anita');
        expect(screen.queryByText('Edit customer')).toBeNull();

        rerender(
            <AccessControl
                authorizedActionsEmployers={['list', 'edit']}
                authorizedActionsCustomers={['edit']}
            />
        );
        fireEvent.click((await screen.findAllByText('Edit'))[0]);
        await screen.findByText('JOHNSON Anita');
        expect(screen.getAllByText('Edit customer')).toHaveLength(2);
    });
});
