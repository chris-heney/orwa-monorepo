import { useEvent, useTranslate } from 'react-admin';
import { useFormDialogContext } from './useFormDialogContext';
import { useFormContext } from 'react-hook-form';
import { useEffect } from 'react';

export const WarnWhenUnsavedChangesInDialog = () => {
    const translate = useTranslate();
    const context = useFormDialogContext();
    const formContext = useFormContext();
    if (!context?.registerOnCloseCallback) {
        throw new Error(
            'The WarnWhenUnsavedChangesInDialog component must be used inside a FormDialogContext'
        );
    }
    if (!formContext) {
        throw new Error(
            'The WarnWhenUnsavedChangesInDialog component must be used inside a FormContext'
        );
    }

    const {
        formState: { dirtyFields, isSubmitSuccessful },
    } = formContext;
    const isDirty = Object.keys(dirtyFields).length > 0;

    const onCloseCallback = useEvent(() => {
        let shouldProceed = true;
        const shouldNotify = isDirty && !isSubmitSuccessful;
        if (shouldNotify) {
            shouldProceed = window.confirm(
                translate('ra.message.unsaved_changes')
            );
        }
        return shouldProceed;
    });

    // Register the callback to be called when the dialog is closed
    useEffect(() => {
        context.registerOnCloseCallback!(onCloseCallback);
        // unregister on unmount
        return () => {
            context.registerOnCloseCallback!(undefined);
        };
    }, [context, onCloseCallback]);

    return null;
};
