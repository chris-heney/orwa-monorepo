import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import React from 'react';

import { StandaloneInSimpleForm } from '../../../stories/dialogForm.stories';
import {
    AccessControl,
    OnClick,
    WarnWhenUnsavedChanges,
    WithCustomTitle,
} from './CreateInDialogButton.stories';

describe('CreateInDialogButton', () => {
    it('should open the dialog on click on the button, and close it on click on the close button', async () => {
        render(<StandaloneInSimpleForm />);
        fireEvent.click(await screen.findByText('Acme'));
        await screen.findByText('Employer Acme');
        fireEvent.click(await screen.findByLabelText('Create'));
        await screen.findByText('Create Customer');
        screen.getByLabelText('First name *');
        screen.getByLabelText('Last name *');
        fireEvent.click(screen.getByLabelText('Close'));
        await waitFor(() => {
            expect(screen.queryByText('Create Customer')).toBeNull();
        });
    });

    it('should open the dialog on click on the button, and close it on click on the save button', async () => {
        render(<StandaloneInSimpleForm />);
        fireEvent.click(await screen.findByText('Acme'));
        await screen.findByText('Employer Acme');
        fireEvent.click(await screen.findByLabelText('Create'));
        await screen.findByText('Create Customer');
        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'Roger' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'Moore' },
        });
        fireEvent.click(screen.getByText('Informations'));
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1927-10-14' },
        });
        fireEvent.click(screen.getAllByText('Save')[1]); // we need the 2nd save button (the one inside the dialog)
        await waitFor(() => {
            expect(screen.queryByText('Create Customer')).toBeNull();
        });
        await screen.findByText('Roger');
        await screen.findByText('Moore');
    });

    it('should accept an "onClick" in the "ButtonProps"\'s prop', async () => {
        const onClick = jest.fn();
        render(<OnClick onClick={onClick} />);

        fireEvent.click(await screen.findByText('Create'));

        expect(onClick).toHaveBeenCalled();
    });

    it.each([
        ['component', 'Create a new employer'],
        ['componentWithContext', 'Create Employer'],
        ['string', 'Create employer'],
        ['undefined', 'Create Employer'],
    ])(
        'should display custom title with title of type %s',
        async (titleType, expectedTitle) => {
            render(<WithCustomTitle title={titleType} />);
            fireEvent.click(await screen.findByText('Create'));

            await waitFor(() => {
                expect(screen.queryByText(expectedTitle)).not.toBeNull();
            });
        }
    );
    it('should not display title if title is null', async () => {
        render(<WithCustomTitle title="null" />);
        fireEvent.click(await screen.findByText('Create'));

        await screen.findByLabelText('Name');
        expect(screen.queryByText('Create Employer')).toBeNull();
    });

    describe('WarnWhenUnsavedChanges', () => {
        it('should close the dialog when clicking the close button when the form is pristine', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            fireEvent.click(screen.getByLabelText('Close'));
            await waitFor(() => {
                expect(screen.queryByTestId('create-dialog')).toBeNull();
            });
            expect(window.confirm).not.toHaveBeenCalled();
        });

        it('should close the dialog when clicking outside the dialog when the form is pristine', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            const backdrop = screen.getByLabelText('backdrop');
            fireEvent.click(backdrop);
            await waitFor(() => {
                expect(screen.queryByTestId('create-dialog')).toBeNull();
            });
            expect(window.confirm).not.toHaveBeenCalled();
        });

        it('should not close the dialog when clicking the close button when the form is dirty and user clicks Cancel', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Close'));
            // wait for a bit
            await new Promise(res => setTimeout(res, 50));
            expect(window.confirm).toHaveBeenCalled();
            // dialog should still be open
            screen.getByTestId('create-dialog');
        });

        it('should not close the dialog when clicking outside the dialog when the form is dirty and user clicks Cancel', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            const backdrop = screen.getByLabelText('backdrop');
            fireEvent.click(backdrop);
            // wait for a bit
            await new Promise(res => setTimeout(res, 50));
            expect(window.confirm).toHaveBeenCalled();
            // dialog should still be open
            screen.getByTestId('create-dialog');
        });

        it('should close the dialog when clicking the close button when the form is dirty and user clicks Ok', async () => {
            window.confirm = jest.fn().mockReturnValue(true);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Close'));
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('create-dialog')).toBeNull();
            });
            expect(window.confirm).toHaveBeenCalled();
        });

        it('should close the dialog when clicking outside the dialog when the form is dirty and user clicks Ok', async () => {
            window.confirm = jest.fn().mockReturnValue(true);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Close'));
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('create-dialog')).toBeNull();
            });
            expect(window.confirm).toHaveBeenCalled();
        });

        it('should close the dialog when clicking the Save button', async () => {
            window.confirm = jest.fn().mockReturnValue(false);
            render(<WarnWhenUnsavedChanges />);
            await screen.findByText('Acme');
            fireEvent.click(await screen.findByText('Create'));
            await screen.findByText('Create Employer');
            screen.getByTestId('create-dialog');
            fireEvent.change(await screen.findByLabelText('Name'), {
                target: { value: 'changed' },
            });
            fireEvent.click(screen.getByLabelText('Save'));
            await screen.findByText('Element created');
            // dialog should be closed
            await waitFor(() => {
                expect(screen.queryByTestId('create-dialog')).toBeNull();
            });
            // window.confirm should not have been called
            expect(window.confirm).not.toHaveBeenCalled();
        });
    });

    describe('Access Control', () => {
        it('should not be displayed if the user does not have create access to the resource', async () => {
            const { rerender } = render(
                <AccessControl
                    authorizedActionsEmployers={['list']}
                    authorizedActionsCustomers={[]}
                />
            );
            await waitFor(() => {
                expect(screen.queryByText('Create')).toBeNull();
            });

            rerender(
                <AccessControl
                    authorizedActionsEmployers={['list', 'create']}
                    authorizedActionsCustomers={[]}
                />
            );
            await screen.findByText('Create');
        });

        it('should not be displayed if the user does not have create access to the resource passed by props', async () => {
            const { rerender } = render(
                <AccessControl
                    authorizedActionsEmployers={['list', 'create', 'edit']}
                    authorizedActionsCustomers={[]}
                />
            );
            fireEvent.click(await screen.findByText('Acme'));
            await screen.findByText('JOHNSON Anita');
            expect(screen.queryByText('Create')).toBeNull();

            rerender(
                <AccessControl
                    authorizedActionsEmployers={['list', 'create', 'edit']}
                    authorizedActionsCustomers={['create']}
                />
            );
            await screen.findByText('JOHNSON Anita');
            expect(screen.getByText('Create')).not.toBeNull();
        });
    });
});
