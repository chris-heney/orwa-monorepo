import {
    fireEvent,
    render,
    screen,
    waitFor,
    within,
} from '@testing-library/react';
import React from 'react';
import { StandaloneInSimpleForm } from '../../../stories/dialogForm.stories';
import {
    AccessControl,
    Basic,
    OnClick,
    WithCustomTitle,
} from './ShowInDialogButton.stories';

describe('ShowInDialogButton', () => {
    it('should open the dialog on click on the button, and close it on click on the close button', async () => {
        render(<StandaloneInSimpleForm />);
        fireEvent.click(await screen.findByText('Acme'));
        await screen.findByText('Employer Acme');
        fireEvent.click((await screen.findAllByLabelText('Show'))[0]);
        await screen.findByText('Customer #4');
        const dialog = screen.getByTestId('show-dialog');
        within(dialog).getByText('First name');
        within(dialog).getByText('Anita');
        within(dialog).getByText('Last name');
        within(dialog).getByText('Johnson');
        fireEvent.click(screen.getByText('Informations'));
        within(dialog).getByText('born');
        within(dialog).getByText(new Date('1942-07-13').toLocaleDateString());
        within(dialog).getByText('Sex');
        within(dialog).getByText('Female');
        fireEvent.click(screen.getByLabelText('Close'));
        await waitFor(() => {
            expect(screen.queryByText('Customer #4')).toBeNull();
        });
    });

    it('should stop propagation of the click event and not handle parent event', async () => {
        render(<Basic />);

        const editButtons = await screen.findAllByText('Show');
        fireEvent.click(editButtons[0]);
        fireEvent.click(await screen.findByText('Employer Acme'));
        expect(screen.queryByText('Edit Acmes')).toBeNull();
        fireEvent.click(screen.getByLabelText('Close'));
        expect(screen.queryByText('Edit Acmes')).toBeNull();

        fireEvent.click(editButtons[0]);
        await screen.findByText('Employer Acme');
        const backdrop = screen.getByLabelText('backdrop');
        fireEvent.click(backdrop);
        expect(screen.queryByText('Edit Acmes')).toBeNull();
    });

    it('should accept an "onClick" in the "ButtonProps"\'s prop', async () => {
        const onClick = jest.fn();
        render(<OnClick onClick={onClick} />);

        const showButtons = await screen.findAllByText('Show');
        fireEvent.click(showButtons[0]);

        expect(onClick).toHaveBeenCalled();
    });

    it.each([
        ['component', 'Show employer Acme'],
        ['string', 'Show employer'],
        ['undefined', 'Employer Acme'],
    ])(
        'should display custom title with title of type %s',
        async (titleType, expectedTitle) => {
            render(
                <WithCustomTitle
                    title={titleType as 'component' | 'string' | 'undefined'}
                />
            );
            fireEvent.click((await screen.findAllByText('Show'))[0]);

            await waitFor(() => {
                expect(screen.queryByText(expectedTitle)).not.toBeNull();
            });
        }
    );
    it('should not display title if title is null', async () => {
        render(<WithCustomTitle title="null" />);
        fireEvent.click((await screen.findAllByText('Show'))[0]);

        // Wait for the backdrop to appear, meaning the dialog is open
        await screen.findByLabelText('backdrop');
        expect(screen.queryByText('Employer Acme')).toBeNull();
    });

    describe('Access Control', () => {
        it('should not be displayed if the user does not have show access to the resource', async () => {
            const { rerender } = render(
                <AccessControl
                    authorizedActionsEmployers={['list']}
                    authorizedActionsCustomers={[]}
                />
            );
            await waitFor(() => {
                expect(screen.queryByText('Show')).toBeNull();
            });

            rerender(
                <AccessControl
                    authorizedActionsEmployers={['list', 'show']}
                    authorizedActionsCustomers={[]}
                />
            );
            await screen.findByText('Show');
        });

        it('should not be displayed if the user does not have show access to the resource passed by props', async () => {
            const { rerender } = render(
                <AccessControl
                    authorizedActionsEmployers={['list', 'show']}
                    authorizedActionsCustomers={[]}
                />
            );
            fireEvent.click((await screen.findAllByText('Show'))[0]);
            await screen.findByText('JOHNSON Anita');
            expect(screen.queryByText('Show customer')).toBeNull();

            rerender(
                <AccessControl
                    authorizedActionsEmployers={['list', 'show']}
                    authorizedActionsCustomers={['show']}
                />
            );
            fireEvent.click((await screen.findAllByText('Show'))[0]);
            await screen.findByText('JOHNSON Anita');
            expect(screen.getAllByText('Show customer')).toHaveLength(2);
        });
    });
});
