import * as React from 'react';
import {
    DataTable,
    ReferenceManyField,
    Edit,
    SimpleForm,
    TextInput,
    Admin,
    Resource,
    WithRecord,
    ListGuesser,
    List,
    required,
    EditGuesser,
    useNotify,
    TestMemoryRouter,
    useCreateContext,
    ExportButton,
    DateField,
    SelectField,
    SelectInput,
    DateInput,
    useRecordContext,
} from 'react-admin';
import { Stack, Typography } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import i18nProvider from '../../../stories/i18nProvider';
import { getDataProvider } from '../../../stories/common';
import { CreateInDialogButton } from './CreateInDialogButton';
import { WarnWhenUnsavedChangesInDialog } from './WarnWhenUnsavedChangesInDialog';

export default {
    title: 'ra-form-layout/DialogForm/CreateInDialogButton',
};

const EmployerList = () => (
    <List
        actions={
            <Stack direction="row">
                <CreateInDialogButton>
                    <SimpleForm>
                        <TextInput source="name" />
                        <TextInput source="address" />
                        <TextInput source="city" />
                    </SimpleForm>
                </CreateInDialogButton>
                <ExportButton />
            </Stack>
        }
    >
        <DataTable rowClick="edit">
            <DataTable.Col source="name" />
            <DataTable.Col source="address" />
            <DataTable.Col source="city" />
        </DataTable>
    </List>
);

export const Basic = () => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
            <Resource
                name="employers"
                list={EmployerList}
                edit={EditGuesser}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);

const CreateCustomersButton = () => {
    const record = useRecordContext();
    return (
        <CreateInDialogButton
            record={{ employer_id: record?.id }}
            resource="customers"
        >
            <SimpleForm>
                <TextInput source="first_name" />
                <TextInput source="last_name" />
                <DateInput source="dob" />
                <SelectInput
                    source="sex"
                    choices={[
                        { id: 'male', name: 'Male' },
                        { id: 'female', name: 'Female' },
                    ]}
                />

                <TextInput source="employer_id" readOnly />
            </SimpleForm>
        </CreateInDialogButton>
    );
};

const EmployerEdit = () => (
    <Edit>
        <SimpleForm>
            <TextInput source="id" readOnly />
            <TextInput source="name" />
            <TextInput source="address" />
            <TextInput source="city" />
            <Typography variant="h6" gutterBottom>
                Customers
            </Typography>
            <ReferenceManyField reference="customers" target="employer_id">
                <DataTable>
                    <DataTable.Col label="Name">
                        <WithRecord
                            label="Name"
                            render={record =>
                                `${record.last_name.toUpperCase()} ${record.first_name}`
                            }
                        />
                    </DataTable.Col>
                    <DataTable.Col source="dob">
                        <DateField source="dob" />
                    </DataTable.Col>
                    <DataTable.Col source="sex">
                        <SelectField
                            source="sex"
                            choices={[
                                { id: 'male', name: 'Male' },
                                { id: 'female', name: 'Female' },
                            ]}
                        />
                    </DataTable.Col>
                </DataTable>
            </ReferenceManyField>
            <CreateCustomersButton />
        </SimpleForm>
    </Edit>
);

export const AccessControl = ({
    authorizedActionsEmployers,
    authorizedActionsCustomers,
}) => (
    <TestMemoryRouter>
        <Admin
            dataProvider={getDataProvider()}
            i18nProvider={i18nProvider}
            authProvider={{
                canAccess: ({ resource, action }) => {
                    if (resource === 'employers') {
                        return authorizedActionsEmployers.includes(action);
                    }
                    if (resource === 'customers') {
                        return authorizedActionsCustomers.includes(action);
                    }
                    return false;
                },
                checkAuth: () => Promise.resolve(),
                login: () => Promise.resolve(),
                logout: () => Promise.resolve(),
                checkError: () => Promise.resolve(),
                getIdentity: () =>
                    Promise.resolve({ id: 'user', fullName: 'John Doe' }),
            }}
            key={JSON.stringify({
                authorizedActionsEmployers,
                authorizedActionsCustomers,
            })}
        >
            <Resource
                name="employers"
                list={EmployerList}
                edit={EmployerEdit}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);
AccessControl.args = {
    authorizedActionsEmployers: ['show', 'list', 'edit'],
    authorizedActionsCustomers: [],
};
AccessControl.argTypes = {
    authorizedActionsEmployers: {
        name: 'Actions that are authorized for resource "employers"',
        options: ['list', 'edit', 'show', 'create'],
        control: { type: 'inline-check' },
    },
    authorizedActionsCustomers: {
        name: 'Actions that are authorized for resource "customers"',
        options: ['create'],
        control: { type: 'inline-check' },
    },
};

export const Transform = () => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
            <Resource
                name="employers"
                list={() => (
                    <List
                        actions={
                            <CreateInDialogButton
                                transform={record => ({
                                    ...record,
                                    name: record.name + '_transformed',
                                })}
                            >
                                <SimpleForm>
                                    <TextInput source="name" />
                                    <TextInput source="address" />
                                    <TextInput source="city" />
                                </SimpleForm>
                            </CreateInDialogButton>
                        }
                    >
                        <DataTable>
                            <DataTable.Col source="name" />
                            <DataTable.Col source="address" />
                            <DataTable.Col source="city" />
                        </DataTable>
                    </List>
                )}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);

export const OnClick = ({
    onClick = e => {
        // eslint-disable-next-line no-console
        console.log('ButtonProps.onClick', e);
    },
}) => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
            <Resource
                name="employers"
                list={() => (
                    <List
                        actions={
                            <CreateInDialogButton
                                ButtonProps={{
                                    variant: 'contained',
                                    onClick,
                                }}
                            >
                                <SimpleForm>
                                    <TextInput source="name" />
                                    <TextInput source="address" />
                                    <TextInput source="city" />
                                </SimpleForm>
                            </CreateInDialogButton>
                        }
                    >
                        <DataTable>
                            <DataTable.Col source="name" />
                            <DataTable.Col source="address" />
                            <DataTable.Col source="city" />
                        </DataTable>
                    </List>
                )}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);

export const InReferenceField = () => {
    return (
        <TestMemoryRouter>
            <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
                <Resource
                    name="employers"
                    list={ListGuesser}
                    edit={() => (
                        <Edit>
                            <SimpleForm>
                                <TextInput source="name" />
                                <TextInput source="address" />
                                <TextInput source="city" />
                                <ReferenceManyField
                                    target="employer_id"
                                    reference="customers"
                                >
                                    <WithRecord
                                        render={record => (
                                            <CreateInDialogButton
                                                record={{
                                                    employer_id: record.id,
                                                }}
                                            >
                                                <SimpleForm>
                                                    <TextInput source="first_name" />
                                                    <TextInput source="last_name" />
                                                </SimpleForm>
                                            </CreateInDialogButton>
                                        )}
                                    />
                                    <DataTable>
                                        <DataTable.Col source="first_name" />
                                        <DataTable.Col source="last_name" />
                                    </DataTable>
                                </ReferenceManyField>
                            </SimpleForm>
                        </Edit>
                    )}
                    recordRepresentation="name"
                />
                <Resource name="customers" list={ListGuesser} />
            </Admin>
        </TestMemoryRouter>
    );
};

export const InputValidation = () => {
    return (
        <TestMemoryRouter>
            <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
                <Resource
                    name="employers"
                    list={ListGuesser}
                    edit={() => (
                        <Edit>
                            <SimpleForm>
                                <TextInput source="name" />
                                <TextInput source="address" />
                                <TextInput source="city" />
                                <ReferenceManyField
                                    target="employer_id"
                                    reference="customers"
                                >
                                    <WithRecord
                                        render={record => (
                                            <CreateInDialogButton
                                                record={{
                                                    employer_id: record.id,
                                                }}
                                            >
                                                <SimpleForm>
                                                    <TextInput
                                                        source="first_name"
                                                        validate={[required()]}
                                                    />
                                                    <TextInput
                                                        source="last_name"
                                                        validate={[required()]}
                                                    />
                                                </SimpleForm>
                                            </CreateInDialogButton>
                                        )}
                                    />
                                    <DataTable>
                                        <DataTable.Col source="first_name" />
                                        <DataTable.Col source="last_name" />
                                    </DataTable>
                                </ReferenceManyField>
                            </SimpleForm>
                        </Edit>
                    )}
                    recordRepresentation="name"
                />
                <Resource name="customers" list={ListGuesser} />
            </Admin>
        </TestMemoryRouter>
    );
};

export const GlobalValidation = () => {
    return (
        <TestMemoryRouter>
            <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
                <Resource
                    name="employers"
                    list={ListGuesser}
                    edit={() => (
                        <Edit>
                            <SimpleForm>
                                <TextInput source="name" />
                                <TextInput source="address" />
                                <TextInput source="city" />
                                <ReferenceManyField
                                    target="employer_id"
                                    reference="customers"
                                >
                                    <WithRecord
                                        render={record => (
                                            <CreateInDialogButton
                                                record={{
                                                    employer_id: record.id,
                                                }}
                                            >
                                                <SimpleForm
                                                    validate={() => ({
                                                        first_name: 'not good',
                                                    })}
                                                >
                                                    <TextInput source="first_name" />
                                                    <TextInput source="last_name" />
                                                </SimpleForm>
                                            </CreateInDialogButton>
                                        )}
                                    />
                                    <DataTable>
                                        <DataTable.Col source="first_name" />
                                        <DataTable.Col source="last_name" />
                                    </DataTable>
                                </ReferenceManyField>
                            </SimpleForm>
                        </Edit>
                    )}
                    recordRepresentation="name"
                />
                <Resource name="customers" list={ListGuesser} />
            </Admin>
        </TestMemoryRouter>
    );
};

export const CustomMutationOptions = () => {
    return (
        <TestMemoryRouter>
            <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
                <Resource
                    name="employers"
                    list={CustomMutationOptionsList}
                    recordRepresentation="name"
                />
            </Admin>
        </TestMemoryRouter>
    );
};

const CustomMutationOptionsList = () => {
    const notify = useNotify();
    return (
        <List
            actions={
                <CreateInDialogButton
                    mutationOptions={{
                        onSuccess: () => {
                            notify('custom notification');
                        },
                    }}
                >
                    <SimpleForm>
                        <TextInput source="name" />
                        <TextInput source="address" />
                        <TextInput source="city" />
                    </SimpleForm>
                </CreateInDialogButton>
            }
        >
            <DataTable>
                <DataTable.Col source="name" />
                <DataTable.Col source="address" />
                <DataTable.Col source="city" />
            </DataTable>
        </List>
    );
};

export const WarnWhenUnsavedChanges = () => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
            <Resource
                name="employers"
                list={() => (
                    <List
                        actions={
                            <CreateInDialogButton
                                slotProps={{
                                    backdrop: {
                                        'aria-label': 'backdrop',
                                    },
                                }}
                            >
                                <SimpleForm>
                                    <TextInput source="name" />
                                    <TextInput source="address" />
                                    <TextInput source="city" />
                                    <WarnWhenUnsavedChangesInDialog />
                                </SimpleForm>
                            </CreateInDialogButton>
                        }
                    >
                        <DataTable>
                            <DataTable.Col source="name" />
                            <DataTable.Col source="address" />
                            <DataTable.Col source="city" />
                        </DataTable>
                    </List>
                )}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);

const CreateDialogTitle = () => {
    return <span>Create a new employer</span>;
};

const CreateDialogTitleWithContext = () => {
    const { defaultTitle } = useCreateContext();
    return (
        <Stack
            direction="row"
            sx={{
                gap: 1,
                alignItems: 'center',
            }}
        >
            <PeopleIcon />
            {defaultTitle}
        </Stack>
    );
};

const EmployerListWithTitle = (props: {
    title?:
        | 'component'
        | 'componentWithContext'
        | 'string'
        | 'null'
        | 'undefined';
}) => (
    <List
        actions={
            <CreateInDialogButton
                title={
                    props.title === 'undefined' ? undefined : props.title ===
                      'null' ? null : props.title === 'string' ? (
                        'Create employer'
                    ) : props.title === 'component' ? (
                        <CreateDialogTitle />
                    ) : (
                        <CreateDialogTitleWithContext />
                    )
                }
                fullWidth
                maxWidth="sm"
            >
                <SimpleForm>
                    <TextInput source="name" />
                    <TextInput source="address" />
                    <TextInput source="city" />
                </SimpleForm>
            </CreateInDialogButton>
        }
    >
        <DataTable rowClick="edit">
            <DataTable.Col source="name" />
            <DataTable.Col source="address" />
            <DataTable.Col source="city" />
        </DataTable>
    </List>
);

export const WithCustomTitle = props => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
            <Resource
                name="employers"
                list={<EmployerListWithTitle {...props} />}
                edit={EditGuesser}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);
WithCustomTitle.args = { title: 'component' };
WithCustomTitle.argTypes = {
    title: {
        options: [
            'component',
            'componentWithContext',
            'string',
            'null',
            'undefined',
        ],
        control: { type: 'inline-radio' },
    },
};
