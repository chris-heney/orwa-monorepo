import * as React from 'react';
import {
    SimpleForm,
    TextInput,
    Admin,
    Resource,
    List,
    DataTable,
    TextField,
    useNotify,
    ReferenceManyField,
    ListGuesser,
    Edit,
    Toolbar,
    SaveButton,
    DeleteButton,
    TestMemoryRouter,
    Show,
    SimpleShowLayout,
    useRecordContext,
    DataProvider,
    useEditContext,
    DateInput,
    SelectInput,
    useGetManyReference,
} from 'react-admin';
import { Stack, Typography } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';

import i18nProvider from '../../../stories/i18nProvider';
import { getDataProvider } from '../../../stories/common';
import { EditInDialogButton } from './EditInDialogButton';
import { WarnWhenUnsavedChangesInDialog } from './WarnWhenUnsavedChangesInDialog';

export default {
    title: 'ra-form-layout/DialogForm/EditInDialogButton',
};

const EmployerTitle = () => {
    const record = useRecordContext();
    if (!record) return null;
    return <span>Show {record.name}</span>;
};

const EmployerShow = () => (
    <Show title={<EmployerTitle />}>
        <SimpleShowLayout>
            <TextField source="name" />
            <TextField source="address" />
            <TextField source="city" />
        </SimpleShowLayout>
    </Show>
);

const Wrapper = ({ children, ...props }) => (
    <TestMemoryRouter>
        <Admin
            dataProvider={getDataProvider()}
            i18nProvider={i18nProvider}
            {...props}
        >
            <Resource
                name="employers"
                show={EmployerShow}
                list={() => (
                    <List>
                        <DataTable rowClick="show">
                            <DataTable.Col source="name" />
                            <DataTable.Col source="address" />
                            <DataTable.Col source="city" />
                            <DataTable.Col>{children}</DataTable.Col>
                        </DataTable>
                    </List>
                )}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);

export const Basic = () => (
    <Wrapper>
        <EditInDialogButton
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
        >
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);

const CustomerList = () => {
    const record = useRecordContext();
    const { data, isPending, error } = useGetManyReference('customers', {
        target: 'employer_id',
        id: record?.id,
    });
    if (!record?.id) return <p>ERROR: no record id</p>;
    if (isPending) return <p>loading</p>;
    if (error) return <p>ERROR</p>;

    return (
        <>
            <Typography variant="h6" gutterBottom>
                Customers
            </Typography>
            <ul>
                {data.map(customer => (
                    <li key={customer.id}>
                        {customer.last_name.toUpperCase()} {customer.first_name}
                        <EditInDialogButton
                            resource="customers"
                            id={customer.id}
                            label="Edit customer"
                        >
                            <SimpleForm>
                                <TextInput source="first_name" />
                                <TextInput source="last_name" />
                                <DateInput source="dob" />
                                <SelectInput
                                    source="sex"
                                    choices={[
                                        { id: 'male', name: 'Male' },
                                        { id: 'female', name: 'Female' },
                                    ]}
                                />

                                <TextInput source="employer_id" readOnly />
                            </SimpleForm>
                        </EditInDialogButton>
                    </li>
                ))}
            </ul>
        </>
    );
};

export const AccessControl = ({
    authorizedActionsEmployers,
    authorizedActionsCustomers,
}) => (
    <Wrapper
        authProvider={{
            canAccess: ({ resource, action }) => {
                if (resource === 'employers') {
                    return authorizedActionsEmployers.includes(action);
                }
                if (resource === 'customers') {
                    return authorizedActionsCustomers.includes(action);
                }
                return false;
            },
            checkAuth: () => Promise.resolve(),
            login: () => Promise.resolve(),
            logout: () => Promise.resolve(),
            checkError: () => Promise.resolve(),
            getIdentity: () =>
                Promise.resolve({ id: 'user', fullName: 'John Doe' }),
        }}
        key={JSON.stringify({
            authorizedActionsEmployers,
            authorizedActionsCustomers,
        })}
    >
        <EditInDialogButton
            fullWidth
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
        >
            <SimpleForm>
                <TextInput source="id" readOnly />
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
                <CustomerList />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);
AccessControl.args = {
    authorizedActionsEmployers: ['show', 'list'],
    authorizedActionsCustomers: [],
};
AccessControl.argTypes = {
    authorizedActionsEmployers: {
        name: 'Actions that are authorized for resource "employers"',
        options: ['list', 'edit', 'show'],
        control: { type: 'inline-check' },
    },
    authorizedActionsCustomers: {
        name: 'Actions that are authorized for resource "customers"',
        options: ['edit'],
        control: { type: 'inline-check' },
    },
};

export const FullWidth = () => (
    <Wrapper>
        <EditInDialogButton fullWidth maxWidth={false}>
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);

export const MaxWidth = () => (
    <Wrapper>
        <EditInDialogButton maxWidth="md" fullWidth>
            <SimpleForm>
                <TextInput source="name" fullWidth />
                <TextInput source="address" fullWidth />
                <TextInput source="city" fullWidth />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);

export const Label = () => (
    <Wrapper>
        <>
            <EditInDialogButton label="Update">
                <SimpleForm>
                    <TextInput source="name" />
                    <TextInput source="address" />
                    <TextInput source="city" />
                </SimpleForm>
            </EditInDialogButton>
        </>
    </Wrapper>
);

export const Inline = () => (
    <Wrapper>
        <EditInDialogButton inline>
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);

export const OnClick = ({
    onClick = e => {
        // eslint-disable-next-line no-console
        console.log('ButtonProps.onClick', e);
    },
}) => (
    <Wrapper>
        <EditInDialogButton
            ButtonProps={{
                variant: 'contained',
                onClick,
            }}
        >
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);

export const Transform = () => (
    <Wrapper>
        <EditInDialogButton
            transform={record => ({
                ...record,
                name: record.name + '_transformed',
            })}
        >
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);

export const MutationOptions = () => (
    <Wrapper>
        <MutationOptionsStory />
    </Wrapper>
);

const MutationOptionsStory = () => {
    const notify = useNotify();
    return (
        <EditInDialogButton
            mutationOptions={{
                onSuccess: () => {
                    notify('custom notification');
                },
            }}
        >
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    );
};

export const InReferenceField = () => (
    <TestMemoryRouter>
        <Admin dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
            <Resource
                name="employers"
                list={ListGuesser}
                edit={() => (
                    <Edit>
                        <SimpleForm>
                            <TextInput source="name" />
                            <TextInput source="address" />
                            <TextInput source="city" />
                            <ReferenceManyField
                                target="employer_id"
                                reference="customers"
                            >
                                <DataTable>
                                    <DataTable.Col source="first_name" />
                                    <DataTable.Col source="last_name" />
                                    <DataTable.Col>
                                        <EditInDialogButton
                                            fullWidth
                                            maxWidth="sm"
                                        >
                                            <SimpleForm
                                                toolbar={
                                                    <Toolbar
                                                        sx={{
                                                            justifyContent:
                                                                'space-between',
                                                        }}
                                                    >
                                                        <SaveButton />
                                                        <DeleteButton
                                                            redirect={false}
                                                        />
                                                    </Toolbar>
                                                }
                                            >
                                                <TextInput source="first_name" />
                                                <TextInput source="last_name" />
                                            </SimpleForm>
                                        </EditInDialogButton>
                                    </DataTable.Col>
                                </DataTable>
                            </ReferenceManyField>
                        </SimpleForm>
                    </Edit>
                )}
                recordRepresentation="name"
            />
            <Resource name="customers" list={ListGuesser} />
        </Admin>
    </TestMemoryRouter>
);

export const WarnWhenUnsavedChanges = ({
    mutationMode,
}: {
    mutationMode?: 'undoable' | 'pessimistic' | 'optimistic';
}) => (
    <Wrapper>
        <EditInDialogButton
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
            mutationMode={mutationMode}
        >
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
                <WarnWhenUnsavedChangesInDialog />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);
WarnWhenUnsavedChanges.argTypes = {
    mutationMode: {
        options: [undefined, 'undoable', 'pessimistic', 'optimistic'],
        control: { type: 'inline-radio' },
    },
};

const EditDialogTitle = () => {
    const record = useRecordContext();
    return <span>Edit employer {record?.name}</span>;
};

const EditDialogTitleWithContext = () => {
    const { defaultTitle } = useEditContext();
    return (
        <Stack
            direction="row"
            sx={{
                gap: 1,
                alignItems: 'center',
            }}
        >
            <PeopleIcon />
            {defaultTitle}
        </Stack>
    );
};

export const WithCustomTitle = (props: {
    title?:
        | 'component'
        | 'componentWithContext'
        | 'string'
        | 'null'
        | 'undefined';
}) => (
    <Wrapper>
        <EditInDialogButton
            title={
                props.title === 'undefined' ? undefined : props.title ===
                  'null' ? null : props.title === 'string' ? (
                    'Edit employer'
                ) : props.title === 'component' ? (
                    <EditDialogTitle />
                ) : (
                    <EditDialogTitleWithContext />
                )
            }
            fullWidth
            maxWidth="sm"
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
        >
            <SimpleForm>
                <TextInput source="name" />
                <TextInput source="address" />
                <TextInput source="city" />
            </SimpleForm>
        </EditInDialogButton>
    </Wrapper>
);
WithCustomTitle.args = { title: 'component' };
WithCustomTitle.argTypes = {
    title: {
        options: [
            'component',
            'componentWithContext',
            'string',
            'null',
            'undefined',
        ],
        control: { type: 'inline-radio' },
    },
};

export const WithEmptyWhenLoading = ({
    delay = 300,
    emptyWhileLoading = false,
}) => {
    const dataProvider = addDelay(getDataProvider(), delay);
    return (
        <TestMemoryRouter initialEntries={['/employers/1']}>
            <Admin dataProvider={dataProvider} i18nProvider={i18nProvider}>
                <Resource
                    name="employers"
                    show={EmployerShow}
                    list={() => (
                        <List>
                            <DataTable rowClick="show">
                                <DataTable.Col source="name" />
                                <DataTable.Col source="address" />
                                <DataTable.Col source="city" />
                                <DataTable.Col>
                                    <EditInDialogButton
                                        slotProps={{
                                            backdrop: {
                                                'aria-label': 'backdrop',
                                            },
                                        }}
                                        emptyWhileLoading={emptyWhileLoading}
                                        queryOptions={{
                                            // This ensure record is not cached and loading is displayed
                                            meta: { fromEdditButton: true },
                                        }}
                                    >
                                        <SimpleForm>
                                            <TextInput source="name" />
                                            <TextInput source="address" />
                                            <TextInput source="city" />
                                        </SimpleForm>
                                    </EditInDialogButton>
                                </DataTable.Col>
                            </DataTable>
                        </List>
                    )}
                    recordRepresentation="name"
                />
            </Admin>
        </TestMemoryRouter>
    );
};

WithEmptyWhenLoading.args = { delay: 300, emptyWhileLoading: false };
WithEmptyWhenLoading.argTypes = {
    delay: {
        control: { type: 'number' },
    },
    emptyWhileLoading: {
        control: { type: 'boolean' },
    },
};

const addDelay = (dataProvider: DataProvider, delay = 300) =>
    new Proxy(dataProvider, {
        get: (target, name) => (resource: string, params: any) => {
            if (typeof name === 'symbol' || name === 'then') {
                return;
            }
            return new Promise(resolve =>
                setTimeout(
                    () => resolve(dataProvider[name](resource, params)),
                    delay
                )
            );
        },
    });
