import * as React from 'react';
import {
    SimpleForm,
    TextInput,
    Admin,
    Resource,
    List,
    DataTable,
    TextField,
    Edit,
    TestMemoryRouter,
    SimpleShowLayout,
    useRecordContext,
    useShowContext,
    useGetManyReference,
    DateField,
    SelectField,
} from 'react-admin';
import { Stack, Typography } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';

import i18nProvider from '../../../stories/i18nProvider';
import { dataProvider } from '../../../stories/common';
import { ShowInDialogButton } from './ShowInDialogButton';

export default {
    title: 'ra-form-layout/DialogForm/ShowInDialogButton',
};

const EmployerTitle = () => {
    const record = useRecordContext();
    if (!record) return null;
    return <span>Edit {record.name}</span>;
};

const EmployerEdit = () => (
    <Edit title={<EmployerTitle />}>
        <SimpleForm>
            <TextInput source="name" />
            <TextInput source="address" />
            <TextInput source="city" />
        </SimpleForm>
    </Edit>
);

const Wrapper = ({ children, ...props }) => (
    <TestMemoryRouter>
        <Admin
            dataProvider={dataProvider}
            i18nProvider={i18nProvider}
            {...props}
        >
            <Resource
                name="employers"
                edit={EmployerEdit}
                list={() => (
                    <List>
                        <DataTable rowClick="edit">
                            <DataTable.Col source="name" />
                            <DataTable.Col source="address" />
                            <DataTable.Col source="city" />
                            <DataTable.Col>{children}</DataTable.Col>
                        </DataTable>
                    </List>
                )}
                recordRepresentation="name"
            />
        </Admin>
    </TestMemoryRouter>
);

export const Basic = () => (
    <Wrapper>
        <ShowInDialogButton
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
        >
            <SimpleShowLayout>
                <TextField source="name" />
                <TextField source="address" />
                <TextField source="city" />
            </SimpleShowLayout>
        </ShowInDialogButton>
    </Wrapper>
);

const CustomerList = () => {
    const record = useRecordContext();
    const { data, isPending, error } = useGetManyReference('customers', {
        target: 'employer_id',
        id: record?.id,
    });
    if (!record?.id) return <p>ERROR: no record id</p>;
    if (isPending) return <p>loading</p>;
    if (error) return <p>ERROR</p>;

    return (
        <>
            <Typography variant="h6" gutterBottom>
                Customers
            </Typography>
            <ul>
                {data.map(customer => (
                    <li key={customer.id}>
                        <Stack
                            direction="row"
                            sx={{
                                gap: 1,
                            }}
                        >
                            {customer.last_name.toUpperCase()}{' '}
                            {customer.first_name}
                            <ShowInDialogButton
                                resource="customers"
                                id={customer.id}
                                label="Show customer"
                            >
                                <SimpleShowLayout>
                                    <TextField source="first_name" />
                                    <TextField source="last_name" />
                                    <DateField source="dob" />
                                    <SelectField
                                        source="sex"
                                        choices={[
                                            { id: 'male', name: 'Male' },
                                            { id: 'female', name: 'Female' },
                                        ]}
                                    />

                                    <TextField source="employer_id" />
                                </SimpleShowLayout>
                            </ShowInDialogButton>
                        </Stack>
                    </li>
                ))}
            </ul>
        </>
    );
};

export const AccessControl = ({
    authorizedActionsEmployers,
    authorizedActionsCustomers,
}) => (
    <Wrapper
        authProvider={{
            canAccess: ({ resource, action }) => {
                if (resource === 'employers') {
                    return authorizedActionsEmployers.includes(action);
                }
                if (resource === 'customers') {
                    return authorizedActionsCustomers.includes(action);
                }
                return false;
            },
            checkAuth: () => Promise.resolve(),
            login: () => Promise.resolve(),
            logout: () => Promise.resolve(),
            checkError: () => Promise.resolve(),
            getIdentity: () =>
                Promise.resolve({ id: 'user', fullName: 'John Doe' }),
        }}
        key={JSON.stringify({
            authorizedActionsEmployers,
            authorizedActionsCustomers,
        })}
    >
        <ShowInDialogButton
            fullWidth
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
        >
            <SimpleShowLayout>
                <TextField source="name" />
                <TextField source="address" />
                <TextField source="city" />
                <CustomerList />
            </SimpleShowLayout>
        </ShowInDialogButton>
    </Wrapper>
);
AccessControl.args = {
    authorizedActionsEmployers: ['list', 'edit'],
    authorizedActionsCustomers: [],
};
AccessControl.argTypes = {
    authorizedActionsEmployers: {
        name: 'Actions that are authorized for resource "employers"',
        options: ['list', 'edit', 'show'],
        control: { type: 'inline-check' },
    },
    authorizedActionsCustomers: {
        name: 'Actions that are authorized for resource "customers"',
        options: ['show'],
        control: { type: 'inline-check' },
    },
};

export const OnClick = ({
    onClick = e => {
        // eslint-disable-next-line no-console
        console.log('ButtonProps.onClick', e);
    },
}) => (
    <Wrapper>
        <ShowInDialogButton
            ButtonProps={{
                variant: 'contained',
                onClick,
            }}
        >
            <SimpleShowLayout>
                <TextField source="name" />
                <TextField source="address" />
                <TextField source="city" />
            </SimpleShowLayout>
        </ShowInDialogButton>
    </Wrapper>
);

const ShowDialogTitle = () => {
    const record = useRecordContext();
    return <span>Show employer {record?.name}</span>;
};

const ShowDialogTitleWithContext = () => {
    const { defaultTitle } = useShowContext();
    return (
        <Stack
            direction="row"
            sx={{
                gap: 1,
                alignItems: 'center',
            }}
        >
            <PeopleIcon />
            {defaultTitle}
        </Stack>
    );
};

export const WithCustomTitle = (props: {
    title?:
        | 'component'
        | 'componentWithContext'
        | 'string'
        | 'null'
        | 'undefined';
}) => (
    <Wrapper>
        <ShowInDialogButton
            title={
                props.title === 'undefined' ? undefined : props.title ===
                  'null' ? null : props.title === 'string' ? (
                    'Show employer'
                ) : props.title === 'component' ? (
                    <ShowDialogTitle />
                ) : (
                    <ShowDialogTitleWithContext />
                )
            }
            fullWidth
            maxWidth="sm"
            slotProps={{
                backdrop: {
                    'aria-label': 'backdrop',
                },
            }}
        >
            <SimpleShowLayout>
                <TextField source="name" />
                <TextField source="address" />
                <TextField source="city" />
            </SimpleShowLayout>
        </ShowInDialogButton>
    </Wrapper>
);
WithCustomTitle.args = { title: 'component' };
WithCustomTitle.argTypes = {
    title: {
        options: [
            'component',
            'componentWithContext',
            'string',
            'null',
            'undefined',
        ],
        control: { type: 'inline-radio' },
    },
};
