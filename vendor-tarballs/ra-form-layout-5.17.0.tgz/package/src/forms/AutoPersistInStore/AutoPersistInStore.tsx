import { useAutoPersistInStore } from './useAutoPersistInStore';
import type { UseAutoPersistInStoreParams } from './useAutoPersistInStore';

export const AutoPersistInStore = ({
    getStoreKey,
    notificationMessage,
}: UseAutoPersistInStoreParams) => {
    useAutoPersistInStore({ getStoreKey, notificationMessage });
    return null;
};
