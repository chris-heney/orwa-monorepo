import React, { useEffect, useRef } from 'react';
import {
    Button,
    Translate,
    useCloseNotification,
    useEvent,
    useNotify,
    useRecordContext,
    useResourceContext,
    useStore,
} from 'react-admin';
import type {
    Identifier,
    RaRecord,
    ResourceContextValue,
    useStoreResult,
} from 'react-admin';
import { useFormContext } from 'react-hook-form';
import type { UseFormReset } from 'react-hook-form';
import { Alert } from '@mui/material';
import isEqual from 'lodash/isEqual';

export const useAutoPersistInStore = ({
    getStoreKey,
    notificationMessage = 'ra-form-layout.auto_persist_in_store.applied_changes',
}: UseAutoPersistInStoreParams) => {
    const isFirstRender = useRef(true);
    const notify = useNotify();
    const form = useFormContext();
    if (!form) {
        throw new Error(
            'Cannot use AutoPersistInStore outside of a react-admin form'
        );
    }
    const {
        getValues,
        setValue,
        formState: { isDirty, isSubmitting, isReady },
        reset,
        watch,
    } = form;

    const resource = useResourceContext();
    const record = useRecordContext();
    const isEditMode =
        typeof record === 'object' && record.hasOwnProperty('id');

    const storeKey = getStoreKey
        ? getStoreKey(resource, record)
        : `ra-persist-${resource}-${isEditMode ? record.id : 'create'}`;

    const [storedFormValues, setStoredFormValues] = useStore<any>(storeKey);

    // When the form is first rendered, populate the form with the stored values
    useEffect(() => {
        if (storedFormValues && isFirstRender.current && isReady) {
            let shouldNotify = false;
            for (const [name, value] of Object.entries(storedFormValues)) {
                if (!isEqual(getValues(name), value)) {
                    // duplicate the setValue call to avoid flickering
                    setValue(name, value, { shouldDirty: true });
                    // setTimeout is necessary to avoid race condition when the form is loading
                    setTimeout(
                        () => setValue(name, value, { shouldDirty: true }),
                        0
                    );
                    shouldNotify = true;
                }
            }
            if (shouldNotify) {
                notify(
                    <div>
                        <AutoPersistNotification
                            notificationMessage={notificationMessage}
                            reset={reset}
                            setStoredFormValues={setStoredFormValues}
                        />
                    </div>,
                    { autoHideDuration: null } // The notification will disappear when users click or submit the form
                );
            }
            isFirstRender.current = false;
        }
    }, [
        notify,
        notificationMessage,
        reset,
        setStoredFormValues,
        storedFormValues,
        getValues,
        setValue,
        isReady,
    ]);

    // Backup of the form's current values on change.
    useEffect(() => {
        const { unsubscribe } = watch((values, { type }) => {
            if (type === 'change' || isDirty) {
                // clean formValues from undefined values
                const cleanedFormValues = Object.entries(values).reduce(
                    (acc, [key, value]) =>
                        value !== undefined &&
                        !(Array.isArray(value) && value.length === 0)
                            ? { ...acc, [key]: value }
                            : acc,
                    {}
                );
                if (!isEqual(cleanedFormValues, storedFormValues)) {
                    setStoredFormValues(cleanedFormValues);
                }
            }
        });

        return () => unsubscribe();
    }, [isDirty, setStoredFormValues, storedFormValues, watch]);

    // When the form is submitted, remove the stored values
    useEffect(() => {
        if (isSubmitting) {
            setStoredFormValues(undefined);
        }
    }, [isSubmitting, setStoredFormValues]);
};

export type UseAutoPersistInStoreParams = {
    getStoreKey?: (
        resource: ResourceContextValue,
        record: RaRecord<Identifier> | undefined
    ) => string;
    notificationMessage?: string;
};

const AutoPersistNotification = ({
    notificationMessage,
    reset,
    setStoredFormValues,
}: {
    notificationMessage: string;
    reset: UseFormReset<any>;
    setStoredFormValues: useStoreResult[1];
}) => {
    const closeNotification = useCloseNotification();

    const cancel = useEvent(() => {
        reset();
        setStoredFormValues(undefined);
        closeNotification();
    });

    return (
        <Alert
            severity="info"
            action={<Button label="ra.action.cancel" onClick={cancel} />}
        >
            <Translate i18nKey={notificationMessage} />
        </Alert>
    );
};
