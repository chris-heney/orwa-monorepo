// This file is named with a `.nobuild.` extension to prevent it from being built by TypeScript.
// We need to do it because this file import `ra-relationships` which use `ra-form-layout` as devDependency.

import React from 'react';
import {
    Admin,
    ArrayInput,
    Button,
    Create,
    DateInput,
    Edit,
    Layout,
    ReferenceInput,
    required,
    Resource,
    SelectArrayInput,
    SelectInput,
    SimpleFormIterator,
    TabbedForm,
    TestMemoryRouter,
    TextInput,
    useResetStore,
    useStore,
} from 'react-admin';

import {
    getDataProvider,
    CustomerList,
    CustomerShow,
    sexChoices,
} from '../../../stories/common';
import i18nProvider from '../../../stories/i18nProvider';
import { AutoPersistInStore as AutoPersistInStoreComponent } from './AutoPersistInStore';
import { ReferenceManyToManyInput } from '@react-admin/ra-relationships';

const getStoreKey = (resource, record) =>
    `my-custom-persist-key-${resource}-${record && record.hasOwnProperty('id') ? record.id : 'create'}`;

const CustomerForm = ({
    customStoreKey,
    customNotificationMessage,
    displayAutoPersistInStore,
}) => (
    <TabbedForm defaultValues={{ first_name: 'John', last_name: 'Doe' }}>
        <TabbedForm.Tab label="identity">
            <TextInput source="first_name" validate={required()} />
            <TextInput source="last_name" validate={required()} />
            <DateInput source="dob" label="born" validate={required()} />
            <SelectInput source="sex" choices={sexChoices} />
        </TabbedForm.Tab>
        <TabbedForm.Tab label="work">
            <ReferenceInput source="employer_id" reference="employers">
                <SelectInput />
            </ReferenceInput>
            <ArrayInput source="occupations">
                <SimpleFormIterator inline>
                    <TextInput source="name" />
                    <DateInput source="from" />
                </SimpleFormIterator>
            </ArrayInput>
            <ReferenceManyToManyInput
                reference="profiles"
                through="customers_profiles"
                using="customer_id,profile_id"
            >
                <SelectArrayInput label="Preferred theme" optionText="name" />
            </ReferenceManyToManyInput>
        </TabbedForm.Tab>

        {displayAutoPersistInStore ? (
            <AutoPersistInStoreComponent
                getStoreKey={customStoreKey ? getStoreKey : undefined}
                notificationMessage={
                    customNotificationMessage
                        ? 'Modifications applied'
                        : undefined
                }
            />
        ) : undefined}
    </TabbedForm>
);

export const AutoPersistInStore = ({
    displayStore = false,
    customStoreKey = false,
    customNotificationMessage = false,
    displayAutoPersistInStore = true,
}: {
    customStoreKey?: boolean;
    displayStore?: boolean;
    displayAutoPersistInStore?: boolean;
    customNotificationMessage?: boolean;
}) => (
    <TestMemoryRouter>
        <Admin
            dataProvider={getDataProvider()}
            i18nProvider={i18nProvider}
            layout={layoutProps => (
                <MyLayout
                    {...layoutProps}
                    displayStore={displayStore}
                    customStoreKey={customStoreKey}
                />
            )}
        >
            <Resource
                name="customers"
                list={CustomerList}
                edit={
                    <Edit>
                        <CustomerForm
                            customStoreKey={customStoreKey}
                            customNotificationMessage={
                                customNotificationMessage
                            }
                            displayAutoPersistInStore={
                                displayAutoPersistInStore
                            }
                        />
                    </Edit>
                }
                create={
                    <Create>
                        <CustomerForm
                            customStoreKey={customStoreKey}
                            customNotificationMessage={
                                customNotificationMessage
                            }
                            displayAutoPersistInStore={
                                displayAutoPersistInStore
                            }
                        />
                    </Create>
                }
                show={CustomerShow}
            />
        </Admin>
    </TestMemoryRouter>
);

const MyLayout = ({ displayStore, customStoreKey, children }) => (
    <Layout>
        <ResetButton />
        {children}
        {displayStore ? <Store customStoreKey={customStoreKey} /> : null}
    </Layout>
);

const Store = ({ customStoreKey }) => {
    const createStoreKey = customStoreKey
        ? getStoreKey('customers', {})
        : 'ra-persist-customers-create';
    const editStoreKey = customStoreKey
        ? getStoreKey('customers', { id: 5 })
        : 'ra-persist-customers-5';
    const [storedValueCreate] = useStore(createStoreKey);
    const [storedValueEdit] = useStore(editStoreKey);
    return (
        <div style={{ maxWidth: '50vw' }} data-testid="stored_data">
            <pre>
                {createStoreKey}: {JSON.stringify(storedValueCreate)}
            </pre>
            <pre>
                {editStoreKey}: {JSON.stringify(storedValueEdit)}
            </pre>
        </div>
    );
};

const ResetButton = () => {
    const reset = useResetStore();
    return <Button onClick={() => reset()} label="Reset store" />;
};

AutoPersistInStore.args = {
    displayStore: false,
    customStoreKey: false,
    customNotificationMessage: false,
};

AutoPersistInStore.argTypes = {
    displayStore: {
        control: {
            type: 'boolean',
        },
    },
    customStoreKey: {
        control: {
            type: 'boolean',
        },
    },
    customNotificationMessage: {
        control: {
            type: 'boolean',
        },
    },
};

export default { title: 'ra-form-layout/AutoPersistInStore' };
