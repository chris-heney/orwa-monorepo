import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';

import { AutoPersistInStore } from './AutoPersistInStore.nobuild.stories';

const resetStore = async () =>
    fireEvent.click(await screen.getByRole('button', { name: 'Reset store' }));

describe('<AutoPersistInStore />', () => {
    it('the component should not render anything in the DOM', async () => {
        const { unmount } = render(
            <AutoPersistInStore displayAutoPersistInStore={false} />
        );
        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');
        const formWithoutAutoPersist = document.querySelector('.MuiStack-root');
        expect(formWithoutAutoPersist).not.toBeNull();

        unmount();
        expect(document.querySelector('form')).toBeNull();

        render(<AutoPersistInStore />);
        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');
        const formWithAutoPersist = document.querySelector('.MuiStack-root');
        expect(formWithAutoPersist).not.toBeNull();

        expect(formWithoutAutoPersist?.childElementCount).toBe(
            formWithAutoPersist?.childElementCount
        );
    });

    it('should persist form values in the store (create)', async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: '
        );

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');
        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: {"first_name":"toto","last_name":"Doe"}'
        );
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: {"first_name":"toto","last_name":"tata"}'
        );
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: {"first_name":"toto","last_name":"tata","dob":"1966-05-09"}'
        );
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: {"first_name":"toto","last_name":"tata","dob":"1966-05-09","sex":"female"}'
        );
        fireEvent.click(screen.getByRole('tab', { name: 'work' }));
        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: {"first_name":"toto","last_name":"tata","dob":"1966-05-09","sex":"female","employer_id":1}'
        );
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        expect(
            JSON.parse(
                screen
                    .getByTestId('stored_data')
                    .children[0].textContent.substring(29)
            )
        ).toStrictEqual({
            first_name: 'toto',
            last_name: 'tata',
            dob: '1966-05-09',
            sex: 'female',
            employer_id: 1,
            occupations: [{ name: null, from: null }],
        });
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));
        expect(
            JSON.parse(
                screen
                    .getByTestId('stored_data')
                    .children[0].textContent.substring(29)
            )
        ).toStrictEqual({
            first_name: 'toto',
            last_name: 'tata',
            dob: '1966-05-09',
            sex: 'female',
            employer_id: 1,
            occupations: [{ name: 'titi', from: null }],
            '@@ra-many-to-many/customers/customers_profiles/profiles': [2],
        });
    });

    it('should persist form values in the store (edit)', async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: '
        );
        fireEvent.click(await screen.findByText('Alan'));
        await new Promise(resolve => setTimeout(resolve, 500)); // wait for 500ms to let the ReferenceInput load
        fireEvent.change(await screen.findByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        await waitFor(() =>
            expect(
                screen.getByTestId('stored_data').children[1].textContent
            ).toBe(
                'ra-persist-customers-5: {"first_name":"toto","last_name":"Smith","id":5,"dob":"1949-06-22T00:00:00.000Z","sex":"male","employer_id":2,"occupations":[{"name":"Construction manager","from":"2017-05-13T00:00:00.000Z"},{"name":"Construction worker","from":"2003-09-08T00:00:00.000Z","to":"2017-05-12T00:00:00.000Z"},{"name":"Salesman","from":"2003-05-01T00:00:00.000Z","to":"2003-09-07T00:00:00.000Z"},{"name":"Fisher","from":"1992-12-02T00:00:00.000Z","to":"2003-04-16T00:00:00.000Z"},{"name":"Farmer","from":"1984-03-12T00:00:00.000Z","to":"1992-10-17T00:00:00.000Z"}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
            )
        );
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1949-06-22T00:00:00.000Z","sex":"male","employer_id":2,"occupations":[{"name":"Construction manager","from":"2017-05-13T00:00:00.000Z"},{"name":"Construction worker","from":"2003-09-08T00:00:00.000Z","to":"2017-05-12T00:00:00.000Z"},{"name":"Salesman","from":"2003-05-01T00:00:00.000Z","to":"2003-09-07T00:00:00.000Z"},{"name":"Fisher","from":"1992-12-02T00:00:00.000Z","to":"2003-04-16T00:00:00.000Z"},{"name":"Farmer","from":"1984-03-12T00:00:00.000Z","to":"1992-10-17T00:00:00.000Z"}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
        );
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1966-05-09","sex":"male","employer_id":2,"occupations":[{"name":"Construction manager","from":"2017-05-13T00:00:00.000Z"},{"name":"Construction worker","from":"2003-09-08T00:00:00.000Z","to":"2017-05-12T00:00:00.000Z"},{"name":"Salesman","from":"2003-05-01T00:00:00.000Z","to":"2003-09-07T00:00:00.000Z"},{"name":"Fisher","from":"1992-12-02T00:00:00.000Z","to":"2003-04-16T00:00:00.000Z"},{"name":"Farmer","from":"1984-03-12T00:00:00.000Z","to":"1992-10-17T00:00:00.000Z"}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
        );
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1966-05-09","sex":"female","employer_id":2,"occupations":[{"name":"Construction manager","from":"2017-05-13T00:00:00.000Z"},{"name":"Construction worker","from":"2003-09-08T00:00:00.000Z","to":"2017-05-12T00:00:00.000Z"},{"name":"Salesman","from":"2003-05-01T00:00:00.000Z","to":"2003-09-07T00:00:00.000Z"},{"name":"Fisher","from":"1992-12-02T00:00:00.000Z","to":"2003-04-16T00:00:00.000Z"},{"name":"Farmer","from":"1984-03-12T00:00:00.000Z","to":"1992-10-17T00:00:00.000Z"}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
        );
        fireEvent.click(screen.getByRole('tab', { name: 'work' }));
        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1966-05-09","sex":"female","employer_id":1,"occupations":[{"name":"Construction manager","from":"2017-05-13T00:00:00.000Z"},{"name":"Construction worker","from":"2003-09-08T00:00:00.000Z","to":"2017-05-12T00:00:00.000Z"},{"name":"Salesman","from":"2003-05-01T00:00:00.000Z","to":"2003-09-07T00:00:00.000Z"},{"name":"Fisher","from":"1992-12-02T00:00:00.000Z","to":"2003-04-16T00:00:00.000Z"},{"name":"Farmer","from":"1984-03-12T00:00:00.000Z","to":"1992-10-17T00:00:00.000Z"}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
        );
        fireEvent.click(screen.getByRole('button', { name: 'Clear the list' }));
        fireEvent.click(screen.getByRole('button', { name: 'Confirm' }));
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1966-05-09","sex":"female","employer_id":1,"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
        );
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1966-05-09","sex":"female","employer_id":1,"occupations":[{"name":null,"from":null}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1]}'
        );
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));
        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: {"first_name":"toto","last_name":"tata","id":5,"dob":"1966-05-09","sex":"female","employer_id":1,"occupations":[{"name":"titi","from":null}],"@@ra-many-to-many/customers/customers_profiles/profiles":[1,2]}'
        );
    });

    it('should apply stored values (create)', async () => {
        render(<AutoPersistInStore />);
        await resetStore();

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');

        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));
        fireEvent.click(screen.getByRole('tab', { name: 'work' }));
        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));
        fireEvent.click(screen.getByRole('menuitem'));

        await screen.findByText('Alan');
        fireEvent.click(screen.getByText('Create'));

        await screen.findByText('Applied previous unsaved changes');

        await screen.findByDisplayValue('toto');
        screen.getByDisplayValue('tata');
        screen.getByDisplayValue('1966-05-09');
        screen.getByText('Female');
        screen.getByText('Acme');
        screen.getByDisplayValue('titi');
        screen.getByText('white');
    });

    it('should apply stored values (edit)', async () => {
        render(<AutoPersistInStore />);
        await resetStore();

        fireEvent.click(await screen.findByText('Alan'));
        await screen.findByLabelText('First name *');

        screen.getByDisplayValue('Alan');
        screen.getByDisplayValue('Smith');
        screen.getByDisplayValue('1949-06-22');
        screen.getByText('Male');

        fireEvent.click(screen.getByRole('tab', { name: 'work' }));

        screen.getByText('Ace Chemicals');
        screen.getByDisplayValue('Construction manager');
        screen.getByDisplayValue('2017-05-13');
        screen.getByDisplayValue('Construction worker');
        screen.getByDisplayValue('2003-09-08');
        screen.getByDisplayValue('Salesman');
        screen.getByDisplayValue('2003-05-01');
        screen.getByDisplayValue('Fisher');
        screen.getByDisplayValue('1992-12-02');
        screen.getByDisplayValue('Farmer');
        screen.getByDisplayValue('1984-03-12');
        await screen.findByText('dark');

        fireEvent.click(screen.getByRole('tab', { name: 'identity' }));

        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));

        fireEvent.click(screen.getByRole('tab', { name: 'work' }));

        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        fireEvent.click(screen.getByRole('button', { name: 'Clear the list' }));
        fireEvent.click(screen.getByRole('button', { name: 'Confirm' }));
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));

        fireEvent.click(screen.getByText('Customers'));

        await screen.findByText('Anita');
        fireEvent.click(screen.getByText('Alan'));

        await screen.findByText('Applied previous unsaved changes');

        await screen.findByDisplayValue('toto');
        screen.getByDisplayValue('tata');
        screen.getByDisplayValue('1966-05-09');
        screen.getByDisplayValue('titi');
        screen.getByText('Female');

        fireEvent.click(screen.getByRole('tab', { name: 'work' }));

        screen.getByText('Acme');
        await screen.findByText('white');
    });

    it('should not persist form values in the store on saving (create)', async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: '
        );

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');
        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));
        fireEvent.click(screen.getByRole('tab', { name: 'work' }));
        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));
        fireEvent.click(screen.getByRole('button', { name: 'Save' }));

        setTimeout(() => null, 500); // wait for the store to be updated

        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: '
        );
    });

    it('should not persist form values in the store on saving (edit)', async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();
        expect(
            (await screen.findByTestId('stored_data')).children[1].textContent
        ).toBe('ra-persist-customers-5: ');
        fireEvent.click(screen.getByText('Alan'));
        fireEvent.change(await screen.findByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));
        fireEvent.click(screen.getByRole('tab', { name: 'work' }));
        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        fireEvent.click(screen.getByRole('button', { name: 'Clear the list' }));
        fireEvent.click(screen.getByRole('button', { name: 'Confirm' }));
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));
        fireEvent.click(screen.getByText('Save'));

        setTimeout(() => null, 500); // wait for the store to be updated

        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: '
        );
    });

    it("should not persist form values in the store if form isn't dirty (create)", async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: '
        );

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');
        fireEvent.click(screen.getByRole('menuitem'));

        setTimeout(() => null, 500); // wait for the store to be updated

        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: '
        );
    });

    it("should not persist form values in the store if form isn't dirty (edit)", async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();
        expect(
            (await screen.findByTestId('stored_data')).children[1].textContent
        ).toBe('ra-persist-customers-5: ');

        fireEvent.click(screen.getByText('Alan'));
        await screen.findByDisplayValue('Alan');
        fireEvent.click(screen.getByRole('menuitem'));

        setTimeout(() => null, 500); // wait for the store to be updated

        expect(screen.getByTestId('stored_data').children[1].textContent).toBe(
            'ra-persist-customers-5: '
        );
    });

    it('should allow to pass a custom persist key', async () => {
        render(<AutoPersistInStore customStoreKey displayStore />);
        await resetStore();
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'my-custom-persist-key-customers-create: '
        );

        fireEvent.click(await screen.findByText('Create'));
        fireEvent.change(await screen.findByLabelText('First name *'), {
            target: { value: 'toto' },
        });

        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'my-custom-persist-key-customers-create: {"first_name":"toto","last_name":"Doe"}'
        );
    });

    it('should allow to pass a custom notification message', async () => {
        render(<AutoPersistInStore customNotificationMessage />);
        await resetStore();

        fireEvent.click(await screen.findByText('Create'));
        fireEvent.change(await screen.findByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.click(screen.getByRole('menuitem'));
        fireEvent.click(screen.getByText('Create'));

        await screen.findByText('Modifications applied');
    });

    it('should remove the applied changes on click on the "Cancel" button of the notification (create)', async () => {
        render(<AutoPersistInStore />);
        await resetStore();

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');

        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));
        fireEvent.click(screen.getByRole('tab', { name: 'work' }));
        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));
        fireEvent.click(screen.getByRole('menuitem'));

        await screen.findByText('Alan');
        fireEvent.click(screen.getByText('Create'));

        await screen.findByDisplayValue('toto');
        screen.getByDisplayValue('tata');
        screen.getByDisplayValue('1966-05-09');
        screen.getByText('Female');
        screen.getByText('Acme');
        await screen.findByDisplayValue('titi');
        screen.getByText('white');

        fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));

        await screen.findByDisplayValue('John');
        screen.getByDisplayValue('Doe');
        expect(screen.queryByDisplayValue('toto')).toBeNull();
        expect(screen.queryByDisplayValue('tata')).toBeNull();
        expect(screen.queryByDisplayValue('1966-09-05')).toBeNull();
        expect(screen.queryByText('Female')).toBeNull();
        expect(screen.queryByText('Acme')).toBeNull();
        await waitFor(() => {
            expect(screen.queryByDisplayValue('titi')).toBeNull();
        });
        expect(screen.queryByText('white')).toBeNull();
    });

    it('should remove the applied changes on click on the "Cancel" button of the notification (edit)', async () => {
        render(<AutoPersistInStore />);
        await resetStore();

        fireEvent.click(await screen.findByText('Alan'));
        await screen.findByDisplayValue('1949-06-22');

        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        fireEvent.change(screen.getByLabelText('Last name *'), {
            target: { value: 'tata' },
        });
        fireEvent.change(screen.getByLabelText('born *'), {
            target: { value: '1966-05-09' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Sex'));
        fireEvent.click(await screen.findByText('Female'));

        fireEvent.click(screen.getByRole('tab', { name: 'work' }));

        fireEvent.mouseDown(await screen.findByLabelText('Employer'));
        fireEvent.click(await screen.findByText('Acme'));
        fireEvent.click(screen.getByRole('button', { name: 'Clear the list' }));
        fireEvent.click(screen.getByRole('button', { name: 'Confirm' }));
        fireEvent.click(screen.getByRole('button', { name: 'Add' }));
        fireEvent.change(screen.getByLabelText('Name'), {
            target: { value: 'titi' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Preferred theme'));
        fireEvent.click(await screen.findByText('white'));

        fireEvent.click(screen.getByText('Customers'));

        await screen.findByText('Anita');
        fireEvent.click(screen.getByText('Alan'));

        await screen.findByDisplayValue('toto');
        screen.getByDisplayValue('tata');
        screen.getByDisplayValue('1966-05-09');
        screen.getByDisplayValue('titi');
        screen.getByText('Female');
        screen.getByText('Acme');
        await screen.findByText('white');

        fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));

        await screen.findByDisplayValue('Alan');
        expect(screen.queryByDisplayValue('toto')).toBeNull();
        expect(screen.queryByDisplayValue('tata')).toBeNull();
        expect(screen.queryByDisplayValue('1966-05-09')).toBeNull();
        expect(screen.queryByDisplayValue('titi')).toBeNull();
        expect(screen.queryByText('Female')).toBeNull();
        expect(screen.queryByText('Acme')).toBeNull();
        expect(screen.queryByText('white')).toBeNull();
    });

    it('should reset the store on click on the "Cancel" button of the notification', async () => {
        render(<AutoPersistInStore displayStore />);
        await resetStore();

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');

        fireEvent.change(screen.getByLabelText('First name *'), {
            target: { value: 'toto' },
        });
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: {"first_name":"toto","last_name":"Doe"}'
        );
        fireEvent.click(screen.getByRole('menuitem'));

        await screen.findByText('Alan');
        fireEvent.click(screen.getByText('Create'));

        fireEvent.click(await screen.findByRole('button', { name: 'Cancel' }));
        expect(screen.getByTestId('stored_data').children[0].textContent).toBe(
            'ra-persist-customers-create: '
        );
    });

    it('should not remove stored values on click on the "Cancel" button of the notification', async () => {
        render(<AutoPersistInStore />);
        await resetStore();

        fireEvent.click(await screen.findByText('Create'));
        await screen.findByDisplayValue('John');

        fireEvent.change(screen.getByRole('textbox', { name: 'Last name' }), {
            target: { value: 'Wick' },
        });
        fireEvent.click(screen.getByRole('menuitem'));

        await screen.findByText('Alan');
        fireEvent.click(screen.getByText('Create'));

        await waitFor(() => {
            expect(
                (
                    screen.getByRole('textbox', {
                        name: 'First name',
                    }) as HTMLInputElement
                ).value
            ).toBe('John');
        });
        await waitFor(() => {
            expect(
                (
                    screen.getByRole('textbox', {
                        name: 'Last name',
                    }) as HTMLInputElement
                ).value
            ).toBe('Wick');
        });

        fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));

        await waitFor(() => {
            expect(
                screen.queryByText('Applied previous unsaved changes')
            ).toBeNull();
        });
        expect(
            (
                screen.getByRole('textbox', {
                    name: 'Last name',
                }) as HTMLInputElement
            ).value
        ).toBe('Doe');
        expect(
            (
                screen.getByRole('textbox', {
                    name: 'First name',
                }) as HTMLInputElement
            ).value
        ).toBe('John');
    });
});
