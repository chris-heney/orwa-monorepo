import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { userEvent } from '@testing-library/user-event';
import expect from 'expect';
import * as React from 'react';
import { add, format } from 'date-fns';
import {
    Basic,
    DefaultValues,
    Required,
    Validate,
    WithLocalizationProvider,
} from './DateRangeInput.stories';

describe('<DateRangeInput />', () => {
    beforeEach(() => {
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        jest.spyOn(console, 'error').mockImplementationOnce(() => {});
    });
    it('should render a text input', () => {
        render(<Basic />);
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.type).toBe('text');
    });
    it('should let users enter a date using the keyboard', async () => {
        render(<Basic />);
        const input = (await screen.findByLabelText(
            'Period'
        )) as HTMLInputElement;

        await userEvent.type(input, '1012201310122014');
        expect(input.value).toBe('10/12/2013 – 10/12/2014');

        await screen.findByText(
            '["2013-10-11T22:00:00.000Z","2014-10-11T22:00:00.000Z"] (object)'
        );
    });
    it('should accept a date object as defaultValue', async () => {
        render(<DefaultValues />);
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024 – 02/17/2024');
    });
    it('should accept a date string as defaultValue', async () => {
        render(
            <DefaultValues
                defaultValue={[
                    new Date('2024-01-18').toDateString(),
                    new Date('2024-02-15').toDateString(),
                ]}
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('01/18/2024 – 02/15/2024');
    });
    it('should accept an ISO string as defaultValue', async () => {
        render(
            <DefaultValues
                defaultValue={[
                    new Date('2024-01-18').toISOString(),
                    new Date('2024-02-15').toISOString(),
                ]}
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('01/18/2024 – 02/15/2024');
    });
    it('should return date objects as value', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{
                    period: [
                        new Date('2024-01-18').toISOString(),
                        new Date('2024-02-15').toISOString(),
                    ],
                }}
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('01/18/2024 – 02/15/2024');
        fireEvent.click(input);
        await waitFor(() => screen.getByRole('tooltip'));
        fireEvent.click(screen.getAllByText('22')[0]);
        fireEvent.click(screen.getAllByText('8')[1]);
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    period: [
                        new Date('2024-01-22T00:00:00.000Z'),
                        new Date('2024-02-08T00:00:00.000Z'),
                    ],
                },
                expect.anything()
            );
        });
    });
    it('should accept a parse prop', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{
                    period: ['2024-01-22', '2024-02-08'],
                }}
                parse={dates =>
                    dates
                        ? dates.map(date =>
                              date ? format(date, 'yyyy-MM-dd') : null
                          )
                        : null
                }
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('01/22/2024 – 02/08/2024');
        fireEvent.click(input);
        await waitFor(() => screen.getByRole('tooltip'));
        fireEvent.click(screen.getAllByText('22')[0]);
        fireEvent.click(screen.getAllByText('18')[1]);
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    period: ['2024-01-22', '2024-02-18'],
                },
                expect.anything()
            );
        });
    });
    it('should use the provided LocalizationProvider', async () => {
        render(
            <WithLocalizationProvider
                defaultValues={{
                    period: ['2024-01-15', '2024-01-18'],
                }}
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('15/01/2024 – 18/01/2024'); // As opposed to 01/15/2024
    });
    it('should support the mask prop', async () => {
        render(
            <DefaultValues
                defaultValues={{
                    period: ['2024-01-15', '2024-01-15'],
                }}
                mask="yyyy"
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('2024 – 2024');
    });
    it('should accept a parse function returning null', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{
                    period: ['2024-05-15', '2024-06-15'],
                }}
                parse={() => [null, null]}
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('05/15/2024 – 06/15/2024');
        fireEvent.click(input);
        await waitFor(() => screen.getByRole('tooltip'));
        fireEvent.click(screen.getAllByText('22')[0]);
        fireEvent.click(screen.getAllByText('8')[1]);
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    period: [null, null],
                },
                expect.anything()
            );
        });
    });
    it('should return null when date is empty', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{
                    period: ['2024-02-15', '2024-03-15'],
                }}
            />
        );
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('02/15/2024 – 03/15/2024');
        fireEvent.change(input, { target: { value: '' } });
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    period: [null, null],
                },
                expect.anything()
            );
        });
    });
    it('should render an error message if required', async () => {
        const onSubmit = jest.fn();
        render(
            <Required
                onSubmit={onSubmit}
                defaultValues={{
                    period: ['2024-02-15', '2024-03-15'],
                }}
            />
        );
        const input = screen.getByLabelText('Period *') as HTMLInputElement;
        expect(input.value).toBe('02/15/2024 – 03/15/2024');
        fireEvent.change(input, { target: { value: '' } });
        fireEvent.click(screen.getByLabelText('Save'));
        await screen.findByText('Required');
        expect(onSubmit).not.toHaveBeenCalled();
    });

    it('should render an error message if not valid', async () => {
        const onSubmit = jest.fn();
        const now = new Date().toISOString();
        const yesterday = format(add(new Date(), { days: -1 }), 'MM/dd/yyyy');
        const tomorow = format(add(new Date(), { days: 1 }), 'MM/dd/yyyy');
        render(<Validate onSubmit={onSubmit} />);
        const input = screen.getByLabelText('Period') as HTMLInputElement;
        expect(input.value).toBe('');
        fireEvent.change(input, {
            target: { value: `${yesterday}–${yesterday}` },
        });
        expect(input.value).toBe(`${yesterday} – ${yesterday}`);
        fireEvent.click(screen.getByLabelText('Save'));
        await screen.findByText(
            `End date must be at least ${format(now, 'dd/MM/yyyy')}`
        );
        fireEvent.change(input, {
            target: { value: `${tomorow}–${tomorow}` },
        });
        expect(input.value).toBe(`${tomorow} – ${tomorow}`);
        fireEvent.click(screen.getByLabelText('Save'));
        await screen.findByText(
            `Start date must be ${format(now, 'dd/MM/yyyy')} or less`
        );
        expect(onSubmit).not.toHaveBeenCalled();
    });
});
