import * as React from 'react';
import polyglotI18nProvider from 'ra-i18n-polyglot';
import englishMessages from 'ra-language-english';
import {
    AdminContext,
    Create,
    SimpleForm,
    SimpleFormProps,
    required,
    defaultTheme,
} from 'react-admin';
import { DateInput, DateInputProps } from './DateInput';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFnsV3';
import { Alert } from '@mui/material';
import { deepmerge } from '@mui/utils';

import { fr } from 'date-fns/locale';
import { format } from 'date-fns';
import { FormInspector, dataProvider } from '../../../stories/common';

export default {
    title: 'ra-form-layout/DatePickers/DateInput',
};

export const Basic = () => (
    <Wrapper>
        <DateInput source="published" />
    </Wrapper>
);

export const DefaultValues = ({
    onSubmit,
    defaultValues = { published: new Date('2024-01-15') },
    ...rest
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
} & Partial<DateInputProps>) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <DateInput source="published" {...rest} />
    </Wrapper>
);

export const DefaultValuesString = () => (
    <Wrapper defaultValues={{ published: '2024-01-15' }}>
        <DateInput source="published" />
    </Wrapper>
);

export const Label = () => (
    <Wrapper>
        <DateInput source="published" label="Custom Label" />
    </Wrapper>
);

export const Mask = () => (
    <Wrapper>
        <DateInput source="published" mask="yyyy" />
    </Wrapper>
);

export const ParseAsISO = () => (
    <Wrapper>
        <DateInput
            source="published"
            parse={(date: Date) => (date ? date.toISOString() : null)}
        />
    </Wrapper>
);

export const ParseAsDate = () => (
    <Wrapper>
        <DateInput
            source="published"
            parse={(date: Date) => (date ? format(date, 'MM/dd/yyyy') : null)}
        />
    </Wrapper>
);

const notFullWidthTheme = deepmerge(defaultTheme, {
    components: {
        MuiFormControl: { defaultProps: { fullWidth: undefined } },
        MuiTextField: { defaultProps: { fullWidth: undefined } },
        MuiAutocomplete: { defaultProps: { fullWidth: undefined } },
        RaSimpleFormIterator: { defaultProps: { fullWidth: undefined } },
        RaTranslatableInputs: { defaultProps: { fullWidth: undefined } },
    },
});

export const NotFullWidth = () => (
    <AdminContext
        dataProvider={dataProvider}
        i18nProvider={i18nProvider}
        theme={notFullWidthTheme}
    >
        <Create resource="posts">
            <SimpleForm>
                <DateInput source="published" />
                <FormInspector name="published" />
            </SimpleForm>
        </Create>
    </AdminContext>
);

export const Disabled = () => (
    <Wrapper>
        <DateInput source="published" disabled />
    </Wrapper>
);

export const Required = ({
    onSubmit,
    defaultValues,
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <DateInput source="published" validate={required()} />
    </Wrapper>
);

export const HelperText = () => (
    <Wrapper>
        <DateInput source="published" helperText="Custom helper text" />
    </Wrapper>
);

export const Variant = () => (
    <Wrapper>
        <DateInput source="published" variant="outlined" />
    </Wrapper>
);

const greaterThan = min => value => {
    const minDate = new Date(min);
    const valueDate = new Date(value);
    return valueDate > minDate ? undefined : 'Too early';
};

export const Validate = () => (
    <Wrapper>
        <DateInput source="published" validate={greaterThan('2010-10-26')} />
        <Alert severity="info">
            Please enter a date greater than 2010-10-26
        </Alert>
    </Wrapper>
);

export const WithLocalizationProvider = ({
    defaultValues,
}: {
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={fr}>
        <Wrapper defaultValues={defaultValues}>
            <DateInput source="published" />
        </Wrapper>
    </LocalizationProvider>
);

const i18nProvider = polyglotI18nProvider(() => englishMessages);

const Wrapper = ({
    children,
    onSubmit,
    defaultValues,
}: {
    children: React.ReactNode;
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <AdminContext dataProvider={dataProvider} i18nProvider={i18nProvider}>
        <Create resource="posts">
            <SimpleForm onSubmit={onSubmit} defaultValues={defaultValues}>
                {children}
                <FormInspector name="published" />
            </SimpleForm>
        </Create>
    </AdminContext>
);
