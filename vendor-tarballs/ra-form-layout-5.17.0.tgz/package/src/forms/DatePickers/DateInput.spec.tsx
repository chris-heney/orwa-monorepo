import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import expect from 'expect';
import * as React from 'react';
import { isValid, format } from 'date-fns';
import {
    Basic,
    DefaultValues,
    Required,
    WithLocalizationProvider,
} from './DateInput.stories';

describe('<DateInput />', () => {
    it('should render a text input', () => {
        render(<Basic />);
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.type).toBe('text');
    });

    it('should accept a date object as value', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: new Date('2024-01-15') }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');
        fireEvent.click(
            screen.getByLabelText('Choose date, selected date is Jan 15, 2024')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByText('22'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: new Date('2024-01-22T00:00:00.000Z'),
                },
                expect.anything()
            );
        });
    });

    it('should accept a date string as value', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');

        fireEvent.click(
            screen.getByLabelText('Choose date, selected date is Jan 15, 2024')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByText('22'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: new Date('2024-01-22T00:00:00.000Z'),
                },
                expect.anything()
            );
        });
    });

    it('should accept an ISO string as value (and keep the time part)', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15T14:25:17.772Z' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');

        fireEvent.click(
            screen.getByLabelText('Choose date, selected date is Jan 15, 2024')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByText('22'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: new Date('2024-01-22T14:25:17.772Z'),
                },
                expect.anything()
            );
        });
    });

    it('should use the provided LocalizationProvider', async () => {
        render(
            <WithLocalizationProvider
                defaultValues={{ published: '2024-01-15' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('15/01/2024'); // As opposed to 01/15/2024
    });

    it('should support the mask prop', async () => {
        render(
            <DefaultValues
                defaultValues={{ published: '2024-01-15' }}
                mask="yyyy"
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('2024');
    });

    it('should accept a parse function', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15' }}
                parse={(date: Date) =>
                    isValid(date) ? format(date, 'MM/dd/yyyy') : null
                }
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');
        fireEvent.click(
            screen.getByLabelText('Choose date, selected date is Jan 15, 2024')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByText('22'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: '01/22/2024',
                },
                expect.anything()
            );
        });
    });

    it('should accept a parse function returning null', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15' }}
                parse={() => null}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');
        fireEvent.click(
            screen.getByLabelText('Choose date, selected date is Jan 15, 2024')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByText('22'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: null,
                },
                expect.anything()
            );
        });
    });

    it('should return null when date is empty', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');
        fireEvent.change(input, {
            target: { value: '' },
        });
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: null,
                },
                expect.anything()
            );
        });
    });

    it('should render error messages', async () => {
        const onSubmit = jest.fn();
        render(
            <Required
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15' }}
            />
        );
        const input = screen.getByLabelText('Published *') as HTMLInputElement;
        expect(input.value).toBe('01/15/2024');
        fireEvent.change(input, {
            target: { value: '' },
        });
        fireEvent.click(screen.getByLabelText('Save'));
        await screen.findByText('Required');
        expect(onSubmit).not.toHaveBeenCalled();
    });
});
