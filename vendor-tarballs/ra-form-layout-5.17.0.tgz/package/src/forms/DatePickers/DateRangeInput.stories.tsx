/* eslint-disable no-console */
import * as React from 'react';
import {
    Admin,
    AdminContext,
    Create,
    DataTable,
    DateField,
    isEmpty,
    List,
    memoryStore,
    Resource,
    SimpleForm,
    SimpleFormProps,
    TestMemoryRouter,
} from 'react-admin';
import polyglotI18nProvider from 'ra-i18n-polyglot';
import englishMessages from 'ra-language-english';
import fakeRestProvider from 'ra-data-fakerest';
import { LocalizationProvider } from '@mui/x-date-pickers-pro';
import { AdapterDateFns } from '@mui/x-date-pickers-pro/AdapterDateFnsV3';
import { add, format, parse, endOfDay } from 'date-fns';
import { fr } from 'date-fns/locale';

import { DateRangeInput, DateRangeInputProps } from './DateRangeInput';
import { FormInspector } from '../../../stories/common';

export default {
    title: 'ra-form-layout/DatePickers/DateRangeInput',
};

const getDataProvider = () => fakeRestProvider({});

const i18nProvider = polyglotI18nProvider(() => englishMessages);

const Wrapper = props => (
    <AdminContext dataProvider={getDataProvider()} i18nProvider={i18nProvider}>
        <Create resource={props.resource ?? 'posts'}>
            <SimpleForm
                onSubmit={props.onSubmit}
                defaultValues={props.defaultValues}
                sx={props.sx}
            >
                {props.children}
                <FormInspector name="period" />
            </SimpleForm>
        </Create>
    </AdminContext>
);

export const Basic = () => (
    <Wrapper>
        <DateRangeInput source="period" />
    </Wrapper>
);

export const ClassName = () => (
    <Wrapper
        sx={{
            '.bg-red': {
                backgroundColor: 'rgba(255, 0, 0, 0.1)',
            },
        }}
    >
        <DateRangeInput source="period" className="bg-red" />
    </Wrapper>
);

export const NonFullWidth = () => (
    <Wrapper>
        <DateRangeInput source="period" fullWidth={false} />
    </Wrapper>
);

export const ParseAndFormat = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            format={dates =>
                dates
                    ? dates.map(date =>
                          date ? parse(date, 'dd/MM/yyyy', new Date()) : null
                      )
                    : null
            }
            parse={dates =>
                dates
                    ? dates.map(date =>
                          date ? format(date, 'dd/MM/yyyy') : null
                      )
                    : null
            }
        />
    </Wrapper>
);

export const ParseAsISO = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            parse={dates =>
                dates
                    ? dates.map(date => (date ? date.toISOString() : null))
                    : null
            }
        />
    </Wrapper>
);

export const ParseAsDate = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            parse={dates =>
                dates ? dates.map(date => (date ? new Date(date) : null)) : null
            }
        />
    </Wrapper>
);

export const HelperText = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            helperText="Dates shouldn't be later than 2030"
        />
    </Wrapper>
);

export const Label = () => (
    <Wrapper>
        <DateRangeInput source="period" label="Event Period" />
    </Wrapper>
);

export const Mask = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            defaultValue={[
                '2024-07-25T00:00:00+02:00',
                '2024-07-14T00:00:00+02:00',
            ]}
            mask="MM/yy"
        />
    </Wrapper>
);

export const SlotProps = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            slotProps={{
                actionBar: {
                    actions: ['today'],
                },
            }}
        />
    </Wrapper>
);

export const Variant = () => (
    <Wrapper>
        <DateRangeInput source="period" variant="outlined" />
    </Wrapper>
);

export const DefaultValues = ({
    onSubmit,
    defaultValues = {},
    defaultValue = [new Date('2024-01-15'), new Date('2024-02-17')],
    ...rest
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
} & Partial<DateRangeInputProps>) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <DateRangeInput source="period" defaultValue={defaultValue} {...rest} />
    </Wrapper>
);

export const DefaultValuesString = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            defaultValue={['2024-07-25', '2024-07-14']}
        />
    </Wrapper>
);

export const Disabled = () => (
    <Wrapper>
        <DateRangeInput source="period" disabled />
        <DateRangeInput
            source="announcement"
            defaultValue={[
                '2024-07-25T00:00:00+02:00',
                '2024-07-14T00:00:00+02:00',
            ]}
            disabled
        />
    </Wrapper>
);

export const ReadOnly = () => (
    <Wrapper>
        <DateRangeInput source="period" readOnly />
        <DateRangeInput
            source="announcement"
            defaultValue={[
                '2024-07-25T00:00:00+02:00',
                '2024-07-14T00:00:00+02:00',
            ]}
            readOnly
        />
    </Wrapper>
);

export const Required = ({
    onSubmit,
    defaultValues,
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <Wrapper defaultValues={defaultValues} onSubmit={onSubmit}>
        <DateRangeInput
            source="period"
            isRequired
            validate={dates =>
                !dates || isEmpty(dates[0]) || isEmpty(dates[1])
                    ? 'ra.validation.required'
                    : null
            }
        />
    </Wrapper>
);

export const Validate = ({
    onSubmit,
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
}) => (
    <Wrapper onSubmit={onSubmit}>
        <DateRangeInput
            source="period"
            validate={dates =>
                !dates
                    ? 'ra.validation.required'
                    : isEmpty(dates[0]) || dates[0] > new Date()
                      ? `Start date must be ${format(new Date(), 'dd/MM/yyyy')} or less`
                      : isEmpty(dates[1]) || dates[1] < new Date()
                        ? `End date must be at least ${format(new Date(), 'dd/MM/yyyy')}`
                        : ''
            }
        />
    </Wrapper>
);

export const OnChange = () => (
    <Wrapper>
        <DateRangeInput
            source="period"
            onChange={dates => {
                // eslint-disable-next-line no-console
                console.log('onChange', dates);
            }}
        />
    </Wrapper>
);

export const WithLocalizationProvider = ({
    defaultValues,
}: {
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={fr}>
        <Wrapper defaultValues={defaultValues}>
            <DateRangeInput source="period" />
        </Wrapper>
    </LocalizationProvider>
);

const dataProvider = fakeRestProvider(
    {
        events: [
            {
                id: 1,
                name: 'React Admin Meetup',
                date: new Date().toISOString(),
            },
            {
                id: 2,
                name: 'GreenFrame Meetup',
                date: new Date().toISOString(),
            },
            {
                id: 3,
                name: 'React Paris',
                date: add(new Date(), { days: -2 }).toISOString(),
            },
            {
                id: 4,
                name: 'SnowCamp day 1',
                date: add(new Date(), { days: 4 }).toISOString(),
            },
            {
                id: 5,
                name: 'SnowCamp day 2',
                date: add(new Date(), { days: 5 }).toISOString(),
            },
            {
                id: 6,
                name: 'SnowCamp day 3',
                date: add(new Date(), { days: 6 }).toISOString(),
            },
        ],
    },
    process.env.NODE_ENV !== 'test'
);

const dataProviderWithBetween = {
    ...dataProvider,
    getList: async (resource, params) => {
        if (params.filter.date_between) {
            const filter = {
                date_gte: params.filter.date_between[0],
                date_lte: params.filter.date_between[1],
            };
            return dataProvider.getList(resource, { ...params, filter });
        }
        return dataProvider.getList(resource, params);
    },
};

const dateRangeFilterParse = (dates: (Date | null)[]) => {
    return [dates[0], dates[1] ? endOfDay(dates[1]) : dates[1]];
};

const eventsFilters = [
    <DateRangeInput
        source="date_between"
        key="date_filter"
        parse={dateRangeFilterParse}
    />,
];

export const UseAsFilter = () => {
    return (
        <TestMemoryRouter>
            <Admin
                dataProvider={dataProviderWithBetween}
                i18nProvider={i18nProvider}
                store={memoryStore()}
            >
                <Resource
                    name="events"
                    list={
                        <List filters={eventsFilters}>
                            <DataTable>
                                <DataTable.NumberCol source="id" />
                                <DataTable.Col source="name" />
                                <DataTable.Col source="date">
                                    <DateField source="date" />
                                </DataTable.Col>
                            </DataTable>
                        </List>
                    }
                />
            </Admin>
        </TestMemoryRouter>
    );
};
