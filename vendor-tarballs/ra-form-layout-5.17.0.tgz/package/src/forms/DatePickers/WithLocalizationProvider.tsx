import * as React from 'react';
import { ReactNode, useContext } from 'react';
import {
    LocalizationProvider,
    MuiPickersAdapterContext,
} from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFnsV3';
import { enUS } from 'date-fns/locale/en-US';

const defaultLocalizationProps = {
    dateAdapter: AdapterDateFns,
    adapterLocale: enUS,
};

export const WithLocalizationProvider = ({
    children,
}: {
    children: ReactNode;
}) => {
    const muiPickersAdapterContext = useContext(MuiPickersAdapterContext);

    if (
        muiPickersAdapterContext?.utils?.lib &&
        muiPickersAdapterContext.utils.lib !== 'date-fns'
    ) {
        throw new Error(
            'DatePickerInput: React-admin Enterprise Edition Date Picker components only support the date-fns library. Please use the date-fns adapter in the LocalizationProvider.'
        );
    }

    return muiPickersAdapterContext ? (
        <>{children}</>
    ) : (
        <LocalizationProvider {...defaultLocalizationProps}>
            {children}
        </LocalizationProvider>
    );
};
