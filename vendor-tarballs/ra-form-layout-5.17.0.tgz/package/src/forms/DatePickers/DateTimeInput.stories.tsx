import * as React from 'react';
import polyglotI18nProvider from 'ra-i18n-polyglot';
import englishMessages from 'ra-language-english';
import {
    AdminContext,
    Create,
    SimpleForm,
    SimpleFormProps,
    required,
    defaultTheme,
} from 'react-admin';
import { DateTimeInput, DateTimeInputProps } from './DateTimeInput';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFnsV3';
import { Alert } from '@mui/material';
import { deepmerge } from '@mui/utils';

import { fr } from 'date-fns/locale';
import { format } from 'date-fns';
import { FormInspector, dataProvider } from '../../../stories/common';

export default {
    title: 'ra-form-layout/DatePickers/DateTimeInput',
};

export const Basic = () => (
    <Wrapper>
        <DateTimeInput source="published" />
    </Wrapper>
);

export const DefaultValues = ({
    onSubmit,
    defaultValues = { published: new Date('2024-01-15 03:25 PM') },
    ...rest
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
} & Partial<DateTimeInputProps>) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <DateTimeInput source="published" {...rest} />
    </Wrapper>
);

export const DefaultValuesString = () => (
    <Wrapper defaultValues={{ published: '2024-01-15 03:25 PM' }}>
        <DateTimeInput source="published" />
    </Wrapper>
);

export const Label = () => (
    <Wrapper>
        <DateTimeInput source="published" label="Custom Label" />
    </Wrapper>
);

export const Mask = () => (
    <Wrapper>
        <DateTimeInput source="published" mask="yyyy" />
    </Wrapper>
);

export const ParseAsISO = () => (
    <Wrapper>
        <DateTimeInput
            source="published"
            parse={(date: Date) => (date ? date.toISOString() : null)}
        />
    </Wrapper>
);

export const ParseAsDateTime = () => (
    <Wrapper>
        <DateTimeInput
            source="published"
            parse={(date: Date) =>
                date ? format(date, 'MM/dd/yyyy hh:mm aa') : null
            }
        />
    </Wrapper>
);

const notFullWidthTheme = deepmerge(defaultTheme, {
    components: {
        MuiFormControl: { defaultProps: { fullWidth: undefined } },
        MuiTextField: { defaultProps: { fullWidth: undefined } },
        MuiAutocomplete: { defaultProps: { fullWidth: undefined } },
        RaSimpleFormIterator: { defaultProps: { fullWidth: undefined } },
        RaTranslatableInputs: { defaultProps: { fullWidth: undefined } },
    },
});

export const NotFullWidth = () => (
    <AdminContext
        dataProvider={dataProvider}
        i18nProvider={i18nProvider}
        theme={notFullWidthTheme}
    >
        <Create resource="posts">
            <SimpleForm>
                <DateTimeInput source="published" />
                <FormInspector name="published" />
            </SimpleForm>
        </Create>
    </AdminContext>
);

export const Disabled = () => (
    <Wrapper>
        <DateTimeInput source="published" disabled />
    </Wrapper>
);

export const Required = ({
    onSubmit,
    defaultValues,
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <DateTimeInput source="published" validate={required()} />
    </Wrapper>
);

export const HelperText = () => (
    <Wrapper>
        <DateTimeInput source="published" helperText="Custom helper text" />
    </Wrapper>
);

export const Variant = () => (
    <Wrapper>
        <DateTimeInput source="published" variant="outlined" />
    </Wrapper>
);

const greaterThan = min => value => {
    const minDate = new Date(min);
    const valueDate = new Date(value);
    return valueDate > minDate ? undefined : 'Too early';
};

export const Validate = () => (
    <Wrapper>
        <DateTimeInput
            source="published"
            validate={greaterThan('2010-10-26')}
        />
        <Alert severity="info">
            Please enter a date greater than 2010-10-26
        </Alert>
    </Wrapper>
);

export const WithLocalizationProvider = ({
    onSubmit,
    defaultValues,
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={fr}>
        <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
            <DateTimeInput source="published" />
        </Wrapper>
    </LocalizationProvider>
);

const i18nProvider = polyglotI18nProvider(() => englishMessages);

const Wrapper = ({
    children,
    onSubmit,
    defaultValues,
}: {
    children: React.ReactNode;
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <AdminContext dataProvider={dataProvider} i18nProvider={i18nProvider}>
        <Create resource="posts">
            <SimpleForm onSubmit={onSubmit} defaultValues={defaultValues}>
                {children}
                <FormInspector name="published" />
            </SimpleForm>
        </Create>
    </AdminContext>
);
