import * as React from 'react';
import clsx from 'clsx';
import {
    CommonInputProps,
    FieldTitle,
    InputHelperText,
    sanitizeInputRestProps,
    useInput,
} from 'react-admin';
import { isValid } from 'date-fns/isValid';
import { parse } from 'date-fns/parse';
import { TimePicker, TimePickerProps } from '@mui/x-date-pickers';
import { WithLocalizationProvider } from './WithLocalizationProvider';

/**
 * Form input to edit the Time of a Date string value or a Date object.
 * Renders a time picker from Mui X (https://mui.com/x/react-date-pickers/time-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { TimeInput } from '@react-admin/ra-form-layout';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <TimeInput source="published_at" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // TimeInput return a Date object but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <TimeInput source="published" parse={(date: Date) => (date ? date.toISOString() : null)} />
 */
export const TimeInput = (props: TimeInputProps) => {
    const {
        className,
        format = defaultFormat,
        mask,
        label,
        source,
        resource,
        helperText,
        fullWidth,
        variant,
        slotProps,
        ...rest
    } = props;

    const { field, fieldState, formState, id, isRequired } = useInput({
        source,
        resource,
        format,
        ...rest,
    });

    const { error, invalid, isTouched } = fieldState;
    const { isSubmitted } = formState;
    const renderHelperText =
        helperText !== false || ((isTouched || isSubmitted) && invalid);

    return (
        <WithLocalizationProvider>
            <TimePicker
                id={id}
                label={
                    <FieldTitle
                        label={label}
                        source={source}
                        resource={resource}
                        isRequired={isRequired}
                    />
                }
                slotProps={{
                    ...slotProps,
                    textField: {
                        helperText: renderHelperText ? (
                            <InputHelperText
                                error={error?.message}
                                helperText={helperText}
                            />
                        ) : null,
                        fullWidth,
                        error: invalid,
                        variant: variant || 'filled',
                        onBlur: field.onBlur,
                        ...slotProps?.textField,
                    },
                }}
                format={mask}
                onChange={(date: Date) => {
                    if (!isValid(date)) {
                        field.onChange(null);
                        return;
                    }
                    field.onChange(date);
                }}
                className={clsx('ra-input', `ra-input-${source}`, className)}
                value={field.value}
                {...sanitizeInputRestProps(rest)}
            />
        </WithLocalizationProvider>
    );
};

export type TimeInputProps = CommonInputProps &
    Omit<TimePickerProps<Date>, 'helperText' | 'label' | 'format'> & {
        mask?: TimePickerProps<Date>['format'];
    };

const defaultFormat = (date: Date | string) => {
    if (!date) return null;
    let parsedDate = date;
    if (typeof date === 'string') {
        const longLocalizedTime = parse(date as string, 'p', new Date());
        if (isValid(longLocalizedTime)) return longLocalizedTime;
        const longLocalizedTimeWithSecs = parse(
            date as string,
            'pp',
            new Date()
        );
        if (isValid(longLocalizedTimeWithSecs))
            return longLocalizedTimeWithSecs;
        parsedDate = new Date(date);
    }
    return isValid(parsedDate) ? parsedDate : null;
};
