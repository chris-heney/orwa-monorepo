import * as React from 'react';
import clsx from 'clsx';
import {
    CommonInputProps,
    FieldTitle,
    InputHelperText,
    sanitizeInputRestProps,
    useInput,
} from 'react-admin';
import { DateTimePicker, DateTimePickerProps } from '@mui/x-date-pickers';
import { isValid } from 'date-fns/isValid';
import { WithLocalizationProvider } from './WithLocalizationProvider';

/**
 * Form input to edit the Time of a Date string value or a Date object.
 * Renders a date time picker from Mui X (https://mui.com/x/react-date-pickers/date-time-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { DateTimeInput } from '@react-admin/ra-form-layout';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <DateTimeInput source="published_at" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // DateTimeInput return a Date object but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <DateTimeInput source="published" parse={(date: Date) => (date ? date.toISOString() : null)} />
 */
export const DateTimeInput = (props: DateTimeInputProps) => {
    const {
        className,
        format = defaultFormat,
        mask,
        label,
        source,
        resource,
        helperText,
        fullWidth,
        variant,
        slotProps,
        ...rest
    } = props;

    const { field, fieldState, formState, id, isRequired } = useInput({
        source,
        resource,
        format,
        ...rest,
    });

    const { error, invalid, isTouched } = fieldState;
    const { isSubmitted } = formState;
    const renderHelperText =
        helperText !== false || ((isTouched || isSubmitted) && invalid);

    return (
        <WithLocalizationProvider>
            <DateTimePicker
                id={id}
                label={
                    <FieldTitle
                        label={label}
                        source={source}
                        resource={resource}
                        isRequired={isRequired}
                    />
                }
                slotProps={{
                    ...slotProps,
                    textField: {
                        helperText: renderHelperText ? (
                            <InputHelperText
                                error={error?.message}
                                helperText={helperText}
                            />
                        ) : null,
                        fullWidth,
                        error: invalid,
                        variant: variant || 'filled',
                        onBlur: field.onBlur,
                        ...slotProps?.textField,
                    },
                }}
                format={mask}
                onChange={(date: Date) => {
                    if (!isValid(date)) {
                        field.onChange(null);
                        return;
                    }
                    field.onChange(date);
                }}
                className={clsx('ra-input', `ra-input-${source}`, className)}
                value={field.value}
                {...sanitizeInputRestProps(rest)}
            />
        </WithLocalizationProvider>
    );
};

export type DateTimeInputProps = CommonInputProps &
    Omit<DateTimePickerProps<Date>, 'helperText' | 'label' | 'format'> & {
        mask?: DateTimePickerProps<Date>['format'];
    };

const defaultFormat = (date: Date | string) => (date ? new Date(date) : null);
