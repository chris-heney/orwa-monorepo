import * as React from 'react';
import {
    CommonInputProps,
    FieldTitle,
    InputHelperText,
    sanitizeInputRestProps,
    useInput,
} from 'react-admin';
import {
    DatePickerProps,
    DateRangePicker,
    SingleInputDateRangeField,
} from '@mui/x-date-pickers-pro';
import clsx from 'clsx';

import { WithLocalizationProviderPro } from './WithLocalizationProviderPro';

/**
 * Form input to edit a range of dates.
 * Renders a date range picker from Mui X (https://mui.com/x/react-date-pickers/date-range-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { DateRangeInput } from '@react-admin/ra-form-layout/DateRangeInput';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <DateRangeInput source="subscription_period" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // DateRangeInput return a Date object array but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <DateRangeInput source="inscription_period" parse={dates => dates ? dates.map(date => (date ? date.toISOString() : null)) : null } />
 */
export const DateRangeInput = ({
    className,
    format = DEFAULT_FORMAT,
    fullWidth,
    helperText,
    label,
    mask,
    resource,
    slotProps,
    source,
    variant = 'filled',
    defaultValue,
    ...rest
}: DateRangeInputProps) => {
    const { field, fieldState, id, isRequired } = useInput({
        source,
        resource,
        format,
        defaultValue: defaultValue ?? [],
        ...rest,
    });

    const { error, invalid } = fieldState;

    const renderHelperText = helperText !== false || invalid;
    return (
        <WithLocalizationProviderPro>
            <DateRangePicker
                id={id}
                label={
                    <FieldTitle
                        label={label}
                        source={source}
                        resource={resource}
                        isRequired={isRequired}
                    />
                }
                slots={DEFAULT_SLOT}
                slotProps={{
                    ...slotProps,
                    textField: {
                        helperText: renderHelperText ? (
                            <InputHelperText
                                error={error?.message}
                                helperText={helperText}
                            />
                        ) : null,
                        fullWidth,
                        error: invalid,
                        variant,
                        onBlur: field.onBlur,
                        ...slotProps?.textField,
                    },
                }}
                format={mask}
                className={clsx('ra-input', `ra-input-${source}`, className)}
                {...field}
                {...sanitizeInputRestProps(rest)}
            />
        </WithLocalizationProviderPro>
    );
};

const DEFAULT_SLOT = { field: SingleInputDateRangeField };

export type DateRangeInputProps = CommonInputProps &
    Omit<
        DatePickerProps<Date>,
        'helperText' | 'label' | 'format' | 'defaultValue'
    > & {
        mask?: DatePickerProps<Date>['format'];
    };

const DEFAULT_FORMAT = (dates: (Date | string | null | undefined)[]) =>
    dates ? dates.map(date => (date ? new Date(date) : null)) : dates;
