import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import expect from 'expect';
import * as React from 'react';
import { isValid, format, parse } from 'date-fns';

import {
    Basic,
    DefaultValues,
    Required,
    WithLocalizationProvider,
} from './TimeInput.stories';

describe('<TimeInput />', () => {
    it('should render a text input', () => {
        render(<Basic />);
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.type).toBe('text');
    });

    it('should accept a date object as value', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: new Date('2024-01-15 03:25 PM') }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');
        fireEvent.click(
            screen.getByLabelText('Choose time, selected time is 3:25 PM')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByLabelText('5 hours'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: new Date('2024-01-15T16:25:00.000Z'),
                },
                expect.anything()
            );
        });
    });

    it('should accept a time string as value', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '03:25 PM' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');

        fireEvent.click(
            screen.getByLabelText('Choose time, selected time is 3:25 PM')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByLabelText('5 hours'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: parse('05:25 PM', 'hh:mm aa', new Date()),
                },
                expect.anything()
            );
        });
    });

    it('should accept an ISO string as value (and keep the date part)', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15T14:25:17.772Z' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');

        fireEvent.click(
            screen.getByLabelText('Choose time, selected time is 3:25 PM')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByLabelText('5 hours'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: new Date('2024-01-15T16:25:17.772Z'),
                },
                expect.anything()
            );
        });
    });

    it('should use the provided LocalizationProvider', async () => {
        render(
            <WithLocalizationProvider
                defaultValues={{ published: '2024-01-15 03:25 PM' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('15:25'); // As opposed to 03:25 PM
    });

    it('should support the mask prop', async () => {
        render(
            <DefaultValues
                defaultValues={{ published: '2024-01-15 03:25 PM' }}
                mask="hh"
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03');
    });

    it('should accept a parse function', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15 03:25 PM' }}
                parse={(date: Date) =>
                    isValid(date) ? format(date, 'hh:mm aa') : date
                }
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');
        fireEvent.click(
            screen.getByLabelText('Choose time, selected time is 3:25 PM')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByLabelText('5 hours'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: '05:25 PM',
                },
                expect.anything()
            );
        });
    });

    it('should accept a parse function returning null', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15 03:25 PM' }}
                parse={() => null}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');
        fireEvent.click(
            screen.getByLabelText('Choose time, selected time is 3:25 PM')
        );
        await waitFor(() => screen.getByRole('dialog'));
        fireEvent.click(screen.getByLabelText('5 hours'));
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: null,
                },
                expect.anything()
            );
        });
    });

    it('should return null when time is empty', async () => {
        const onSubmit = jest.fn();
        render(
            <DefaultValues
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15 03:25 PM' }}
            />
        );
        const input = screen.getByLabelText('Published') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');
        fireEvent.change(input, {
            target: { value: '' },
        });
        fireEvent.click(screen.getByLabelText('Save'));
        await waitFor(() => {
            expect(onSubmit).toHaveBeenCalledWith(
                {
                    published: null,
                },
                expect.anything()
            );
        });
    });

    it('should render error messages', async () => {
        const onSubmit = jest.fn();
        render(
            <Required
                onSubmit={onSubmit}
                defaultValues={{ published: '2024-01-15 03:25 PM' }}
            />
        );
        const input = screen.getByLabelText('Published *') as HTMLInputElement;
        expect(input.value).toBe('03:25 PM');
        fireEvent.change(input, {
            target: { value: '' },
        });
        fireEvent.click(screen.getByLabelText('Save'));
        await screen.findByText('Required');
        expect(onSubmit).not.toHaveBeenCalled();
    });
});
