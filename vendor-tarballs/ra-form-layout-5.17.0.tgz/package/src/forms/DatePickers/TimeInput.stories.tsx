import * as React from 'react';
import polyglotI18nProvider from 'ra-i18n-polyglot';
import englishMessages from 'ra-language-english';
import {
    AdminContext,
    Create,
    SimpleForm,
    SimpleFormProps,
    required,
    defaultTheme,
} from 'react-admin';
import { TimeInput, TimeInputProps } from './TimeInput';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFnsV3';
import { Alert } from '@mui/material';
import { deepmerge } from '@mui/utils';

import { fr } from 'date-fns/locale';
import { parse, format } from 'date-fns';
import { FormInspector, dataProvider } from '../../../stories/common';

export default {
    title: 'ra-form-layout/DatePickers/TimeInput',
};

export const Basic = () => (
    <Wrapper>
        <TimeInput source="published" />
    </Wrapper>
);

export const DefaultValues = ({
    onSubmit,
    defaultValues = { published: new Date('2024-01-15 03:25 PM') },
    ...rest
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
} & Partial<TimeInputProps>) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <TimeInput source="published" {...rest} />
    </Wrapper>
);

export const DefaultValuesString = () => (
    <Wrapper defaultValues={{ published: '03:25 PM' }}>
        <TimeInput source="published" />
    </Wrapper>
);

export const Label = () => (
    <Wrapper>
        <TimeInput source="published" label="Custom Label" />
    </Wrapper>
);

export const Mask = () => (
    <Wrapper>
        <TimeInput source="published" mask="hh" />
    </Wrapper>
);

export const ParseAsISO = () => (
    <Wrapper>
        <TimeInput
            source="published"
            parse={(date: Date) => (date ? date.toISOString() : null)}
        />
    </Wrapper>
);

export const ParseAsTime = () => (
    <Wrapper>
        <TimeInput
            source="published"
            parse={(date: Date) => (date ? format(date, 'hh:mm aa') : date)}
        />
    </Wrapper>
);

const notFullWidthTheme = deepmerge(defaultTheme, {
    components: {
        MuiFormControl: { defaultProps: { fullWidth: undefined } },
        MuiTextField: { defaultProps: { fullWidth: undefined } },
        MuiAutocomplete: { defaultProps: { fullWidth: undefined } },
        RaSimpleFormIterator: { defaultProps: { fullWidth: undefined } },
        RaTranslatableInputs: { defaultProps: { fullWidth: undefined } },
    },
});

export const NotFullWidth = () => (
    <AdminContext
        dataProvider={dataProvider}
        i18nProvider={i18nProvider}
        theme={notFullWidthTheme}
    >
        <Create resource="posts">
            <SimpleForm>
                <TimeInput source="published" />
                <FormInspector name="published" />
            </SimpleForm>
        </Create>
    </AdminContext>
);

export const Disabled = () => (
    <Wrapper>
        <TimeInput source="published" disabled />
    </Wrapper>
);

export const Required = ({
    onSubmit,
    defaultValues,
}: {
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <Wrapper onSubmit={onSubmit} defaultValues={defaultValues}>
        <TimeInput source="published" validate={required()} />
    </Wrapper>
);

export const HelperText = () => (
    <Wrapper>
        <TimeInput source="published" helperText="Custom helper text" />
    </Wrapper>
);

export const Variant = () => (
    <Wrapper>
        <TimeInput source="published" variant="outlined" />
    </Wrapper>
);

const greaterThan = min => value => {
    const minDate = parse(min, 'hh:mm aa', new Date());
    const valueDate = new Date(value);
    return valueDate > minDate ? undefined : 'Too early';
};

export const Validate = () => (
    <Wrapper>
        <TimeInput source="published" validate={greaterThan('10:00 AM')} />
        <Alert severity="info">Please enter a time greater than 10:00 AM</Alert>
    </Wrapper>
);

export const WithLocalizationProvider = ({
    defaultValues,
}: {
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={fr}>
        <Wrapper defaultValues={defaultValues}>
            <TimeInput source="published" />
        </Wrapper>
    </LocalizationProvider>
);

const i18nProvider = polyglotI18nProvider(() => englishMessages);

const Wrapper = ({
    children,
    onSubmit,
    defaultValues,
}: {
    children: React.ReactNode;
    onSubmit?: SimpleFormProps['onSubmit'];
    defaultValues?: SimpleFormProps['defaultValues'];
}) => (
    <AdminContext dataProvider={dataProvider} i18nProvider={i18nProvider}>
        <Create resource="posts">
            <SimpleForm onSubmit={onSubmit} defaultValues={defaultValues}>
                {children}
                <FormInspector name="published" />
            </SimpleForm>
        </Create>
    </AdminContext>
);
