import * as React from 'react';
import { Box, Toolbar as MUIToolbar, ToolbarProps, Stack } from '@mui/material';
import { SaveButton } from 'react-admin';

import { NextButton } from './NextButton';
import { WizardFormContextValue } from './WizardFormContext';
import { useWizardFormContext } from './useWizardFormContext';
import { PreviousButton } from './PreviousButton';

/**
 * The Toolbar displayed at the bottom of WizardForm.
 *
 * @prop {boolean} hasPreviousStep Optional. Does the wizard have a previous step?
 * @prop {boolean} hasNextStep Optional. Does the wizard have a next step?
 * @prop {Function} onPreviousClick Optional. Previous button click action
 * @prop {Function} onNextClick Optional. Next button click action
 * @prop {...BaseToolbarSubmitProps}
 */
export const WizardToolbar = (props: WizardToolbarProps) => {
    const { children, ...rest } = props;

    const { hasNextStep } = useWizardFormContext(props);

    return (
        <MUIToolbar {...sanitizeRestProps(rest)}>
            {children ? (
                children
            ) : (
                <Stack
                    direction="row"
                    sx={{
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        width: '100%',
                    }}
                >
                    <Box>
                        <PreviousButton />
                    </Box>
                    <Box>{hasNextStep ? <NextButton /> : <SaveButton />}</Box>
                </Stack>
            )}
        </MUIToolbar>
    );
};

const sanitizeRestProps = ({
    currentStep,
    goToNextStep,
    goToPreviousStep,
    goToStep,
    steps,
    ...rest
}: WizardToolbarProps): Omit<ToolbarProps, 'classes'> => rest;

export interface WizardToolbarProps
    extends Omit<ToolbarProps, 'classes'>,
        Partial<WizardFormContextValue> {}
