import * as React from 'react';
import { isValidElement, ReactNode, useMemo, useState } from 'react';
import {
    CardContentInner,
    FormGroupContextProvider,
    Loading,
    useEvent,
} from 'react-admin';
import {
    useAuthorizedChildren,
    UseAuthorizedChildrenFilterChildren,
    UseAuthorizedChildrenGetResourceKey,
} from '@react-admin/ra-core-ee';

import { WizardProgress } from './WizardProgress';
import { WizardToolbar } from './WizardToolbar';
import { WizardFormContext, WizardFormContextValue } from './WizardFormContext';
import { WizardFormStepProvider } from './WizardFormStepProvider';
import { WizardFormStepProps } from './WizardFormStep';

export const WizardFormView = ({
    authorizationError,
    children,
    enableAccessControl = false,
    loading = DefaultLoading,
    toolbar = DefaultToolbar,
    progress = DefaultProgress,
}: WizardFormViewProps) => {
    const { authorizedChildren, isPending, error } = useAuthorizedChildren({
        children,
        action: 'write',
        getResourceKey,
        filterChildren,
        enabled: enableAccessControl,
    });

    const [currentStep, setCurrentStep] = useState(0);

    const steps = React.Children.toArray(authorizedChildren)
        .filter(step => isValidElement<WizardFormStepProps>(step))
        .map(step =>
            React.cloneElement<WizardFormStepProps>(step, {
                enableAccessControl:
                    step.props.enableAccessControl ?? enableAccessControl,
            })
        );
    const hasPreviousStep = currentStep > 0;
    const hasNextStep = currentStep < steps.length - 1;

    const goToNextStep = useEvent((): void => {
        setCurrentStep(step => {
            if (step === steps.length - 1) return step;
            return step + 1;
        });
    });

    const goToPreviousStep = useEvent((): void => {
        setCurrentStep(step => {
            if (step === 0) return step;
            return step - 1;
        });
    });

    const goToStep = useEvent((index: number): void => {
        if (index < 0 || index > steps.length - 1) return;
        setCurrentStep(index);
    });

    const context = useMemo<WizardFormContextValue>(
        () => ({
            currentStep,
            hasPreviousStep,
            hasNextStep,
            goToNextStep,
            goToPreviousStep,
            goToStep,
            steps,
        }),
        [
            currentStep,
            hasPreviousStep,
            hasNextStep,
            goToNextStep,
            goToPreviousStep,
            goToStep,
            steps,
        ]
    );

    if (error) {
        return authorizationError;
    }

    if (enableAccessControl && isPending) {
        return loading;
    }

    return (
        <WizardFormContext.Provider value={context}>
            {progress}
            <CardContentInner>
                {steps.map((step, index) => (
                    <FormGroupContextProvider
                        key={step.key}
                        name={`step-${index}`}
                    >
                        <WizardFormStepProvider key={step.key} step={index}>
                            {step}
                        </WizardFormStepProvider>
                    </FormGroupContextProvider>
                ))}
            </CardContentInner>
            {toolbar}
        </WizardFormContext.Provider>
    );
};

const DefaultProgress = <WizardProgress />;
const DefaultToolbar = <WizardToolbar />;
const DefaultLoading = <Loading />;
const getResourceKey: UseAuthorizedChildrenGetResourceKey = (
    child,
    resource
) => {
    return `${resource}.step.${child.props.id ?? child.props.label}`;
};
const filterChildren: UseAuthorizedChildrenFilterChildren = child => {
    if (
        child.props.id == null &&
        (child.props.label == null || child.props.label === '')
    ) {
        if (process.env.NODE_ENV === 'development') {
            console.warn(
                `You enabled access control on the WizardForm but didn't provide an id nor a label to its steps. Access control cannot be enforced on some steps.`
            );
        }
        return false;
    }
    return true;
};

export interface WizardFormViewProps {
    authorizationError?: ReactNode;
    className?: string;
    enableAccessControl?: boolean;
    loading?: ReactNode;
    children: ReactNode;
    progress?: ReactNode;
    toolbar?: ReactNode;
}
