import { createContext, ReactElement } from 'react';
import { WizardFormStepProps } from './WizardFormStep';

export const WizardFormContext = createContext<
    WizardFormContextValue | undefined
>(undefined);

export interface WizardFormContextValue {
    currentStep: number;
    hasPreviousStep: boolean;
    hasNextStep: boolean;
    goToNextStep: () => void;
    goToPreviousStep: () => void;
    goToStep: (step: number) => void;
    steps: ReactElement<WizardFormStepProps>[];
}
