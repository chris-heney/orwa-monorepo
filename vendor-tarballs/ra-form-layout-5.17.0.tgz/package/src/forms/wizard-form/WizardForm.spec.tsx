import * as React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import {
    required,
    Create,
    TextInput,
    AdminContext,
    testDataProvider,
    useRegisterMutationMiddleware,
    Middleware,
    DataProvider,
} from 'react-admin';

import { WizardForm } from './WizardForm';
import { WizardFormStep } from './WizardFormStep';
import {
    AccessControl,
    AccessControlOnStepsOnly,
    Basic,
} from './../../../stories/wizardForm.stories';

const defaultCreateProps = {
    resource: 'posts',
};

const PostCreate = props => (
    <Create {...props}>
        <WizardForm>
            <WizardFormStep label="First step">
                <TextInput source="title" validate={required()} />
            </WizardFormStep>
            <WizardFormStep label="Second step">
                <TextInput source="description" validate={required()} />
            </WizardFormStep>
            <WizardFormStep label="Third step">
                <TextInput source="fullDescription" validate={required()} />
            </WizardFormStep>
        </WizardForm>
    </Create>
);

describe('WizardForm', () => {
    it('should display the same number of steps as declared WizardFormStep', () => {
        render(
            <AdminContext dataProvider={testDataProvider()}>
                <PostCreate {...defaultCreateProps} />
            </AdminContext>
        );

        // 2 for each step: (step indicator + step fieldset legend)
        expect(screen.queryAllByText('First step')).toHaveLength(2);
        expect(screen.queryAllByText('Second step')).toHaveLength(2);
        expect(screen.queryAllByText('Third step')).toHaveLength(2);

        expect(
            screen.queryByText('resources.posts.fields.title')
        ).not.toBeNull();
    });

    it('should enable next button when current step is dirty', async () => {
        render(
            <AdminContext dataProvider={testDataProvider()}>
                <PostCreate {...defaultCreateProps} record={{ title: '' }} />
            </AdminContext>
        );

        await waitFor(() => {
            screen.getByLabelText('resources.posts.fields.title *');
        });

        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title *'),
            {
                target: { value: 'My title' },
            }
        );

        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
    });

    it('should have validation working independently on every step', async () => {
        render(
            <AdminContext
                dataProvider={testDataProvider({
                    create: jest.fn().mockResolvedValue({ data: { id: 123 } }),
                })}
            >
                <PostCreate {...defaultCreateProps} record={{ title: '' }} />
            </AdminContext>
        );

        await screen.findByLabelText('resources.posts.fields.title *');
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title *'),
            { target: { value: 'My title' } }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
        fireEvent.click(screen.getByText('ra-form-layout.action.next'));
        await screen.findByLabelText('resources.posts.fields.description *');
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.description *'),
            { target: { value: 'My desc' } }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
        fireEvent.click(screen.getByText('ra-form-layout.action.next'));
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.fullDescription *'),
            { target: { value: 'My full desc' } }
        );
        fireEvent.click(await screen.findByText('ra.action.save'));
    });

    it('should go to the next step on next button click', async () => {
        render(
            <AdminContext dataProvider={testDataProvider()}>
                <PostCreate {...defaultCreateProps} />
            </AdminContext>
        );

        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title *'),
            {
                target: { value: 'My title' },
            }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
        const nextButton = await screen.findByLabelText(
            'ra-form-layout.action.next'
        );
        fireEvent.click(nextButton);

        await waitFor(() => {
            expect(
                screen
                    .getByText('First step', { selector: 'button *' })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual(null);
        });
        expect(
            (await screen.findByText('Second step', { selector: 'button *' }))
                .closest('button')
                ?.getAttribute('aria-current')
        ).toEqual('step');
    });

    it('should go back on previous button click', async () => {
        render(
            <AdminContext dataProvider={testDataProvider()}>
                <PostCreate {...defaultCreateProps} />
            </AdminContext>
        );

        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title *'),
            {
                target: { value: 'My title' },
            }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
        const nextButton = await screen.findByLabelText(
            'ra-form-layout.action.next'
        );
        fireEvent.click(nextButton);
        await waitFor(() => {
            expect(
                screen
                    .getByText('First step', { selector: 'button *' })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual(null);
        });
        expect(
            (
                await screen.findByText('Second step', {
                    selector: 'button *',
                })
            )
                .closest('button')
                ?.getAttribute('aria-current')
        ).toEqual('step');

        const previousButton = await screen.findByLabelText(
            'ra-form-layout.action.previous'
        );
        fireEvent.click(previousButton);
        await waitFor(() => {
            expect(
                screen
                    .getByText('Second step', {
                        selector: 'button *',
                    })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual(null);
        });
        expect(
            screen
                .getByText('First step', {
                    selector: 'button *',
                })
                .closest('button')
                ?.getAttribute('aria-current')
        ).toEqual('step');
    });

    it('should display a save button instead of next at the last step', async () => {
        render(
            <AdminContext dataProvider={testDataProvider()}>
                <PostCreate {...defaultCreateProps} />
            </AdminContext>
        );

        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title *'),
            {
                target: { value: 'My title' },
            }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });

        fireEvent.click(
            await screen.findByLabelText('ra-form-layout.action.next')
        );
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.description *'),
            {
                target: { value: 'My desc' },
            }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
        fireEvent.click(screen.getByText('ra-form-layout.action.next'));

        await screen.findByText('ra.action.save');
    });

    it('should be able to navigate back and then forth again even when the last step is invalid', async () => {
        render(
            <AdminContext dataProvider={testDataProvider()}>
                <PostCreate {...defaultCreateProps} />
            </AdminContext>
        );
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title *'),
            {
                target: { value: 'My title' },
            }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });

        fireEvent.click(
            await screen.findByLabelText('ra-form-layout.action.next')
        );
        await waitFor(() => {
            expect(
                screen
                    .getByText('Second step', {
                        selector: 'button *',
                    })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual('step');
        });

        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.description *'),
            {
                target: { value: 'My desc' },
            }
        );
        await waitFor(() => {
            expect(
                screen.getByText('ra-form-layout.action.next')['disabled']
            ).toEqual(false);
        });
        fireEvent.click(screen.getByText('ra-form-layout.action.next'));
        await waitFor(() => {
            expect(
                screen
                    .getByText('Third step', {
                        selector: 'button *',
                    })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual('step');
        });

        const previousButton = await screen.findByLabelText(
            'ra-form-layout.action.previous'
        );
        fireEvent.click(previousButton);
        await waitFor(() => {
            expect(
                screen
                    .getByText('Second step', {
                        selector: 'button *',
                    })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual('step');
        });

        fireEvent.click(
            await screen.findByLabelText('ra-form-layout.action.next')
        );
        await waitFor(() => {
            expect(
                screen
                    .getByText('Third step', {
                        selector: 'button *',
                    })
                    .closest('button')
                    ?.getAttribute('aria-current')
            ).toEqual('step');
        });
    });

    it('supports middlewares on all steps', async () => {
        const dataProvider = testDataProvider({
            create: jest.fn().mockResolvedValue({ data: { id: 123 } }),
        });

        const MiddlewareInput = props => {
            const middleware = React.useCallback<
                Middleware<DataProvider['create']>
            >(
                (resource, params, next) => {
                    if (
                        params?.data &&
                        params.data[props.source] !== undefined
                    ) {
                        const newData = { ...params.data };
                        newData[props.source] = `${
                            params.data[props.source]
                        } (modified)`;
                        return next(resource, { ...params, data: newData });
                    }

                    return next(resource, params);
                },
                [props.source]
            );

            useRegisterMutationMiddleware(middleware);

            return <TextInput {...props} />;
        };

        const PostCreate = () => (
            <Create {...defaultCreateProps} redirect={false}>
                <WizardForm>
                    <WizardFormStep label="First step">
                        <MiddlewareInput source="title" />
                    </WizardFormStep>
                    <WizardFormStep label="Second step">
                        <MiddlewareInput source="description" />
                    </WizardFormStep>
                    <WizardFormStep label="Third step">
                        <MiddlewareInput source="fullDescription" />
                    </WizardFormStep>
                </WizardForm>
            </Create>
        );

        render(
            <AdminContext dataProvider={dataProvider}>
                <PostCreate />
            </AdminContext>
        );

        let nextButton = await screen.findByLabelText(
            'ra-form-layout.action.next'
        );
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.title'),
            {
                target: { value: 'test-title' },
            }
        );
        await waitFor(() => {
            expect(nextButton['disabled']).toEqual(false);
        });
        fireEvent.click(nextButton);
        nextButton = await screen.findByLabelText('ra-form-layout.action.next');
        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.description'),
            {
                target: { value: 'test-description' },
            }
        );
        await waitFor(() => {
            expect(nextButton['disabled']).toEqual(false);
        });
        fireEvent.click(nextButton);

        fireEvent.change(
            screen.getByLabelText('resources.posts.fields.fullDescription'),
            {
                target: { value: 'test-fullDescription' },
            }
        );

        fireEvent.click(await screen.findByText('ra.action.save'));

        await waitFor(() => {
            expect(dataProvider.create).toHaveBeenCalledWith('posts', {
                data: {
                    title: 'test-title (modified)',
                    description: 'test-description (modified)',
                    fullDescription: 'test-fullDescription (modified)',
                },
            });
        });
    });

    it("shouldn't disable <NextButton> on pristine form", async () => {
        render(<Basic />);

        // Create view
        await screen.findByLabelText('Next');
        expect(screen.getByLabelText('Next')['disabled']).toEqual(false);

        fireEvent.click(screen.getByText('Posts'));
        // Wait to be on the list view
        await screen.findByText('Lorem Ipsum');
        fireEvent.click(await screen.findByText('Sic dolor amet'));
        // Wait to be on the show view
        await screen.findByText('Almost empty');
        fireEvent.click(await screen.findByLabelText('Edit'));

        // Edit view
        await screen.findByLabelText('Next');
        expect(screen.getByLabelText('Next')['disabled']).toEqual(false);
    });

    const StepHeaderSelector = 'button *';
    it('should apply access control to the steps and inputs if enableAccessControl is true', async () => {
        const { rerender } = render(
            <AccessControl
                canAccessProtectedInput={false}
                canAccessThirdStep={false}
            />
        );

        await screen.findByText('First step', { selector: StepHeaderSelector });
        expect(screen.queryByLabelText('Protected *')).toBeNull();
        await screen.findByText('Second step', {
            selector: StepHeaderSelector,
        });
        expect(
            screen.queryByText('Third step', { selector: StepHeaderSelector })
        ).toBeNull();

        rerender(
            <AccessControl
                canAccessProtectedInput={true}
                canAccessThirdStep={true}
            />
        );
        await screen.findByText('First step', { selector: StepHeaderSelector });
        await screen.findByLabelText('Protected *');
        await screen.findByText('Second step', {
            selector: StepHeaderSelector,
        });
        await screen.findByText('Third step', { selector: StepHeaderSelector });
    });
    it('should apply access control only to the steps if enableAccessControl is true but is overridden on steps', async () => {
        const { rerender } = render(
            <AccessControlOnStepsOnly
                canAccessProtectedInput={false}
                canAccessThirdStep={false}
            />
        );

        await screen.findByText('First step', { selector: StepHeaderSelector });
        // Should be displayed even though the permission would return false if checked as
        // the panels have enableAccessControl set to false
        await screen.findByLabelText('Protected *');
        await screen.findByText('Second step', {
            selector: StepHeaderSelector,
        });
        expect(
            screen.queryByText('Third step', { selector: StepHeaderSelector })
        ).toBeNull();

        rerender(
            <AccessControlOnStepsOnly
                canAccessProtectedInput={false}
                canAccessThirdStep={true}
            />
        );
        await screen.findByText('First step', { selector: StepHeaderSelector });
        // Should be displayed even though the permission would return false if checked as
        // the panels have enableAccessControl set to false
        await screen.findByLabelText('Protected *');
        await screen.findByText('Second step', {
            selector: StepHeaderSelector,
        });
        await screen.findByText('Third step', { selector: StepHeaderSelector });
    });
});
