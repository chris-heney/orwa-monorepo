import * as React from 'react';
import { useTranslate } from 'react-admin';
import { useFormState } from 'react-hook-form';
import { Button, ButtonProps } from '@mui/material';
import { useWizardFormContext } from './useWizardFormContext';

export const PreviousButton = ({ disabled, ...rest }: PreviousButtonProps) => {
    const translate = useTranslate();
    const { isValidating } = useFormState();
    const { hasPreviousStep, goToPreviousStep } = useWizardFormContext();
    if (!goToPreviousStep) {
        throw new Error(
            'The NextButton component cannot be used outside a WizardFormContext'
        );
    }
    const label = translate('ra-form-layout.action.previous');

    const handleClick = (event: React.MouseEvent<HTMLElement>): void => {
        event.preventDefault();
        goToPreviousStep();
    };

    if (!hasPreviousStep) return null;
    return (
        <Button
            color="primary"
            disabled={disabled || isValidating}
            type="button"
            aria-label={label}
            onClick={handleClick}
            {...rest}
        >
            {label}
        </Button>
    );
};

export type PreviousButtonProps = ButtonProps;
