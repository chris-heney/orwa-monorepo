import * as React from 'react';
import { useFormGroups, useTranslate } from 'react-admin';
import { useFormContext, useFormState } from 'react-hook-form';
import { Button, ButtonProps } from '@mui/material';
import { useWizardFormContext } from './useWizardFormContext';

export const NextButton = ({ disabled, ...rest }: NextButtonProps) => {
    const translate = useTranslate();
    const { trigger } = useFormContext();
    const { isValidating } = useFormState();
    const { currentStep, hasNextStep, goToNextStep } = useWizardFormContext();
    if (!goToNextStep) {
        throw new Error(
            'The NextButton component cannot be used outside a WizardFormContext'
        );
    }
    const formGroups = useFormGroups();
    const label = translate('ra-form-layout.action.next');
    const buttonRef = React.useRef<HTMLButtonElement>(null);
    const handleClick = React.useCallback(
        async (event: React.MouseEvent<HTMLButtonElement>) => {
            event.preventDefault();
            // Prevent double submission
            if (buttonRef.current) {
                buttonRef.current.disabled = true;
            }
            const isGroupValid = await trigger(
                formGroups?.getGroupFields(`step-${currentStep}`)
            );
            if (isGroupValid) {
                return goToNextStep();
            }
            if (buttonRef.current) {
                buttonRef.current.disabled = false;
            }
        },
        [currentStep, formGroups, goToNextStep, trigger]
    );

    React.useEffect(() => {
        // Reset the button state when the step changes
        if (buttonRef.current) {
            buttonRef.current.disabled = false;
        }
    }, [currentStep]);

    if (!hasNextStep) return null;
    return (
        <Button
            variant="contained"
            color="primary"
            disabled={disabled || isValidating}
            type="submit"
            aria-label={label}
            onClick={handleClick}
            ref={buttonRef}
            {...rest}
        >
            {label}
        </Button>
    );
};

export type NextButtonProps = ButtonProps;
