import * as React from 'react';
import clsx from 'clsx';
import {
    Form,
    FormProps,
    OptionalRecordContextProvider,
    useRecordContext,
} from 'react-admin';

import { WizardFormStep } from './WizardFormStep';
import { WizardFormView, WizardFormViewProps } from './WizardFormView';

/**
 * Form component rendering a wizard form with stepper
 *
 * Alternative to <SimpleForm>, to be used as child of <Create>.
 * Expects <WizardFormStep> elements as children.
 *
 * @param {ComponentType} toolbar An alternative toolbar element (to customize form buttons)
 * @param {ComponentType} progress An alternative progress bar element (to customize stepper)
 *
 * @example
 *
 * import React from 'react';
 * import { Create, TextInput, required } from 'react-admin';
 * import { WizardForm, WizardFormStep } from '@react-admin/ra-form-layout';
 *
 * const PostCreate = props => (
 *   <Create>
 *       <WizardForm>
 *           <WizardFormStep label="First step">
 *               <TextInput source="title" validate={required()} />
 *           </WizardFormStep>
 *           <WizardFormStep label="Second step">
 *               <TextInput source="description" />
 *           </WizardFormStep>
 *           <WizardFormStep label="Third step">
 *               <TextInput source="fullDescription" validate={required()} />
 *           </WizardFormStep>
 *       </WizardForm>
 *   </Create>
 * );
 */
export const WizardForm = (props: WizardFormProps) => {
    const {
        authorizationError,
        children,
        className,
        progress,
        toolbar,
        enableAccessControl = false,
        loading,
        ...rest
    } = props;
    const record = useRecordContext(props);
    return (
        <OptionalRecordContextProvider value={record}>
            <Form className={clsx('wizard-form', className)} {...rest}>
                <WizardFormView
                    authorizationError={authorizationError}
                    enableAccessControl={enableAccessControl}
                    loading={loading}
                    progress={progress}
                    toolbar={toolbar}
                >
                    {children}
                </WizardFormView>
            </Form>
        </OptionalRecordContextProvider>
    );
};

WizardForm.Step = WizardFormStep;

export interface WizardFormProps
    extends FormProps,
        Omit<WizardFormViewProps, 'onSubmit'> {}
