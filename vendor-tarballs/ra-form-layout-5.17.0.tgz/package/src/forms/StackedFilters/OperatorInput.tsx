import * as React from 'react';
import { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import {
    CommonInputProps,
    SelectInput,
    TextInput,
    useSourceContext,
} from 'react-admin';
import get from 'lodash/get';
import type { FilterOperator, FiltersConfig } from './types';

export const OperatorInput = ({
    className,
    operators,
    source,
    valueInputSource = 'value',
    config,
    ...rest
}: OperatorInputProps) => {
    const { getValues, resetField, watch } = useFormContext();
    const { getSource } = useSourceContext();

    const oldOperator = React.useRef<FilterOperator | undefined>(
        operators.find(
            operator => operator.value === get(getValues(), getSource(source))
        )
    );
    useEffect(() => {
        const { unsubscribe } = watch((data, { name }) => {
            const sourceField = getSource('source');
            const operatorField = getSource(source);
            const valueField = getSource(valueInputSource);

            const operatorChanged = operatorField === name;
            const sourceChanged = sourceField === name;
            if (!operatorChanged && !sourceChanged) return;

            // We need to handle those cases
            // 1. If the source has changed
            //   - Its operators contain the currently selected one
            //     => we don't need to reset the operator
            //   - Its operators do not contain the currently selected one
            //     => we must reset the operator to the first one available
            //   - In any case
            //     => we must reset the source value
            //
            // 2. If the operator has changed (users changed it or we changed it in step 1)
            //   - Its type is the same => we don't need to reset the value
            //   - Its type is different => we must reset the value

            // Get the config for the current source
            const sourceConfig = config[get(data, sourceField)];
            if (!sourceConfig) return;

            // Get the config for the current operator,
            // or the first one available (if source has changed)
            const selectedOperator = get(data, operatorField);
            const operatorConfig =
                sourceConfig.operators.find(
                    operator => operator.value === selectedOperator
                ) ?? sourceConfig.operators[0];

            // If the supported operators are different, reset the operator field
            if (operatorConfig.value !== selectedOperator) {
                if (
                    operators.some(
                        operator => operator.value === operatorConfig.value
                    )
                ) {
                    // If the new operator is already in the choices we can
                    // reset the field immediately
                    resetField(operatorField, {
                        defaultValue: operatorConfig.value,
                    });
                } else {
                    // Else we wait one tick (otherwise we get a MUI warning)
                    setTimeout(() => {
                        resetField(operatorField, {
                            defaultValue: operatorConfig.value,
                        });
                    }, 0);
                }
            }

            // Check if operator type has changed
            const operatorTypeChanged =
                operatorConfig.type != oldOperator.current?.type;

            // Check if we should apply the default value for the new operator
            const newOperatorHasDefaultValue =
                operatorConfig?.defaultValue != null;
            const currentValue = getValues(valueField);
            const isValueOldDefault =
                currentValue === oldOperator.current?.defaultValue;
            const isValueEmpty = currentValue == null || currentValue === '';
            const shouldApplyDefaultValue =
                newOperatorHasDefaultValue &&
                (isValueOldDefault || isValueEmpty);

            if (
                sourceChanged ||
                operatorTypeChanged ||
                shouldApplyDefaultValue
            ) {
                resetField(valueField, {
                    defaultValue:
                        operatorConfig?.defaultValue ??
                        sourceConfig?.defaultValue ??
                        '',
                });
            }
            oldOperator.current = operatorConfig;
        });

        return () => {
            unsubscribe();
        };
    }, [
        config,
        getSource,
        getValues,
        operators,
        resetField,
        source,
        valueInputSource,
        watch,
    ]);

    return operators.length === 1 ? (
        <TextInput
            className={className}
            source={source}
            type="hidden"
            defaultValue={operators[0].value}
            sx={{ display: 'none' }}
            helperText={false}
            {...rest}
        />
    ) : (
        <SelectInput
            className={className}
            source={source}
            choices={operators}
            optionValue="value"
            optionText="label"
            sx={{ flex: 1 }}
            disabled={operators.length === 0}
            helperText={false}
            defaultValue={operators[0]?.value}
            {...rest}
        />
    );
};

export interface OperatorInputProps extends CommonInputProps {
    operators: FilterOperator[];
    valueInputSource: string;
    config: FiltersConfig;
    className?: string;
}
