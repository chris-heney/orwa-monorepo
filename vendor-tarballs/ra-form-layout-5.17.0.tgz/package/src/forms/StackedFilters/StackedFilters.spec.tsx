/* eslint-disable jest/expect-expect */
import * as React from 'react';
import {
    fireEvent,
    render,
    screen,
    waitFor,
    within,
} from '@testing-library/react';
import * as Stories from '../../../stories/stackedFilters.stories';

describe('StackedFilters', () => {
    test('should display a dropdown menu allowing to apply multiple filters', async () => {
        render(<Stories.Basic />);

        // Wait for the data to load
        await screen.findByText('Sed quo et et fugiat modi');

        // Open the filters menu
        fireEvent.click(screen.getByLabelText('Filters'));

        // Add a filter for the "title" field
        const sourceInput = screen.getByLabelText('Source');
        fireEvent.mouseDown(sourceInput); // Don't use click wih AutocompleteInput
        await waitFor(() => screen.getAllByRole('option'));
        fireEvent.click(
            screen.getByText('Title', { selector: '[role="option"]' })
        );
        fireEvent.blur(sourceInput);

        // Select the "contains" operator
        await screen.findByLabelText('Operator');
        const operatorInput = screen.getByLabelText('Operator');
        fireEvent.mouseDown(operatorInput); // Don't use click wih MUI Selects
        await screen.findByText('Contains');
        fireEvent.click(screen.getByText('Contains'));
        fireEvent.blur(operatorInput);

        // Set the filter value
        await screen.findByLabelText('Value');
        fireEvent.change(screen.getByLabelText('Value'), {
            target: { value: 'volup' },
        });

        // Apply the filter
        fireEvent.click(screen.getByText('Apply'));
        await screen.findByText('1-4 of 4');

        // Open the filters menu
        fireEvent.click(screen.getByLabelText('Filters'));
        fireEvent.click(screen.getByText('Add filter'));

        // Give some time for the inputs to be rendered
        await new Promise(resolve => setTimeout(resolve, 50));
        const sourceInput2 = screen.getAllByLabelText('Source')[1];
        // FIXME: remove when using react-admin >= 5.6.4
        // we need to handle both the AutocompleteInput focusing automatically or not
        if (!screen.queryAllByRole('option').length) {
            // If the AutocompleteInput doesn't focus automatically, we need to click on it
            fireEvent.mouseDown(sourceInput2);
        }
        await waitFor(() => screen.getAllByRole('option'));
        // Add a filter for the "is_public" field
        fireEvent.click(
            screen.getByText('Is public', { selector: '[role="option"]' })
        );
        fireEvent.blur(sourceInput2);
        await screen.findByLabelText('Is true');

        // Set its value to true by checking the checkbox
        fireEvent.click(screen.getByLabelText('Is true'));

        // Apply the filter
        fireEvent.click(screen.getByText('Apply'));
        await screen.findByText('1-1 of 1');
    }, 20000); // The test is long so we need a greater timeout

    test('should display applied filters', async () => {
        render(<Stories.ExistingFilters />);

        // Wait for the data to load
        await screen.findByText('1-1 of 1');

        const filterButton = screen.getByLabelText('Filters');
        await within(filterButton.closest('span') as HTMLElement).findByText(
            '2'
        );

        // Open the filters menu
        fireEvent.click(filterButton);

        // Check that the filters are displayed
        await screen.findByDisplayValue('Title');
        await screen.findByDisplayValue('q');
        await screen.findByDisplayValue('volup');

        await screen.findByDisplayValue('Is public');
    });

    test('should allow to remove one filter', async () => {
        render(<Stories.ExistingFilters />);

        // Wait for the data to load
        await screen.findByText('1-1 of 1');

        const filterButton = screen.getByLabelText('Filters');

        // Open the filters menu
        fireEvent.click(filterButton);

        // Remove the is_public filter
        fireEvent.click(screen.getAllByLabelText('Remove')[1]);

        // Apply the filter
        fireEvent.click(screen.getByText('Apply'));
        await screen.findByText('1-4 of 4');
    });

    test('should allow to remove all filters', async () => {
        render(<Stories.ExistingFilters />);

        // Wait for the data to load
        await screen.findByText('1-1 of 1');
        await screen.findByText('Qui tempore rerum et voluptates');

        // Open the filters menu
        const filterButton = screen.getByLabelText('Filters');
        fireEvent.click(filterButton);

        // Wait for filters to be loaded
        await screen.findByDisplayValue('Is public');

        // Remove the all filters
        fireEvent.click(screen.getByText('Remove all filters'));

        await screen.findByText('1-10 of 13', undefined, { timeout: 5000 });
    });

    test('should reset the filter value when selecting an operator accepting multiple values when coming from an operator that do not', async () => {
        render(<Stories.SameOperatorDifferentTypes />);

        // Wait for the data to load
        await screen.findByText('1-5 of 5');

        // Open the filters menu
        const filterButton = screen.getByLabelText('Filters');
        fireEvent.click(filterButton);

        await screen.findByDisplayValue('react');
        // Select an operator that accepts multiple values
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('One of'));
        // The value input should be reset
        expect(screen.queryByDisplayValue('react')).toBeNull();
    });

    test('should not reset the filter value when selecting an operator accepting a single value when coming from an operator that does too', async () => {
        render(<Stories.SameOperatorDifferentTypes />);

        // Wait for the data to load
        await screen.findByText('1-5 of 5');

        // Open the filters menu
        const filterButton = screen.getByLabelText('Filters');
        fireEvent.click(filterButton);

        await screen.findByDisplayValue('react');
        // Select an operator that accepts multiple values
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Not equal'));
        // The value input should not be reset
        expect(screen.queryByDisplayValue('react')).not.toBeNull();
    });

    test('should reset the filter value when selecting an operator accepting a single value when coming from an operator that does not', async () => {
        render(
            <Stories.SameOperatorDifferentTypes
                initialFilter={{ tag_in: ['react', 'vue'] }}
            />
        );

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        await screen.findByDisplayValue('react,vue');
        // Select an operator that accepts multiple values
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Equal'));
        // The value input should be reset
        expect(screen.queryByDisplayValue('react,vue')).toBeNull();
    });

    test('should not reset the filter value when selecting an operator accepting multiple values when coming from an operator that does too', async () => {
        render(
            <Stories.SameOperatorDifferentTypes
                initialFilter={{ tag_in: ['react', 'vue'] }}
            />
        );

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        await screen.findByDisplayValue('react,vue');
        // Select an operator that accepts multiple values
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Not one of'));
        // The value input should not be reset
        expect(screen.queryByDisplayValue('react,vue')).not.toBeNull();
    });

    test('should reset the operator value when selecting a source that have different supported operators', async () => {
        const { container } = render(
            <Stories.SameOperatorDifferentTypes
                initialFilter={{ tag_in: ['react', 'vue', 'solid'] }}
            />
        );

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        await screen.findByDisplayValue('react,vue,solid');
        screen.getByText('One of');

        // Select a source that not accepts 'One of' operator
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(await screen.findByText('Title'));

        // The value input should be reset
        expect(screen.queryByDisplayValue('react,vue, solid')).toBeNull();
        // The operator value should be reset
        expect(screen.queryByText('One of')).toBeNull();

        // The first available operator should be selected
        await screen.findByText('Equals');

        within(
            container.querySelector('.MuiBadge-badge') as HTMLElement
        ).getByText('1');
        // Filter applied should be reset
        fireEvent.click(screen.getByText('Apply'));
        await screen.findByText('1-10 of 13');
        expect(
            within(
                container.querySelector('.MuiBadge-badge') as HTMLElement
            ).queryByText('1')
        ).toBeNull();
    });

    test('should reset the filter value but not reset the operator value when selecting a source that support the currently selected operator', async () => {
        render(
            <Stories.SameOperatorDifferentTypes
                initialFilter={{ tag_neq: 'react' }}
            />
        );

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        await screen.findByDisplayValue('react');
        screen.getByText('Not equal');

        // Select a source that accepts 'Not equal' operator
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(await screen.findByRole('option', { name: 'Title' }));

        // The value input should be reset
        expect(screen.queryByDisplayValue('react')).toBeNull();
        // The operator value should not be reset
        expect(screen.queryByText('Not equals')).not.toBeNull();
    });

    test('should apply the defaultValue of a filter', async () => {
        render(<Stories.DefaultValue />);

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        // Select the source of the new filter
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(await screen.findByRole('option', { name: 'Id' }));

        expect(screen.getByLabelText('Value')).toHaveProperty('value', '0');
    });

    test('should apply the defaultValue of an operator', async () => {
        render(<Stories.DefaultValue />);

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        // Select the source of the new filter
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(
            await screen.findByRole('option', { name: 'Author name' })
        );

        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Alice');
    });

    test('should apply the defaultValue of a new operator when the value is empty', async () => {
        render(<Stories.DefaultValue />);

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        // Select the source of the new filter
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(
            await screen.findByRole('option', { name: 'Author name' })
        );
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Alice');

        // reset the value and select the new operator
        fireEvent.change(screen.getByLabelText('Value'), {
            target: { value: '' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Not equal'));
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Bob');
    });

    test("should not apply the defaultValue of a new operator of the same type as the previous operator when the value isn't empty", async () => {
        render(<Stories.DefaultValue />);

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        // Select the source of the new filter
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(
            await screen.findByRole('option', { name: 'Author name' })
        );
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Alice');

        // update the value and select the new operator
        fireEvent.change(screen.getByLabelText('Value'), {
            target: { value: 'toto' },
        });
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Not equal'));
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'toto');
    });

    test("should apply the defaultValue of a new operator when the value is the same that the old operator's defaultValue", async () => {
        render(<Stories.DefaultValue />);

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        // Select the source of the new filter
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(
            await screen.findByRole('option', { name: 'Author name' })
        );
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Alice');

        // select the new operator
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Not equal'));
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Bob');
    });

    test("shouldn't apply the defaultValue of a new operator when the value isn't the same that the old operator's defaultValue and both operators have the same type", async () => {
        render(<Stories.DefaultValue />);

        // Open the filters menu
        const filterButton = await screen.findByLabelText('Filters');
        fireEvent.click(filterButton);

        // Select the source of the new filter
        fireEvent.mouseDown(screen.getByLabelText('Source'));
        fireEvent.click(
            await screen.findByRole('option', { name: 'Author name' })
        );
        expect(screen.getByLabelText('Value')).toHaveProperty('value', 'Alice');

        fireEvent.change(screen.getByLabelText('Value'), {
            target: { value: 'Aliceeee' },
        });
        // select the new operator
        fireEvent.mouseDown(screen.getByLabelText('Operator'));
        fireEvent.click(await screen.findByText('Not equal'));
        expect(screen.getByLabelText('Value')).toHaveProperty(
            'value',
            'Aliceeee'
        );
    });
});
