import * as React from 'react';
import { useCallback } from 'react';
import {
    ArrayInput,
    Form,
    FormDataConsumer,
    RemoveItemButton,
    SimpleFormIterator,
    TextInput,
    useListContext,
    useTranslate,
} from 'react-admin';
import { styled, SxProps } from '@mui/material';
import clsx from 'clsx';
import { getListFiltersFromFormValues } from './getListFiltersFromFormValues';
import { getFormValuesFromListFilters } from './getFormValuesFromListFilters';
import { FiltersConfig } from './types';
import { StackedFiltersFormActions } from './StackedFiltersActions';
import { SourceInput } from './SourceInput';
import { OperatorInput } from './OperatorInput';

/**
 * An alternative to the <Filter> component that add the concept of operator.
 * It allows users to apply an operator with a value to multiple fields.
 *
 * @example
 * import { List, NumberInput } from 'react-admin';
 * import { StackedFilters, FiltersConfig, textFilter, numberFilter, referenceFilter, booleanFilter } from '@react-admin/ra-form-layout';
 * import { MyNumberRangeInput } from './MyNumberRangeInput';
 *
 * const PostListFilters: FiltersConfig = {
 *     title: textFilter(),
 *     views: numberFilter(),
 *     tags: referenceFilter({ reference: 'tags' }),
 *     published: booleanFilter(),
 *     note: {
 *         operators: [
 *            { value: 'eq', label: 'Equals' },
 *            { value: 'neq', label: 'Not Equals' },
 *            { value: 'between', label: 'Between', input: ({ source }) => <MyNumberRangeInput source={source} /> },
 *         ],
 *         input: ({ source }) => <NumberInput source={source} />,
 *     }
 * };
 * const PostList = (props) => (
 *    <ListBase {...props}>
 *       <Accordion>
 *           <AccordionSummary
 *               expandIcon={<ExpandMoreIcon />}
 *               aria-controls="filters-panel-content"
 *               id="filters-panel-header"
 *           >
 *               <Typography>Filters</Typography>
 *           </AccordionSummary>
 *           <AccordionDetails>
 *               <StackedFiltersForm config={PostListFilters} />
 *           </AccordionDetails>
 *       </Accordion>
 *       ...
 *     </ListBase>
 * );
 * @param props
 * @param props.config {FilterConfig} The filters configuration.
 * @param props.onFiltersApplied Callback function called after the filters have been applied.
 * @returns A filter form for a <List>.
 */
export const StackedFiltersForm = (props: StackedFiltersFormProps) => {
    const { className, config, onFiltersApplied, sx } = props;
    const translate = useTranslate();
    const { filterValues, setFilters } = useListContext();

    const onApplyFilters = useCallback(
        values => {
            const { filters } = values;
            const newFilters = getListFiltersFromFormValues(filters);

            setFilters(
                newFilters,
                Object.keys(newFilters).reduce((acc, key) => {
                    acc[key] = true;
                    return acc;
                }, {})
            );

            if (onFiltersApplied && typeof onFiltersApplied === 'function') {
                onFiltersApplied();
            }
        },
        [onFiltersApplied, setFilters]
    );

    const appliedFilters = {
        filters: getFormValuesFromListFilters(filterValues, config),
    };

    const sourceChoices = Object.keys(config).map(source => ({
        id: source,
        name: source,
        label: config[source].label,
    }));

    return (
        <Root
            className={clsx(StackedFiltersFormClasses.root, className)}
            onSubmit={onApplyFilters}
            defaultValues={appliedFilters}
            sx={sx}
        >
            <ArrayInput label={false} source="filters">
                <SimpleFormIterator
                    inline
                    disableReordering
                    disableClear
                    addButton={
                        <StackedFiltersFormActions
                            onFiltersApplied={onFiltersApplied}
                        />
                    }
                    removeButton={<RemoveItemButton />}
                    sx={{
                        '& .RaSimpleFormIterator-inline': {
                            width: '100%',
                            alignItems: 'center',
                        },
                        '& .RaSimpleFormIterator-action': {
                            display: 'flex',
                            alignItems: 'center',
                        },
                        '& .RaSimpleFormIterator-add': {
                            marginTop: 1,
                            width: '100%',
                        },
                    }}
                >
                    <SourceInput
                        className={StackedFiltersFormClasses.sourceInput}
                        source="source"
                        label={translate('ra-form-layout.filters.source', {
                            _: 'Source',
                        })}
                        choices={sourceChoices}
                    />
                    <FormDataConsumer>
                        {({ scopedFormData }) => {
                            if (!scopedFormData) return null;
                            const source = scopedFormData.source;
                            const { operators } = config[source] ?? {
                                operators: [],
                            };

                            return (
                                <OperatorInput
                                    className={
                                        StackedFiltersFormClasses.operatorInput
                                    }
                                    source="operator"
                                    operators={operators}
                                    label={translate(
                                        'ra-form-layout.filters.operator',
                                        {
                                            _: 'Operator',
                                        }
                                    )}
                                    valueInputSource="value"
                                    config={config}
                                />
                            );
                        }}
                    </FormDataConsumer>
                    <FormDataConsumer>
                        {({ scopedFormData }) => {
                            if (!scopedFormData) return null;
                            const source = scopedFormData.source;
                            const operator = scopedFormData.operator;

                            const { operators, input } = config[source] ?? {
                                operators: [],
                                // eslint-disable-next-line react/display-name
                                input: ({ source }) => (
                                    <TextInput
                                        className={
                                            StackedFiltersFormClasses.valueInput
                                        }
                                        label={translate(
                                            'ra-form-layout.filters.value',
                                            {
                                                _: 'Value',
                                            }
                                        )}
                                        source={source}
                                        disabled
                                        helperText={false}
                                    />
                                ),
                            };

                            const operatorConfig = operators.find(
                                o => o.value === operator
                            );

                            return operatorConfig && operatorConfig.input
                                ? operatorConfig.input({
                                      className:
                                          StackedFiltersFormClasses.valueInput,
                                      operator,
                                      source: 'value',
                                      label: translate(
                                          'ra-form-layout.filters.value',
                                          {
                                              _: 'Value',
                                          }
                                      ),
                                  })
                                : input
                                  ? input({
                                        className:
                                            StackedFiltersFormClasses.valueInput,
                                        operator,
                                        source: 'value',
                                        label: translate(
                                            'ra-form-layout.filters.value',
                                            {
                                                _: 'Value',
                                            }
                                        ),
                                    })
                                  : null;
                        }}
                    </FormDataConsumer>
                </SimpleFormIterator>
            </ArrayInput>
        </Root>
    );
};

export interface StackedFiltersFormProps {
    className?: string;
    config: FiltersConfig;
    onFiltersApplied?: () => void;
    sx?: SxProps;
}

const PREFIX = 'RaStackedFiltersForm';

export const StackedFiltersFormClasses = {
    root: `${PREFIX}-root`,
    sourceInput: `${PREFIX}-sourceInput`,
    operatorInput: `${PREFIX}-operatorInput`,
    valueInput: `${PREFIX}-valueInput`,
};

const Root = styled(Form, {
    name: PREFIX,
    overridesResolver: (props: any, styles) => styles.root,
})(() => ({
    [`* .${StackedFiltersFormClasses.valueInput}`]: {
        justifyContent: 'center',
    },
}));
