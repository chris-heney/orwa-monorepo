import { FiltersConfig } from './types';

type Filter = {
    source?: string;
    operator?: string;
    value?: any;
};
type Filters = Filter[];

/**
 * Converts a list of filters to a list of filter form values.
 *
 * @param {Record<string, any>} filterValues The filters from the ListContext, an object with the following shape: { foo_eq: 'bar' }
 * @param {FiltersConfig} config The StackedFilters config
 * @returns {Filters} The form values as an array of objects with the following shape: { source: 'foo', operator: 'eq', value: 'bar' }.
 */
export const getFormValuesFromListFilters = (
    filterValues: Record<string, any>,
    config: FiltersConfig
): Filters => {
    const filters: Filters = [];

    Object.keys(filterValues).forEach(key => {
        const parts = key.split('_');
        let sourcePartIndex = 0;
        let source = parts[0];

        while (config[source] == null && sourcePartIndex <= parts.length) {
            source += `_${parts[++sourcePartIndex]}`;
        }

        if (config[source] == null) {
            return;
        }

        const operator = key.replace(`${source}_`, '');

        if (config[source].operators.find(o => o.value === operator) == null) {
            return;
        }

        const value = filterValues[key];

        filters.push({
            source,
            operator,
            value,
        });
    });

    if (filters.length === 0) {
        return [{}];
    }

    return filters;
};
