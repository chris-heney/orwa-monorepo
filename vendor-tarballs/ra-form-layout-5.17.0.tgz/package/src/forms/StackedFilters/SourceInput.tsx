import * as React from 'react';
import {
    AutocompleteInput,
    AutocompleteInputProps,
    useResourceContext,
    useTranslateLabel,
} from 'react-admin';

export const SourceInput = ({
    source,
    choices,
    ...rest
}: AutocompleteInputProps) => {
    const resource = useResourceContext();
    const translateLabel = useTranslateLabel();
    return (
        <AutocompleteInput
            source={source}
            choices={choices}
            optionText={choice =>
                translateLabel({
                    label: choice.label,
                    resource,
                    source: choice.name,
                })
            }
            helperText={false}
            sx={{ flex: 1 }}
            {...rest}
        />
    );
};
