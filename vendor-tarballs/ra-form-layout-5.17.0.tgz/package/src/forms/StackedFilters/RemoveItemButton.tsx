import * as React from 'react';
import { useCallback } from 'react';
import CloseIcon from '@mui/icons-material/RemoveCircleOutline';
import {
    ButtonProps,
    IconButtonWithTooltip,
    useSimpleFormIterator,
    useSimpleFormIteratorItem,
} from 'react-admin';

export const RemoveItemButton = ({ onClick, ...props }: ButtonProps) => {
    const { add, total } = useSimpleFormIterator();
    const { remove } = useSimpleFormIteratorItem();

    const handleClick = useCallback(() => {
        remove();
        // We don't want the filter list to be empty so we add a new empty filter
        // if that was the last one
        if (total === 1) {
            add();
        }
    }, [add, remove, total]);

    return (
        <IconButtonWithTooltip
            label="ra.action.remove"
            size="small"
            onClick={handleClick}
            color="warning"
            {...props}
        >
            <CloseIcon fontSize="small" />
        </IconButtonWithTooltip>
    );
};
