import { WizardFormContextValue } from './WizardFormContext';
export declare const WizardFormStepContext: import("react").Context<WizardFormStepContextValue | undefined>;
export interface WizardFormStepContextValue extends WizardFormContextValue {
    active: boolean;
    step: number;
}
//# sourceMappingURL=WizardFormStepContext.d.ts.map