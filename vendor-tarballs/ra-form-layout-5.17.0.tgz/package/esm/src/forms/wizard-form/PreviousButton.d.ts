import { ButtonProps } from '@mui/material';
export declare const PreviousButton: ({ disabled, ...rest }: PreviousButtonProps) => import("react/jsx-runtime").JSX.Element | null;
export type PreviousButtonProps = ButtonProps;
//# sourceMappingURL=PreviousButton.d.ts.map