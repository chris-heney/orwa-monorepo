import * as React from 'react';
import { ReactNode } from 'react';
export declare const WizardFormView: ({ authorizationError, children, enableAccessControl, loading, toolbar, progress, }: WizardFormViewProps) => string | number | boolean | Iterable<React.ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
export interface WizardFormViewProps {
    authorizationError?: ReactNode;
    className?: string;
    enableAccessControl?: boolean;
    loading?: ReactNode;
    children: ReactNode;
    progress?: ReactNode;
    toolbar?: ReactNode;
}
//# sourceMappingURL=WizardFormView.d.ts.map