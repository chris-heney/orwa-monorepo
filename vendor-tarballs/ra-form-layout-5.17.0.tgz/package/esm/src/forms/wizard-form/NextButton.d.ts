import { ButtonProps } from '@mui/material';
export declare const NextButton: ({ disabled, ...rest }: NextButtonProps) => import("react/jsx-runtime").JSX.Element | null;
export type NextButtonProps = ButtonProps;
//# sourceMappingURL=NextButton.d.ts.map