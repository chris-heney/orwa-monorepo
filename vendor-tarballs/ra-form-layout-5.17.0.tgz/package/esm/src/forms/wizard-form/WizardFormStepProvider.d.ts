import { ReactNode } from 'react';
export declare const WizardFormStepProvider: ({ children, step, }: {
    children: ReactNode;
    step: number;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=WizardFormStepProvider.d.ts.map