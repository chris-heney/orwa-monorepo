import { ReactElement } from 'react';
import { WizardFormStepProps } from './WizardFormStep';
export declare const WizardFormContext: import("react").Context<WizardFormContextValue | undefined>;
export interface WizardFormContextValue {
    currentStep: number;
    hasPreviousStep: boolean;
    hasNextStep: boolean;
    goToNextStep: () => void;
    goToPreviousStep: () => void;
    goToStep: (step: number) => void;
    steps: ReactElement<WizardFormStepProps>[];
}
//# sourceMappingURL=WizardFormContext.d.ts.map