import * as React from 'react';
import { ReactElement, ReactNode } from 'react';
import { SxProps } from '@mui/material';
export declare const AccordionFormView: ({ authorizationError, autoClose, children, className, enableAccessControl, loading, resource, toolbar, sx, }: AccordionFormViewProps) => string | number | boolean | Iterable<React.ReactNode> | import("react/jsx-runtime").JSX.Element | null;
export interface AccordionFormViewProps {
    autoClose?: boolean;
    authorizationError?: ReactNode;
    children?: ReactNode;
    className?: string;
    enableAccessControl?: boolean;
    loading?: ReactNode;
    resource?: string;
    submitOnEnter?: boolean;
    toolbar?: ReactElement;
    sx?: SxProps;
}
export declare const findAccordionsWithErrors: (children: ReactNode, errors: any) => string[];
//# sourceMappingURL=AccordionFormView.d.ts.map