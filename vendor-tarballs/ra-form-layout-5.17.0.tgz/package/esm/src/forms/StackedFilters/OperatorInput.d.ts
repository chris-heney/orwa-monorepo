import { CommonInputProps } from 'react-admin';
import type { FilterOperator, FiltersConfig } from './types';
export declare const OperatorInput: ({ className, operators, source, valueInputSource, config, ...rest }: OperatorInputProps) => import("react/jsx-runtime").JSX.Element;
export interface OperatorInputProps extends CommonInputProps {
    operators: FilterOperator[];
    valueInputSource: string;
    config: FiltersConfig;
    className?: string;
}
//# sourceMappingURL=OperatorInput.d.ts.map