import { ButtonProps } from 'react-admin';
export declare const RemoveItemButton: ({ onClick, ...props }: ButtonProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RemoveItemButton.d.ts.map