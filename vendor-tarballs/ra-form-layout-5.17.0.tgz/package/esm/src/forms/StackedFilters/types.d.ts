import { ReactElement } from 'react';
/**
 * Constructs a string type with type hints for known values.
 * TODO: Remove when react-admin 5.3.0 is released as it will export it
 */
type HintedString<KnownValues extends string> = (string & {}) | KnownValues;
export type FilterOperator = {
    label: string;
    value: string;
    input?: FilterInput;
    type?: HintedString<'single' | 'multiple'>;
    defaultValue?: any;
};
export type FilterOperatorProps = {
    className?: string;
    operator: string;
    source: string;
    label?: string | ReactElement;
};
export type FilterDefinition = {
    label?: string | ReactElement;
    operators: FilterOperator[];
    input?: FilterInput;
    defaultValue?: any;
};
export type FilterInput = (props: FilterOperatorProps) => ReactElement;
export type FiltersConfig = Record<string, FilterDefinition>;
export {};
//# sourceMappingURL=types.d.ts.map