import { SxProps } from '@mui/material';
export declare const StackedFiltersFormActions: (props: StackedFiltersFormActions) => import("react/jsx-runtime").JSX.Element;
export interface StackedFiltersFormActions {
    className?: string;
    onFiltersApplied?: () => void;
    sx?: SxProps;
}
export declare const StackedFiltersActionsClasses: {
    root: string;
    addFilterButton: string;
    removeFiltersButton: string;
    applyButton: string;
};
//# sourceMappingURL=StackedFiltersActions.d.ts.map