import { FiltersConfig } from './types';
type Filter = {
    source?: string;
    operator?: string;
    value?: any;
};
type Filters = Filter[];
/**
 * Converts a list of filters to a list of filter form values.
 *
 * @param {Record<string, any>} filterValues The filters from the ListContext, an object with the following shape: { foo_eq: 'bar' }
 * @param {FiltersConfig} config The StackedFilters config
 * @returns {Filters} The form values as an array of objects with the following shape: { source: 'foo', operator: 'eq', value: 'bar' }.
 */
export declare const getFormValuesFromListFilters: (filterValues: Record<string, any>, config: FiltersConfig) => Filters;
export {};
//# sourceMappingURL=getFormValuesFromListFilters.d.ts.map