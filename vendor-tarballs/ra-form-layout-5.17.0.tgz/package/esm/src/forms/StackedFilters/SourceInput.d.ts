import { AutocompleteInputProps } from 'react-admin';
export declare const SourceInput: ({ source, choices, ...rest }: AutocompleteInputProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SourceInput.d.ts.map