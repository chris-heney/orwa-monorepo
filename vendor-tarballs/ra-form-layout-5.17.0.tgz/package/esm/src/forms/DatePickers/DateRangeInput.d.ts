import { CommonInputProps } from 'react-admin';
import { DatePickerProps } from '@mui/x-date-pickers-pro';
/**
 * Form input to edit a range of dates.
 * Renders a date range picker from Mui X (https://mui.com/x/react-date-pickers/date-range-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { DateRangeInput } from '@react-admin/ra-form-layout/DateRangeInput';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <DateRangeInput source="subscription_period" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // DateRangeInput return a Date object array but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <DateRangeInput source="inscription_period" parse={dates => dates ? dates.map(date => (date ? date.toISOString() : null)) : null } />
 */
export declare const DateRangeInput: ({ className, format, fullWidth, helperText, label, mask, resource, slotProps, source, variant, defaultValue, ...rest }: DateRangeInputProps) => import("react/jsx-runtime").JSX.Element;
export type DateRangeInputProps = CommonInputProps & Omit<DatePickerProps<Date>, 'helperText' | 'label' | 'format' | 'defaultValue'> & {
    mask?: DatePickerProps<Date>['format'];
};
//# sourceMappingURL=DateRangeInput.d.ts.map