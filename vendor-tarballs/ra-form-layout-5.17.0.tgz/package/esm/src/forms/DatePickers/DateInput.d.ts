import { CommonInputProps } from 'react-admin';
import { DatePickerProps } from '@mui/x-date-pickers';
/**
 * Form input to edit a Date string value or a Date object.
 * Renders a date picker from Mui X (https://mui.com/x/react-date-pickers/date-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { DateInput } from '@react-admin/ra-form-layout';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <DateInput source="published_at" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // DateInput return a Date object but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <DateInput source="published" parse={(date: Date) => (date ? date.toISOString() : null)} />
 */
export declare const DateInput: (props: DateInputProps) => import("react/jsx-runtime").JSX.Element;
export type DateInputProps = CommonInputProps & Omit<DatePickerProps<Date>, 'helperText' | 'label' | 'format'> & {
    mask?: DatePickerProps<Date>['format'];
};
//# sourceMappingURL=DateInput.d.ts.map