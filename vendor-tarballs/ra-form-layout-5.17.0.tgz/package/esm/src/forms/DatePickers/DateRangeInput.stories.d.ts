import { SimpleFormProps } from 'react-admin';
import { DateRangeInputProps } from './DateRangeInput';
declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const ClassName: () => import("react/jsx-runtime").JSX.Element;
export declare const NonFullWidth: () => import("react/jsx-runtime").JSX.Element;
export declare const ParseAndFormat: () => import("react/jsx-runtime").JSX.Element;
export declare const ParseAsISO: () => import("react/jsx-runtime").JSX.Element;
export declare const ParseAsDate: () => import("react/jsx-runtime").JSX.Element;
export declare const HelperText: () => import("react/jsx-runtime").JSX.Element;
export declare const Label: () => import("react/jsx-runtime").JSX.Element;
export declare const Mask: () => import("react/jsx-runtime").JSX.Element;
export declare const SlotProps: () => import("react/jsx-runtime").JSX.Element;
export declare const Variant: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValues: ({ onSubmit, defaultValues, defaultValue, ...rest }: {
    onSubmit?: SimpleFormProps["onSubmit"];
    defaultValues?: SimpleFormProps["defaultValues"];
} & Partial<DateRangeInputProps>) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValuesString: () => import("react/jsx-runtime").JSX.Element;
export declare const Disabled: () => import("react/jsx-runtime").JSX.Element;
export declare const ReadOnly: () => import("react/jsx-runtime").JSX.Element;
export declare const Required: ({ onSubmit, defaultValues, }: {
    onSubmit?: SimpleFormProps["onSubmit"];
    defaultValues?: SimpleFormProps["defaultValues"];
}) => import("react/jsx-runtime").JSX.Element;
export declare const Validate: ({ onSubmit, }: {
    onSubmit?: SimpleFormProps["onSubmit"];
}) => import("react/jsx-runtime").JSX.Element;
export declare const OnChange: () => import("react/jsx-runtime").JSX.Element;
export declare const WithLocalizationProvider: ({ defaultValues, }: {
    defaultValues?: SimpleFormProps["defaultValues"];
}) => import("react/jsx-runtime").JSX.Element;
export declare const UseAsFilter: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DateRangeInput.stories.d.ts.map