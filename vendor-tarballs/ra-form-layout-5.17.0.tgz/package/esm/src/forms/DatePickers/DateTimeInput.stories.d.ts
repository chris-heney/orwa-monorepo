import { SimpleFormProps } from 'react-admin';
import { DateTimeInputProps } from './DateTimeInput';
declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValues: ({ onSubmit, defaultValues, ...rest }: {
    onSubmit?: SimpleFormProps["onSubmit"];
    defaultValues?: SimpleFormProps["defaultValues"];
} & Partial<DateTimeInputProps>) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValuesString: () => import("react/jsx-runtime").JSX.Element;
export declare const Label: () => import("react/jsx-runtime").JSX.Element;
export declare const Mask: () => import("react/jsx-runtime").JSX.Element;
export declare const ParseAsISO: () => import("react/jsx-runtime").JSX.Element;
export declare const ParseAsDateTime: () => import("react/jsx-runtime").JSX.Element;
export declare const NotFullWidth: () => import("react/jsx-runtime").JSX.Element;
export declare const Disabled: () => import("react/jsx-runtime").JSX.Element;
export declare const Required: ({ onSubmit, defaultValues, }: {
    onSubmit?: SimpleFormProps["onSubmit"];
    defaultValues?: SimpleFormProps["defaultValues"];
}) => import("react/jsx-runtime").JSX.Element;
export declare const HelperText: () => import("react/jsx-runtime").JSX.Element;
export declare const Variant: () => import("react/jsx-runtime").JSX.Element;
export declare const Validate: () => import("react/jsx-runtime").JSX.Element;
export declare const WithLocalizationProvider: ({ onSubmit, defaultValues, }: {
    onSubmit?: SimpleFormProps["onSubmit"];
    defaultValues?: SimpleFormProps["defaultValues"];
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DateTimeInput.stories.d.ts.map