import { CommonInputProps } from 'react-admin';
import { TimePickerProps } from '@mui/x-date-pickers';
/**
 * Form input to edit the Time of a Date string value or a Date object.
 * Renders a time picker from Mui X (https://mui.com/x/react-date-pickers/time-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { TimeInput } from '@react-admin/ra-form-layout';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <TimeInput source="published_at" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // TimeInput return a Date object but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <TimeInput source="published" parse={(date: Date) => (date ? date.toISOString() : null)} />
 */
export declare const TimeInput: (props: TimeInputProps) => import("react/jsx-runtime").JSX.Element;
export type TimeInputProps = CommonInputProps & Omit<TimePickerProps<Date>, 'helperText' | 'label' | 'format'> & {
    mask?: TimePickerProps<Date>['format'];
};
//# sourceMappingURL=TimeInput.d.ts.map