import { ReactNode } from 'react';
export declare const WithLocalizationProvider: ({ children, }: {
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=WithLocalizationProvider.d.ts.map