import { ReactNode } from 'react';
export declare const WithLocalizationProviderPro: ({ children, }: {
    children: ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=WithLocalizationProviderPro.d.ts.map