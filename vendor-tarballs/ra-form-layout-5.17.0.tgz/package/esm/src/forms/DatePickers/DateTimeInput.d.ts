import { CommonInputProps } from 'react-admin';
import { DateTimePickerProps } from '@mui/x-date-pickers';
/**
 * Form input to edit the Time of a Date string value or a Date object.
 * Renders a date time picker from Mui X (https://mui.com/x/react-date-pickers/date-time-picker/).
 *
 * @example
 * import { Edit, SimpleForm } from 'react-admin';
 * import { DateTimeInput } from '@react-admin/ra-form-layout';
 *
 * const PostEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <DateTimeInput source="published_at" />
 *         </SimpleForm>
 *     </Edit>
 * );
 *
 * @example
 * // DateTimeInput return a Date object but you can pass a custom parse
 * // method to convert the form value to an ISO string.
 * <DateTimeInput source="published" parse={(date: Date) => (date ? date.toISOString() : null)} />
 */
export declare const DateTimeInput: (props: DateTimeInputProps) => import("react/jsx-runtime").JSX.Element;
export type DateTimeInputProps = CommonInputProps & Omit<DateTimePickerProps<Date>, 'helperText' | 'label' | 'format'> & {
    mask?: DateTimePickerProps<Date>['format'];
};
//# sourceMappingURL=DateTimeInput.d.ts.map