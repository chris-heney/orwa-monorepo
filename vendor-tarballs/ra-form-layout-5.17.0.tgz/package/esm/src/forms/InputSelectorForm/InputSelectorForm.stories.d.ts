import { DataProvider } from 'react-admin';
declare const _default: {
    title: string;
    excludeStories: string[];
};
export default _default;
export declare const Basic: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const InDialog: () => import("react/jsx-runtime").JSX.Element;
export declare const Validation: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const I18N: () => import("react/jsx-runtime").JSX.Element;
export declare const NumerousInputs: () => import("react/jsx-runtime").JSX.Element;
export declare const NumerousInputsInDialog: () => import("react/jsx-runtime").JSX.Element;
export declare const InBulkUpdateFormButton: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const dataProvider: DataProvider;
//# sourceMappingURL=InputSelectorForm.stories.d.ts.map