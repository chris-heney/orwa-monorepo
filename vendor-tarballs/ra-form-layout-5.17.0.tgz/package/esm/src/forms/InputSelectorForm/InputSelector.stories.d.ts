declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const NotFullWidth: () => import("react/jsx-runtime").JSX.Element;
export declare const Required: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValue: () => import("react/jsx-runtime").JSX.Element;
export declare const HelperText: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InputSelector.stories.d.ts.map