import { CheckboxGroupInputProps } from 'react-admin';
export declare const InputSelector: (props: InputSelectorProps) => import("react/jsx-runtime").JSX.Element;
export interface InputSelectorProps extends CheckboxGroupInputProps {
    inputs: string[];
}
export declare const InputSelectorClasses: {
    root: string;
};
//# sourceMappingURL=InputSelector.d.ts.map