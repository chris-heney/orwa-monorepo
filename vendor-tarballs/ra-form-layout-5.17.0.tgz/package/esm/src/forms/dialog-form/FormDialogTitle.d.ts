import { MouseEventHandler, ReactNode } from 'react';
import { DialogTitleProps } from '@mui/material';
import { RaRecord } from 'react-admin';
export declare const FormDialogTitle: (props: FormDialogTitleProps) => import("react/jsx-runtime").JSX.Element;
interface FormDialogTitleProps extends Omit<DialogTitleProps, 'title'> {
    defaultTitle?: string;
    onClose: MouseEventHandler<HTMLButtonElement>;
    record?: Partial<RaRecord>;
    title?: ReactNode;
}
export declare const FormDialogTitleClasses: {
    closeButton: string;
};
export {};
//# sourceMappingURL=FormDialogTitle.d.ts.map