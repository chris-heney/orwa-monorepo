export declare const WarnWhenUnsavedChangesInDialog: () => null;
//# sourceMappingURL=WarnWhenUnsavedChangesInDialog.d.ts.map