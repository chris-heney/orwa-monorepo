declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ authorizedActionsEmployers, authorizedActionsCustomers, }: {
        authorizedActionsEmployers: any;
        authorizedActionsCustomers: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        authorizedActionsEmployers: string[];
        authorizedActionsCustomers: never[];
    };
    argTypes: {
        authorizedActionsEmployers: {
            name: string;
            options: string[];
            control: {
                type: string;
            };
        };
        authorizedActionsCustomers: {
            name: string;
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
export declare const FullWidth: () => import("react/jsx-runtime").JSX.Element;
export declare const MaxWidth: () => import("react/jsx-runtime").JSX.Element;
export declare const Label: () => import("react/jsx-runtime").JSX.Element;
export declare const Inline: () => import("react/jsx-runtime").JSX.Element;
export declare const OnClick: ({ onClick, }: {
    onClick?: ((e: any) => void) | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export declare const Transform: () => import("react/jsx-runtime").JSX.Element;
export declare const MutationOptions: () => import("react/jsx-runtime").JSX.Element;
export declare const InReferenceField: () => import("react/jsx-runtime").JSX.Element;
export declare const WarnWhenUnsavedChanges: {
    ({ mutationMode, }: {
        mutationMode?: "undoable" | "pessimistic" | "optimistic";
    }): import("react/jsx-runtime").JSX.Element;
    argTypes: {
        mutationMode: {
            options: (string | undefined)[];
            control: {
                type: string;
            };
        };
    };
};
export declare const WithCustomTitle: {
    (props: {
        title?: "component" | "componentWithContext" | "string" | "null" | "undefined";
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        title: string;
    };
    argTypes: {
        title: {
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
export declare const WithEmptyWhenLoading: {
    ({ delay, emptyWhileLoading, }: {
        delay?: number | undefined;
        emptyWhileLoading?: boolean | undefined;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        delay: number;
        emptyWhileLoading: boolean;
    };
    argTypes: {
        delay: {
            control: {
                type: string;
            };
        };
        emptyWhileLoading: {
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=EditInDialogButton.stories.d.ts.map