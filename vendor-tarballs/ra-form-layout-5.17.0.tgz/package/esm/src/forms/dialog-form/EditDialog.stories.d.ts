export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const Standalone: () => import("react/jsx-runtime").JSX.Element;
declare const _default: {
    title: string;
};
export default _default;
//# sourceMappingURL=EditDialog.stories.d.ts.map