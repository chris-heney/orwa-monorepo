declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ authorizedActionsEmployers, authorizedActionsCustomers, }: {
        authorizedActionsEmployers: any;
        authorizedActionsCustomers: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        authorizedActionsEmployers: string[];
        authorizedActionsCustomers: never[];
    };
    argTypes: {
        authorizedActionsEmployers: {
            name: string;
            options: string[];
            control: {
                type: string;
            };
        };
        authorizedActionsCustomers: {
            name: string;
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
export declare const OnClick: ({ onClick, }: {
    onClick?: ((e: any) => void) | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export declare const WithCustomTitle: {
    (props: {
        title?: "component" | "componentWithContext" | "string" | "null" | "undefined";
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        title: string;
    };
    argTypes: {
        title: {
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=ShowInDialogButton.stories.d.ts.map