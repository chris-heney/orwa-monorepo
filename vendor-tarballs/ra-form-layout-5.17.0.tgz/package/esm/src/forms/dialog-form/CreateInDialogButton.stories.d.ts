declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ authorizedActionsEmployers, authorizedActionsCustomers, }: {
        authorizedActionsEmployers: any;
        authorizedActionsCustomers: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        authorizedActionsEmployers: string[];
        authorizedActionsCustomers: never[];
    };
    argTypes: {
        authorizedActionsEmployers: {
            name: string;
            options: string[];
            control: {
                type: string;
            };
        };
        authorizedActionsCustomers: {
            name: string;
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
export declare const Transform: () => import("react/jsx-runtime").JSX.Element;
export declare const OnClick: ({ onClick, }: {
    onClick?: ((e: any) => void) | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export declare const InReferenceField: () => import("react/jsx-runtime").JSX.Element;
export declare const InputValidation: () => import("react/jsx-runtime").JSX.Element;
export declare const GlobalValidation: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomMutationOptions: () => import("react/jsx-runtime").JSX.Element;
export declare const WarnWhenUnsavedChanges: () => import("react/jsx-runtime").JSX.Element;
export declare const WithCustomTitle: {
    (props: any): import("react/jsx-runtime").JSX.Element;
    args: {
        title: string;
    };
    argTypes: {
        title: {
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=CreateInDialogButton.stories.d.ts.map