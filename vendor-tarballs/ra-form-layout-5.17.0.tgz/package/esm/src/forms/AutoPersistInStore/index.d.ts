export * from './AutoPersistInStore';
//# sourceMappingURL=index.d.ts.map