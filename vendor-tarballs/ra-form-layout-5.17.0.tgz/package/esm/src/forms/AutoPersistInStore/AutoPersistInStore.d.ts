import type { UseAutoPersistInStoreParams } from './useAutoPersistInStore';
export declare const AutoPersistInStore: ({ getStoreKey, notificationMessage, }: UseAutoPersistInStoreParams) => null;
//# sourceMappingURL=AutoPersistInStore.d.ts.map