import type { Identifier, RaRecord, ResourceContextValue } from 'react-admin';
export declare const useAutoPersistInStore: ({ getStoreKey, notificationMessage, }: UseAutoPersistInStoreParams) => void;
export type UseAutoPersistInStoreParams = {
    getStoreKey?: (resource: ResourceContextValue, record: RaRecord<Identifier> | undefined) => string;
    notificationMessage?: string;
};
//# sourceMappingURL=useAutoPersistInStore.d.ts.map