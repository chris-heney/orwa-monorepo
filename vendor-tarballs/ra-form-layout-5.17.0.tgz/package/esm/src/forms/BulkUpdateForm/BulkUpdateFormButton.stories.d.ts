import { DataProvider } from 'react-admin';
import { BulkUpdateFormButtonProps } from './BulkUpdateFormButton';
declare const _default: {
    title: string;
    excludeStories: string[];
};
export default _default;
export declare const Basic: {
    ({ mutationMode, meta, dataProvider: dataProviderProp, }: {
        mutationMode?: BulkUpdateFormButtonProps["mutationMode"];
        meta?: any;
        dataProvider?: DataProvider;
    }): import("react/jsx-runtime").JSX.Element;
    argTypes: {
        mutationMode: {
            options: (string | undefined)[];
            control: {
                type: string;
            };
        };
        meta: {
            control: string;
        };
    };
};
export declare const SlowProvider: {
    ({ mutationMode }: {
        mutationMode: any;
    }): import("react/jsx-runtime").JSX.Element;
    argTypes: {
        mutationMode: {
            options: (string | undefined)[];
            control: {
                type: string;
            };
        };
    };
};
export declare const WithDialogProps: () => import("react/jsx-runtime").JSX.Element;
export declare const Validation: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const WithTabbedForm: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const OnSuccess: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const dataProvider: DataProvider;
//# sourceMappingURL=BulkUpdateFormButton.stories.d.ts.map