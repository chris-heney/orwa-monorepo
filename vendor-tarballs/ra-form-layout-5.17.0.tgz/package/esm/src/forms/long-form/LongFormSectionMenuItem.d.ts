import * as React from 'react';
import { MenuItemProps } from '@mui/material';
export declare const LongFormSectionMenuItem: (props: MenuItemProps & {
    cardinality?: number;
    index: number;
    name: string;
    sectionRefs: React.RefObject<(HTMLElement | undefined)[]>;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LongFormSectionMenuItem.d.ts.map