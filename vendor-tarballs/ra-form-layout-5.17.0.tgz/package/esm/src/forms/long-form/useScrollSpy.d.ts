export interface useScrollSpyParams {
    activeSectionDefault?: number;
    offsetPx?: number;
    sectionElements: (HTMLElement | undefined)[];
    throttleMs?: number;
}
export declare const useScrollSpy: ({ activeSectionDefault, offsetPx, sectionElements, throttleMs, }: useScrollSpyParams) => number;
//# sourceMappingURL=useScrollSpy.d.ts.map