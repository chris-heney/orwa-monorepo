declare const _default: {
    title: string;
};
export default _default;
export declare const BooleanFilter: () => import("react/jsx-runtime").JSX.Element;
export declare const TextFilter: () => import("react/jsx-runtime").JSX.Element;
export declare const NumberFilter: () => import("react/jsx-runtime").JSX.Element;
export declare const DateFilter: () => import("react/jsx-runtime").JSX.Element;
export declare const Choices: () => import("react/jsx-runtime").JSX.Element;
export declare const ChoicesArray: () => import("react/jsx-runtime").JSX.Element;
export declare const Reference: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=stackedFilters.predefined.stories.d.ts.map