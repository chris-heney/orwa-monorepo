import { DataProvider } from 'react-admin';
export declare const Basic: ({ dataProvider, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const OverrideResource: ({ dataProvider, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const SubPath: () => import("react/jsx-runtime").JSX.Element;
export declare const WithCustomTitles: {
    (props: any): import("react/jsx-runtime").JSX.Element;
    args: {
        title: string;
    };
    argTypes: {
        title: {
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
export declare const WithI18nTitles: () => import("react/jsx-runtime").JSX.Element;
export declare const WithTabbedForms: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomRedirect: () => import("react/jsx-runtime").JSX.Element;
export declare const MutationOptionsRedirect: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const WithRecordTitle: () => import("react/jsx-runtime").JSX.Element;
export declare const StandaloneInSimpleForm: () => import("react/jsx-runtime").JSX.Element;
export declare const StandaloneInTabbedForm: () => import("react/jsx-runtime").JSX.Element;
export declare const EmployerEditWithFullyControlledDialogs: () => import("react/jsx-runtime").JSX.Element;
export declare const StandaloneWithFullyControlledCreateDialog: () => import("react/jsx-runtime").JSX.Element;
export declare const Meta: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const OnSuccess: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const OnClose: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const ErrorCase: () => import("react/jsx-runtime").JSX.Element;
export declare const WarnWhenUnsavedChanges: () => import("react/jsx-runtime").JSX.Element;
declare const _default: {
    title: string;
    excludeStories: string[];
};
export default _default;
//# sourceMappingURL=dialogForm.stories.d.ts.map