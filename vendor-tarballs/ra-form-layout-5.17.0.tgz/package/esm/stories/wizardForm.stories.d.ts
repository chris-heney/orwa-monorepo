declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const WithUnique: () => import("react/jsx-runtime").JSX.Element;
export declare const WithSummaryStep: () => import("react/jsx-runtime").JSX.Element;
export declare const I18n: {
    (): import("react/jsx-runtime").JSX.Element;
    storyName: string;
};
export declare const VerticalProgress: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomToolbar: () => import("react/jsx-runtime").JSX.Element;
export declare const WithMultilineTextInputStep: () => import("react/jsx-runtime").JSX.Element;
export declare const AdditiveSteps: () => import("react/jsx-runtime").JSX.Element;
export declare const WithMiddleware: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomProgress: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomSxProgress: () => import("react/jsx-runtime").JSX.Element;
export declare const NoProgress: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ canAccessProtectedInput, canAccessThirdStep, }: {
        canAccessProtectedInput: boolean;
        canAccessThirdStep: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessProtectedInput: boolean;
        canAccessThirdStep: boolean;
    };
    argTypes: {
        canAccessProtectedInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessThirdStep: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const CustomAuthorizationError: ({ canAccessProtectedInput, canAccessThirdStep, }: {
    canAccessProtectedInput: boolean;
    canAccessThirdStep: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const AccessControlSlow: {
    ({ canAccessProtectedInput, canAccessThirdStep, }: {
        canAccessProtectedInput: boolean;
        canAccessThirdStep: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessProtectedInput: boolean;
        canAccessThirdStep: boolean;
    };
    argTypes: {
        canAccessProtectedInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessThirdStep: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const AccessControlOnStepsOnly: {
    ({ canAccessProtectedInput, canAccessThirdStep, }: {
        canAccessProtectedInput: boolean;
        canAccessThirdStep: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessProtectedInput: boolean;
        canAccessThirdStep: boolean;
    };
    argTypes: {
        canAccessProtectedInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessThirdStep: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=wizardForm.stories.d.ts.map