import { ReactElement } from 'react';
import { RaRecord } from 'react-admin';
export declare const getDataProvider: () => import("react-admin").DataProvider;
export declare const dataProvider: import("react-admin").DataProvider;
export declare const sexChoices: {
    id: string;
    name: string;
}[];
export declare const languageChoices: {
    id: string;
    name: string;
}[];
export declare const CustomerTitle: ({ record, }: {
    record?: RaRecord;
}) => ReactElement;
export declare const CustomerForm: (props: any) => import("react/jsx-runtime").JSX.Element;
export declare const CustomerCreate: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomerShow: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomerLayoutForm: (props: any) => import("react/jsx-runtime").JSX.Element;
export declare const CustomerList: () => import("react/jsx-runtime").JSX.Element;
export declare const FormInspector: ({ name }: {
    name?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=common.d.ts.map