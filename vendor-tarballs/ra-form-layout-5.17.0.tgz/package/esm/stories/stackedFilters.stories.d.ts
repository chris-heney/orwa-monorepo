declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const Sx: () => import("react/jsx-runtime").JSX.Element;
export declare const TranslationSupport: () => import("react/jsx-runtime").JSX.Element;
export declare const ExistingFilters: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValue: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomFilter: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomOperator: () => import("react/jsx-runtime").JSX.Element;
export declare const SameOperatorDifferentTypes: ({ initialFilter, }: {
    initialFilter?: Record<string, any>;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=stackedFilters.stories.d.ts.map