export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const Cardinality: () => import("react/jsx-runtime").JSX.Element;
export declare const Toolbar: () => import("react/jsx-runtime").JSX.Element;
export declare const I18n: () => import("react/jsx-runtime").JSX.Element;
export declare const Sx: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ canAccessBornInput, canAccessPreferences, }: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessBornInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const CustomAuthorizationError: ({ canAccessBornInput, canAccessPreferences, }: {
    canAccessBornInput: boolean;
    canAccessPreferences: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const AccessControlSlow: {
    ({ canAccessBornInput, canAccessPreferences, }: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessBornInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const AccessControlOnSectionsOnly: {
    ({ canAccessBornInput, canAccessPreferences, }: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessBornInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
declare const _default: {
    title: string;
};
export default _default;
//# sourceMappingURL=longForm.stories.d.ts.map