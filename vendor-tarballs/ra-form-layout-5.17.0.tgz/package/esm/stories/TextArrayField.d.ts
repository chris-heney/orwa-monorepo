export declare const TextArrayField: ({ source }: {
    source: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TextArrayField.d.ts.map