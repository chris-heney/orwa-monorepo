export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const NotFullWidth: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomStyles: () => import("react/jsx-runtime").JSX.Element;
export declare const Secondary: () => import("react/jsx-runtime").JSX.Element;
export declare const ReactNodeLabelAndSecondary: () => import("react/jsx-runtime").JSX.Element;
export declare const ReactNodeLabelAndSecondaryWithId: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ canAccessLanguageInput, canAccessPreferences, }: {
        canAccessLanguageInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessLanguageInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessLanguageInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const CustomAccessDenied: {
    ({ canAccessLanguageInput, canAccessPreferences, }: {
        canAccessLanguageInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessLanguageInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessLanguageInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const CustomAuthorizationError: {
    ({ canAccessLanguageInput, canAccessPreferences, }: {
        canAccessLanguageInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessLanguageInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessLanguageInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
declare const _default: {
    title: string;
};
export default _default;
//# sourceMappingURL=accordionSection.stories.d.ts.map