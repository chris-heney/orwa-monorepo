import { DataProvider, UpdateResult } from 'react-admin';
declare const _default: {
    title: string;
};
export default _default;
export declare const InSimpleForm: {
    ({ dataProvider, debounce, confirmationDuration, }: {
        dataProvider?: {
            update: (resource: any, params: any) => Promise<UpdateResult>;
            getList: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetListParams & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetListResult<RecordType>>;
            getOne: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetOneParams<RecordType> & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetOneResult<RecordType>>;
            getMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetManyParams<RecordType> & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetManyResult<RecordType>>;
            getManyReference: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetManyReferenceParams & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetManyReferenceResult<RecordType>>;
            updateMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").UpdateManyParams) => Promise<import("react-admin").UpdateManyResult<RecordType>>;
            create: <RecordType extends Omit<import("react-admin").RaRecord, "id"> = any, ResultRecordType extends import("react-admin").RaRecord = RecordType & {
                id: import("react-admin").Identifier;
            }>(resource: string, params: import("react-admin").CreateParams) => Promise<import("react-admin").CreateResult<ResultRecordType>>;
            delete: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").DeleteParams<RecordType>) => Promise<import("react-admin").DeleteResult<RecordType>>;
            deleteMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").DeleteManyParams<RecordType>) => Promise<import("react-admin").DeleteManyResult<RecordType>>;
            supportAbortSignal?: boolean;
        } | undefined;
        debounce: any;
        confirmationDuration: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        debounce: number;
        confirmationDuration: number;
    };
};
export declare const InTabbedForm: () => import("react/jsx-runtime").JSX.Element;
export declare const InAccordionForm: () => import("react/jsx-runtime").JSX.Element;
export declare const InLongForm: () => import("react/jsx-runtime").JSX.Element;
export declare const InWizardForm: () => import("react/jsx-runtime").JSX.Element;
export declare const WithServerSideValidation: () => import("react/jsx-runtime").JSX.Element;
export declare const SubmissionError: () => import("react/jsx-runtime").JSX.Element;
export declare const WithSaveButton: () => import("react/jsx-runtime").JSX.Element;
export declare const FullApp: {
    ({ shouldReject, dataProvider: dataProviderProp, debounce, disableWarnWhenUnsavedChanges, }: {
        dataProvider?: DataProvider;
        debounce: number;
        shouldReject?: boolean;
        disableWarnWhenUnsavedChanges?: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        debounce: number;
        shouldReject: boolean;
        disableWarnWhenUnsavedChanges: boolean;
    };
};
//# sourceMappingURL=AutoSave.optimistic.stories.d.ts.map