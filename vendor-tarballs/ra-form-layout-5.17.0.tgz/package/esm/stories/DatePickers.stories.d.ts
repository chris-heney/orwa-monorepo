declare const _default: {
    title: string;
};
export default _default;
export declare const FullApp: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DatePickers.stories.d.ts.map