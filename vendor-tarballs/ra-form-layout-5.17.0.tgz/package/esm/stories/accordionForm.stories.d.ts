export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const AutoClose: () => import("react/jsx-runtime").JSX.Element;
export declare const AutoCloseWithReactNodeLabel: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomToolbar: () => import("react/jsx-runtime").JSX.Element;
export declare const Secondary: () => import("react/jsx-runtime").JSX.Element;
export declare const ReactNodeLabelAndSecondary: () => import("react/jsx-runtime").JSX.Element;
export declare const ReactNodeLabelAndSecondaryWithId: () => import("react/jsx-runtime").JSX.Element;
export declare const Sx: () => import("react/jsx-runtime").JSX.Element;
export declare const AccessControl: {
    ({ canAccessBornInput, canAccessPreferences, }: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessBornInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
export declare const CustomAuthorizationError: ({ canAccessBornInput, canAccessPreferences, }: {
    canAccessBornInput: boolean;
    canAccessPreferences: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export declare const AccessControlOnTabsOnly: {
    ({ canAccessBornInput, canAccessPreferences, }: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        canAccessBornInput: boolean;
        canAccessPreferences: boolean;
    };
    argTypes: {
        canAccessBornInput: {
            options: boolean[];
            control: {
                type: string;
            };
        };
        canAccessPreferences: {
            options: boolean[];
            control: {
                type: string;
            };
        };
    };
};
declare const _default: {
    title: string;
};
export default _default;
//# sourceMappingURL=accordionForm.stories.d.ts.map