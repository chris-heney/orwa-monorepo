import { getObjectDescriptionParts, getPrompt } from './getPrompt';

describe('getPrompt', () => {
    describe('getObjectDescription', () => {
        it('should return a description of given object', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        title: '',
                        description: '',
                        author: {
                            firstName: '',
                            lastName: '',
                            email: '',
                        },
                        comments: [
                            {
                                content: '',
                                date: new Date(),
                            },
                        ],
                        tags: ['test', 'ai', 'prompt'],
                    },
                    {}
                )
            ).toStrictEqual([
                '- title: A string',
                '- description: A string',
                '- author: An object with:',
                '  - firstName: A string',
                '  - lastName: A string',
                '  - email: A string',
                '- comments: A list of objects with:',
                '  - content: A string',
                '  - date: A date',
                '- tags: A list of string',
            ]);
        });
        it('should use the info from the fieldsDescriptions when the field is in it', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: '',
                    },
                    {
                        theField: 'A field existing to be tested',
                    }
                )
            ).toStrictEqual(['- theField: A field existing to be tested']);
        });
        it('should infer that the field is a string from the form values', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: '',
                    },
                    {}
                )
            ).toStrictEqual(['- theField: A string']);
        });
        it('should infer that the field is a number from the form values', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: 0,
                    },
                    {}
                )
            ).toStrictEqual(['- theField: A number']);
        });
        it('should infer that the field is a boolean from the form values', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: false,
                    },
                    {}
                )
            ).toStrictEqual(['- theField: A boolean']);
        });
        it('should infer that the field is a Date from the form values', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: new Date(),
                    },
                    {}
                )
            ).toStrictEqual(['- theField: A date']);
        });
        it('should infer that the field is a an array of string', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: ['foo', 'bar'],
                    },
                    {}
                )
            ).toStrictEqual(['- theField: A list of string']);
        });
        it('should infer that the field is a an array of object', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: [{ a: 5, b: false }],
                    },
                    {}
                )
            ).toStrictEqual([
                '- theField: A list of objects with:',
                '  - a: A number',
                '  - b: A boolean',
            ]);
        });
        it('should list the field with no additional indication if its value is not set', () => {
            expect(
                getObjectDescriptionParts(
                    {
                        theField: null,
                    },
                    {}
                )
            ).toStrictEqual(['- theField']);
            expect(
                getObjectDescriptionParts(
                    {
                        theField: undefined,
                    },
                    {}
                )
            ).toStrictEqual(['- theField']);
        });
    });

    describe('getPrompt', () => {
        it('should return a prompt based on formValues and fields description', () => {
            expect(
                getPrompt(
                    {
                        title: '',
                        description: '',
                        author: {
                            firstName: '',
                            lastName: '',
                            email: '',
                        },
                        comments: [
                            {
                                content: '',
                                date: new Date(),
                            },
                        ],
                        tags: ['test', 'ai', 'prompt'],
                    },
                    {
                        title: 'The post title',
                    }
                )
            )
                .toStrictEqual(`Extract the following fields from the attached document:
- title: The post title
- description: A string
- author: An object with:
  - firstName: A string
  - lastName: A string
  - email: A string
- comments: A list of objects with:
  - content: A string
  - date: A date
- tags: A list of string

Reply using the JSON format. Do not include any other information.
Do not format the JSON as markdown or any other format.

Only include the fields that are present in the document.
If the document does not contain the required information, set the value to null.`);
        });
    });
});
