import { useState } from 'react';
import { useDataProvider, DataProvider, useEvent } from 'react-admin';
import { useFormContext } from 'react-hook-form';

import { AIDataProvider } from '../../dataProvider/types';
import { getPrompt } from './getPrompt';

type FieldName = string;
type FieldCompletionHint = string;

type UseFillFormPArams = {
    fields?: Record<FieldName, FieldCompletionHint>;
    onError?: (error: Error) => void;
    maxDimension?: number;
    allowOverride?: boolean;
    meta?: any;
};

export const useFillForm = (params: UseFillFormPArams) => {
    const {
        fields,
        onError,
        maxDimension = 1000,
        allowOverride = false,
        meta,
    } = params;
    const dataProvider = useDataProvider<DataProvider & AIDataProvider>();
    const form = useFormContext();
    const [isPending, setIsPending] = useState(false);

    const performCompletion = useEvent(async (file: File) => {
        const attachments = [await rescaleImage(file, maxDimension)];
        try {
            setIsPending(true);
            const prompt = getPrompt(form.getValues(), fields);
            const result = await dataProvider.generateContent({
                systemPrompt: 'You are a structured information extractor',
                prompt,
                temperature: 0.5,
                attachments,
                meta,
            });

            const valuesToInject = JSON.parse(
                result.data,
                // remove null values, see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse#reviver
                (key, value) =>
                    value === null || value === '' ? undefined : value
            );

            if (Object.keys(valuesToInject).length === 0) {
                throw Error('Could not extract any information');
            }
            Object.entries(valuesToInject).map(([key, value]) => {
                if (!allowOverride && form.getValues()[key]) {
                    return;
                }
                form.setValue(key, value ?? '');
            });
        } catch (error) {
            if (onError) {
                onError(error);
            }
        } finally {
            setIsPending(false);
        }
    });

    return { isPending, performCompletion };
};

const rescaleImage = (file: File, maxDimension: number) => {
    return new Promise<File>((resolve, reject) => {
        const image = new Image();
        image.src = URL.createObjectURL(file);
        image.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error('Could not create canvas context'));
                return;
            }
            const scale =
                image.width > maxDimension || image.height > maxDimension
                    ? Math.min(
                          maxDimension / image.width,
                          maxDimension / image.height
                      )
                    : 1;
            canvas.width = image.width * scale;
            canvas.height = image.height * scale;
            ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
            canvas.toBlob(blob => {
                if (blob) {
                    resolve(
                        new File([blob], file.name, { type: 'image/jpeg' })
                    );
                } else {
                    reject(new Error('Could not create blob from canvas'));
                }
            }, 'image/jpeg');
        };
        image.onerror = reject;
    });
};
