import CameraAltIcon from '@mui/icons-material/CameraAlt';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    type DialogProps,
} from '@mui/material';
import {
    default as React,
    useCallback,
    useEffect,
    useRef,
    useState,
} from 'react';
import { useTranslate } from 'react-admin';

export interface ScanFromCameraDialogProps extends DialogProps {
    onClose: () => void;
    onCapture: (datUrl: string) => void;
}

export const ScanFromCameraDialog = ({
    open,
    onClose,
    onCapture,
    ...DialogProps
}: ScanFromCameraDialogProps) => {
    const translate = useTranslate();
    const [width, setWidth] = useState<number | undefined>(undefined);
    const [height, setHeight] = useState<number | undefined>(undefined);
    const intervalRef = useRef<ReturnType<typeof setInterval> | undefined>(
        undefined
    );

    const containerRef = useCallback(node => {
        if (!node) {
            return;
        }

        const containerWidth = parseInt(node.clientWidth, 10);
        const containerHeight = (containerWidth * 9) / 16; // 16:9 aspect ratio

        setWidth(containerWidth);
        setHeight(containerHeight);
    }, []);

    const cameraViewRef = useRef<HTMLCanvasElement | null>(null);

    useEffect(() => {
        if (!width || !height) {
            return;
        }
        let drawInterval: ReturnType<typeof setInterval> | null = null;

        // This forces the ref before the first render
        const timer = setTimeout(async () => {
            if (!cameraViewRef.current || !navigator.mediaDevices) {
                return;
            }

            const canvas = cameraViewRef.current;
            const video = document.createElement('video');

            const canvasCtx = canvas.getContext('2d');
            if (!canvasCtx) {
                throw new Error('2d Canvas context not supported');
            }

            const videoStream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: canvas.clientWidth },
                    height: { ideal: canvas.clientHeight },
                },
                audio: false,
            });

            video.srcObject = videoStream;
            video.setAttribute('width', `${width}px`);
            video.setAttribute('height', `${height}px`);

            video.onloadedmetadata = () => {
                video.play();

                drawInterval = setInterval(() => {
                    canvasCtx.drawImage(
                        video,
                        0,
                        0,
                        canvas.clientWidth,
                        canvas.clientHeight
                    );
                }, 16);
                intervalRef.current = drawInterval;
            };
        }, 0);

        return () => {
            clearTimeout(timer);

            if (drawInterval) {
                clearInterval(drawInterval);
                intervalRef.current = undefined;
            }
        };
    }, [width, height]);

    const handleCapture = async () => {
        if (!width || !height) return;
        // pause the video in the canvas
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = undefined;
        }
        // grab an image from the video stream instead of the resized image from the canvas
        const videoStream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false,
        });
        const video = document.createElement('video');
        video.srcObject = videoStream;
        video.onloadedmetadata = () => {
            video.play();
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const canvasCtx = canvas.getContext('2d')!;
            canvasCtx.drawImage(video, 0, 0, canvas.width, canvas.height);
            setTimeout(() => onCapture(canvas.toDataURL()), 500);
            videoStream.getTracks().forEach(track => track.stop());
        };
    };

    return (
        <Dialog
            open={open}
            onClose={onClose}
            aria-labelledby="scan-dialog-title"
            fullWidth
            maxWidth="md"
            {...DialogProps}
        >
            <DialogTitle sx={{ textAlign: 'center' }} id="scan-dialog-title">
                {translate('ra-ai.scan_camera_dialog.title', {
                    _: 'Place the source in the camera and press the Scan button',
                })}
            </DialogTitle>
            <DialogContent
                sx={{
                    padding: 0,
                    margin: 0,
                    textAlign: 'center',
                }}
                ref={containerRef}
            >
                {width && height && (
                    <canvas
                        width={`${width}px`}
                        height={`${height}px`}
                        ref={cameraViewRef}
                    />
                )}
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>
                    {translate('ra.action.cancel', { _: 'Cancel' })}
                </Button>

                <Button
                    variant="contained"
                    startIcon={<CameraAltIcon />}
                    onClick={handleCapture}
                >
                    {translate('ra-ai.scan_camera_dialog.scan', { _: 'Scan' })}
                </Button>
            </DialogActions>
        </Dialog>
    );
};
