import * as React from 'react';
import { useCallback, useRef, useState } from 'react';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import {
    Button,
    type ButtonProps,
    ButtonGroup,
    type ButtonGroupProps,
    CircularProgress,
    type DialogProps,
    Menu,
    MenuItem,
} from '@mui/material';
import { useTranslate, useNotify } from 'react-admin';

import { ScanFromCameraDialog } from './ScanFromCameraDialog';
import { useFillForm } from './useFillForm';

type FieldName = string;
type FieldCompletionHint = string;

type FormFillerButtonProps = {
    fields?: Record<FieldName, FieldCompletionHint>;
    acceptedFileTypes?: string;
    ButtonProps?: ButtonProps;
    ButtonGroupProps?: ButtonGroupProps;
    DialogProps?: DialogProps;
    sources?: Array<'image' | 'camera'>;
    maxDimension?: number;
    allowOverride?: boolean;
    meta?: any;
};

const buttonLabels = {
    image: 'ra-ai.fill_form_button.fill_using_image',
    camera: 'ra-ai.fill_form_button.fill_using_camera',
};
const buttonDefaultLabels = {
    image: 'Fill using image',
    camera: 'Fill using camera',
};

/**
 * A button that allows the user to fill a form using an image or a camera.
 */
export const FormFillerButton = ({
    fields,
    acceptedFileTypes = 'image/*',
    sources = ['image', 'camera'],
    ButtonProps,
    ButtonGroupProps,
    DialogProps,
    maxDimension,
    allowOverride,
    meta,
}: FormFillerButtonProps) => {
    const translate = useTranslate();
    const notify = useNotify();
    if (sources.length === 0) {
        throw new Error('At least one source must be provided');
    }
    const [source, setSource] = useState(sources[0]);
    const handleSelectFillSource = (source: 'image' | 'camera') => () => {
        setSource(source);
        handleCloseMenu();
    };

    // form filling logic
    const { isPending, performCompletion } = useFillForm({
        fields,
        onError: error => {
            notify(error.message, { type: 'error' });
        },
        maxDimension,
        allowOverride,
        meta,
    });
    const handleFill = () => {
        switch (source) {
            case 'image':
                handleFillUsingImage();
                break;
            case 'camera':
                handleFillUsingCamera();
                break;
        }
    };

    // menu logic
    const [menuAnchorRef, setMenuAnchorRef] = useState<HTMLElement | null>(
        null
    );
    const menuOpen = Boolean(menuAnchorRef);
    const handleToggleMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
        setMenuAnchorRef(currentMenuAnchorRef =>
            currentMenuAnchorRef ? null : event.currentTarget
        );
    };
    const handleCloseMenu = () => {
        setMenuAnchorRef(null);
    };

    // image logic
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const handleFileChange: React.ChangeEventHandler<HTMLInputElement> =
        useCallback(
            async event => {
                if (!event.target.files?.length) {
                    return;
                }
                const attachment = event.target.files[0];
                performCompletion(attachment);
                event.target.value = '';
            },
            [performCompletion]
        );
    const handleFillUsingImage = () => {
        fileInputRef.current?.click();
    };

    // camera logic
    const [cameraDialogOpen, setCameraDialogOpen] = useState(false);
    const handleFillUsingCamera = () => {
        setCameraDialogOpen(true);
    };
    const handleCloseCameraDialog = () => {
        setCameraDialogOpen(false);
    };
    const handleCameraCapture = async (imageDataUrl: string) => {
        setCameraDialogOpen(false);
        const response = await fetch(imageDataUrl);
        const blob = await response.blob();
        const image = new File([blob], 'capture.png', { type: 'image/png' });
        performCompletion(image);
    };

    return (
        <>
            <input
                type="file"
                style={{ display: 'none' }}
                ref={fileInputRef}
                onChange={handleFileChange}
                accept={acceptedFileTypes}
            />

            {sources.length === 1 ? (
                <Button
                    type="button"
                    onClick={handleFill}
                    disabled={isPending}
                    size="small"
                    variant="outlined"
                    {...ButtonProps}
                >
                    {translate(buttonLabels[sources[0]], {
                        _: buttonDefaultLabels[sources[0]],
                    })}
                </Button>
            ) : (
                <ButtonGroup
                    aria-label="Fill form"
                    disabled={isPending}
                    size="small"
                    {...ButtonGroupProps}
                >
                    <Button type="button" onClick={handleFill} {...ButtonProps}>
                        {translate(buttonLabels[source], {
                            _: buttonDefaultLabels[source],
                        })}
                    </Button>

                    <Button
                        id="select-fill-source"
                        size="small"
                        aria-controls={
                            menuOpen ? 'split-button-menu' : undefined
                        }
                        aria-expanded={menuOpen ? 'true' : undefined}
                        aria-label={translate(
                            'ra-ai.fill_form_button.select_fill_source',
                            { _: 'Select fill source' }
                        )}
                        aria-haspopup="menu"
                        onClick={handleToggleMenu}
                        sx={{
                            px: 0.5,
                            '&.MuiButtonGroup-grouped': { minWidth: 30 },
                        }}
                    >
                        {isPending ? (
                            <CircularProgress size={15} />
                        ) : (
                            <ArrowDropDownIcon fontSize="small" />
                        )}
                    </Button>
                </ButtonGroup>
            )}

            <Menu
                aria-labelledby="select-fill-source"
                anchorEl={menuAnchorRef}
                open={menuOpen}
                onClose={handleCloseMenu}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
                {sources.map(src => (
                    <MenuItem key={src} onClick={handleSelectFillSource(src)}>
                        {translate(`ra-ai.fill_form_button.${src}`, {
                            _: src.charAt(0).toUpperCase() + src.slice(1),
                        })}
                    </MenuItem>
                ))}
            </Menu>
            {cameraDialogOpen && (
                <ScanFromCameraDialog
                    open={cameraDialogOpen}
                    {...DialogProps}
                    onClose={handleCloseCameraDialog}
                    onCapture={handleCameraCapture}
                />
            )}
        </>
    );
};
