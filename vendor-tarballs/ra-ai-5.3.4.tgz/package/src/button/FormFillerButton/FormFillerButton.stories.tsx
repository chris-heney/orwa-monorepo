import { createTheme, Box, Link } from '@mui/material';
import fakerestProvider from 'ra-data-fakerest';
import polyglotI18nProvider from 'ra-i18n-polyglot';
import englishMessages from 'ra-language-english';
import * as React from 'react';
import {
    Admin,
    Create,
    Edit,
    ListGuesser,
    mergeTranslations,
    Resource,
    SimpleForm,
    TextInput,
    TranslationMessages,
} from 'react-admin';
import { MemoryRouter } from 'react-router-dom';

import sampleImage from '../../../assets/sample.jpg';
import { addAIMethodsBasedOnOpenAIAPI } from '../../dataProvider';
import { raAiLanguageEnglish, RaAiTranslationMessages } from '../../i18n';
import { OpenAIWrapper } from '../../input/test/OpenAIWrapper';
import { FormFillerButton } from './FormFillerButton';

export default {
    title: 'ra-ai/button/FormFillerButton',
};

interface RaEnterpriseTranslationMessages
    extends TranslationMessages,
        RaAiTranslationMessages {}

const i18nMessages: Record<string, RaEnterpriseTranslationMessages> = {
    en: mergeTranslations(raAiLanguageEnglish, englishMessages),
};

const i18nProvider = polyglotI18nProvider(
    locale => i18nMessages[locale],
    'en',
    { locale: 'en', name: 'English' }
);

const users = [
    {
        id: 1,
        firstName: 'John',
        lastName: 'Doe',
        company: 'Acme',
        email: 'john.doe@acme.com',
    },
];

const Aside = () => (
    <Box sx={{ width: 200, px: 1, textAlign: 'center' }}>
        <Link href={sampleImage} download="sample.jpg" variant="body2">
            <img src={sampleImage} alt="sample" style={{ width: 180 }} />
            <span>Download sample</span>
        </Link>
    </Box>
);

const CreateForm = () => (
    <Create aside={<Aside />}>
        <SimpleForm>
            <FormFillerButton />

            <TextInput
                source="firstName"
                sx={{ width: '50ch' }}
                helperText={false}
            />
            <TextInput
                source="lastName"
                sx={{ width: '50ch' }}
                helperText={false}
            />
            <TextInput
                source="company"
                sx={{ width: '50ch' }}
                helperText={false}
            />
            <TextInput
                source="email"
                sx={{ width: '50ch' }}
                helperText={false}
            />
        </SimpleForm>
    </Create>
);

export const Basic = () => (
    <OpenAIWrapper>
        <MemoryRouter initialEntries={['/users/create']}>
            <Admin
                dataProvider={addAIMethodsBasedOnOpenAIAPI({
                    dataProvider: fakerestProvider(
                        { users },
                        process.env.NODE_ENV !== 'test'
                    ),
                    defaultParams: {
                        model: 'gpt-4o-mini',
                    },
                })}
                i18nProvider={i18nProvider}
                darkTheme={createTheme()}
            >
                <Resource name="users" create={CreateForm} list={ListGuesser} />
            </Admin>
        </MemoryRouter>
    </OpenAIWrapper>
);

export const ErrorCase = () => (
    <MemoryRouter initialEntries={['/users/create']}>
        <Admin
            dataProvider={{
                ...fakerestProvider({ users }, process.env.NODE_ENV !== 'test'),
                getCompletion: async () => {
                    throw new Error('Error message');
                },
            }}
            i18nProvider={i18nProvider}
            darkTheme={createTheme()}
        >
            <Resource name="users" create={CreateForm} list={ListGuesser} />
        </Admin>
    </MemoryRouter>
);

export const AllowOverride = () => (
    <OpenAIWrapper>
        <MemoryRouter initialEntries={['/users/1']}>
            <Admin
                dataProvider={addAIMethodsBasedOnOpenAIAPI({
                    dataProvider: fakerestProvider(
                        { users },
                        process.env.NODE_ENV !== 'test'
                    ),
                    defaultParams: {
                        model: 'gpt-4o-mini',
                    },
                })}
                i18nProvider={i18nProvider}
                darkTheme={createTheme()}
            >
                <Resource
                    name="users"
                    edit={() => (
                        <Edit aside={<Aside />}>
                            <SimpleForm>
                                <FormFillerButton allowOverride />

                                <TextInput
                                    source="firstName"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="lastName"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="company"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="email"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                            </SimpleForm>
                        </Edit>
                    )}
                    list={ListGuesser}
                />
            </Admin>
        </MemoryRouter>
    </OpenAIWrapper>
);

export const Fields = () => (
    <OpenAIWrapper>
        <MemoryRouter initialEntries={['/users/create']}>
            <Admin
                dataProvider={addAIMethodsBasedOnOpenAIAPI({
                    dataProvider: fakerestProvider(
                        { users },
                        process.env.NODE_ENV !== 'test'
                    ),
                    defaultParams: {
                        model: 'gpt-4o-mini',
                    },
                })}
                i18nProvider={i18nProvider}
                darkTheme={createTheme()}
            >
                <Resource
                    name="users"
                    create={() => (
                        <Create aside={<Aside />}>
                            <SimpleForm>
                                <FormFillerButton
                                    fields={{
                                        cp: 'the company name',
                                        gursikso: 'the user email',
                                    }}
                                />

                                <TextInput
                                    source="author.firstName"
                                    label="author.firstName (a.k.a. first name)"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="author.lastName"
                                    label="author.lastName (a.k.a. last name)"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="cp"
                                    label="cp (a.k.a. company)"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="gursikso"
                                    label="gursikso (a.k.a. email)"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                            </SimpleForm>
                        </Create>
                    )}
                    list={ListGuesser}
                />
            </Admin>
        </MemoryRouter>
    </OpenAIWrapper>
);

export const Sources = ({
    sources = ['image'],
}: {
    sources: Array<'image' | 'camera'>;
}) => (
    <OpenAIWrapper>
        <MemoryRouter initialEntries={['/users/create']}>
            <Admin
                dataProvider={addAIMethodsBasedOnOpenAIAPI({
                    dataProvider: fakerestProvider(
                        { users },
                        process.env.NODE_ENV !== 'test'
                    ),
                    defaultParams: {
                        model: 'gpt-4o-mini',
                    },
                })}
                i18nProvider={i18nProvider}
                darkTheme={createTheme()}
            >
                <Resource
                    name="users"
                    create={() => (
                        <Create aside={<Aside />}>
                            <SimpleForm>
                                <FormFillerButton sources={sources} />

                                <TextInput
                                    source="username"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="address"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="phone"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                                <TextInput
                                    source="website"
                                    sx={{ width: '50ch' }}
                                    helperText={false}
                                />
                            </SimpleForm>
                        </Create>
                    )}
                    list={ListGuesser}
                />
            </Admin>
        </MemoryRouter>
    </OpenAIWrapper>
);

Sources.args = {
    sources: ['image'],
};
Sources.argTypes = {
    sources: {
        options: ['image', 'camera'],
        control: { type: 'inline-check' },
    },
};
