import { merge } from 'lodash';

export const getObjectDescriptionParts = (
    formSchema: Record<string, unknown>,
    fieldsDescription: Record<string, unknown> | string | null | undefined,
    indentation = ''
): string[] => {
    return Object.entries(formSchema).flatMap(([key, value]): string[] => {
        if (value === null || value === undefined) {
            return [`${indentation}- ${key}`];
        }
        if (Array.isArray(value)) {
            if (value.length === 0) {
                return [`${indentation}- ${key}: A list`];
            }

            if (typeof value[0] !== 'object') {
                return [`${indentation}- ${key}: A list of ${typeof value[0]}`];
            }
            if (value[0] instanceof Date) {
                return [`${indentation}- ${key}: A list of Date`];
            }
            return [
                `${indentation}- ${key}: A list of objects with:`,
                ...getObjectDescriptionParts(
                    formSchema[key]![0],
                    fieldsDescription?.[key]?.[0] ?? null,
                    indentation + '  '
                ),
            ];
        }
        if (typeof key === 'number') {
            switch (value) {
                case typeof value === 'number':
                    return [`${indentation}- A number`];
                case typeof value === 'string':
                    return [`${indentation}- A string`];
                case typeof value === 'boolean':
                    return [`${indentation}- A boolean`];
                case typeof value === 'object':
                    return [
                        `${indentation}- An object containing:`,
                        ...getObjectDescriptionParts(
                            formSchema[key] as Record<string, unknown>,
                            null,
                            indentation + '  '
                        ),
                    ];
                default:
                    return [];
            }
        }
        if (fieldsDescription?.[key]) {
            if (typeof fieldsDescription[key] === 'object') {
                return [
                    `${indentation}- ${key}: An object with:`,
                    ...getObjectDescriptionParts(
                        formSchema[key] as Record<string, unknown>,
                        fieldsDescription[key],
                        indentation + '  '
                    ),
                ];
            }

            return [`${indentation}- ${key}: ${fieldsDescription[key]}`];
        }
        switch (typeof value) {
            case 'number':
                return [`${indentation}- ${key}: A number`];
            case 'string':
                return [`${indentation}- ${key}: A string`];
            case 'boolean':
                return [`${indentation}- ${key}: A boolean`];
            case 'object': {
                if ((value as Record<string, unknown>) instanceof Date) {
                    return [`${indentation}- ${key}: A date`];
                }
                return [
                    `${indentation}- ${key}: An object with:`,
                    ...getObjectDescriptionParts(
                        formSchema[key] as Record<string, unknown>,
                        null,
                        indentation + '  '
                    ),
                ];
            }
            default:
                return [];
        }
    });
};

export const getPrompt = (
    formValues: Record<string, unknown>,
    fieldsDescription: Record<string, unknown> | null | undefined
) => {
    const formSchema = merge(formValues, fieldsDescription);
    const objectDescriptionParts = getObjectDescriptionParts(
        formSchema,
        fieldsDescription
    );

    return `Extract the following fields from the attached document:
${objectDescriptionParts.join('\n')}

Reply using the JSON format. Do not include any other information.
Do not format the JSON as markdown or any other format.

Only include the fields that are present in the document.
If the document does not contain the required information, set the value to null.`;
};
