import * as React from 'react';
import {
    AdminContext,
    SimpleForm,
    TextInput,
    testDataProvider,
    defaultI18nProvider,
    required,
    minLength,
    ResourceContextProvider,
} from 'react-admin';
import { useWatch, useFormContext } from 'react-hook-form';
import { Card, createTheme, Stack, Button, Dialog } from '@mui/material';

import { TextareaWithCompletion } from './TextareaWithCompletion';
import { addAIMethodsBasedOnOpenAIAPI } from '../../../dataProvider/addAIMethodsBasedOnOpenAIAPI';
import { OpenAIWrapper } from '../../test/OpenAIWrapper';

export default {
    title: 'ra-ai/input/PredictiveTextInput/multiline',
    decorators: [
        Story => (
            <div style={{ margin: '2em' }}>
                <Story />
            </div>
        ),
    ],
};

const delayedPromise =
    (data, delay = 1000) =>
    () =>
        new Promise(resolve => {
            setTimeout(() => resolve(data), delay);
        });

const dataProvider = {
    ...testDataProvider(),
    getCompletion: delayedPromise({
        data: ' dolor sit amet',
    }),
};

const FormInspector = ({ name = 'body' }) => {
    const value = useWatch({ name });
    return (
        <div style={{ backgroundColor: 'lightgrey' }}>
            {name} value in form:&nbsp;
            <code>
                {JSON.stringify(value)} ({typeof value})
            </code>
        </div>
    );
};

const FormResetButton = ({ name = 'body', value = 'foo bar' }) => {
    const { setValue } = useFormContext();
    return <Button onClick={() => setValue(name, value)}>Reset</Button>;
};

export const Default = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <Stack
                        direction="row"
                        sx={{
                            gap: 2,
                        }}
                    >
                        <TextareaWithCompletion
                            source="body"
                            sx={{ width: 400 }}
                            label="predictive"
                        />
                        <TextInput
                            source="body"
                            multiline
                            sx={{ width: 400 }}
                            label="not predictive"
                        />
                    </Stack>

                    <FormInspector />
                    <FormResetButton />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const NoValue = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm>
                    <Stack
                        sx={{
                            width: '100%',
                        }}
                    >
                        <TextInput source="body" multiline />
                        <TextareaWithCompletion source="body" />
                    </Stack>

                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const Label = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion
                        source="body"
                        label="custom label"
                    />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const Margin = () => (
    <AdminContext
        dataProvider={dataProvider}
        i18nProvider={defaultI18nProvider}
    >
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion
                        source="body"
                        label="Default (dense)"
                    />
                    <TextareaWithCompletion
                        source="body"
                        label="Normal"
                        margin="normal"
                    />
                    <TextareaWithCompletion
                        source="body"
                        label="None"
                        margin="none"
                    />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const Size = () => (
    <AdminContext
        dataProvider={dataProvider}
        i18nProvider={defaultI18nProvider}
    >
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion
                        source="body"
                        label="Default (small)"
                    />
                    <TextareaWithCompletion
                        source="body"
                        label="medium"
                        size="medium"
                    />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const Variant = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <Stack
                        direction="row"
                        spacing={2}
                        sx={{
                            width: '100%',
                        }}
                    >
                        <Stack
                            sx={{
                                width: '100%',
                            }}
                        >
                            <TextInput source="body" multiline />
                            <TextareaWithCompletion source="body" />
                        </Stack>
                        <Stack
                            sx={{
                                width: '100%',
                            }}
                        >
                            <TextInput
                                source="body"
                                multiline
                                variant="outlined"
                            />
                            <TextareaWithCompletion
                                source="body"
                                variant="outlined"
                            />
                        </Stack>
                        <Stack
                            sx={{
                                width: '100%',
                            }}
                        >
                            <TextInput
                                source="body"
                                multiline
                                variant="standard"
                            />
                            <TextareaWithCompletion
                                source="body"
                                variant="standard"
                            />
                        </Stack>
                    </Stack>
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const NotFullWidth = () => (
    <AdminContext dataProvider={dataProvider} theme={createTheme()}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion source="body" />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const FullWidth = () => (
    <AdminContext dataProvider={dataProvider} theme={createTheme()}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion source="body" fullWidth />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const MinRows = ({ minRows }) => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion source="body" minRows={minRows} />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);
MinRows.args = {
    minRows: 3,
};

export const MaxRows = ({ maxRows }) => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion source="body" maxRows={maxRows} />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);
MaxRows.args = {
    maxRows: 3,
};

export const MaxRowsBasic = () => (
    <AdminContext dataProvider={dataProvider} theme={createTheme()}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion source="body" maxRows={3} />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const MaxRowsFullWidth = () => (
    <AdminContext dataProvider={dataProvider} theme={createTheme()}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion
                        source="body"
                        maxRows={3}
                        fullWidth
                    />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const MaxRowsNotFullWidth = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion
                        source="body"
                        maxRows={3}
                        fullWidth={false}
                    />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const HelperText = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: '' }}>
                    <TextareaWithCompletion
                        source="body"
                        helperText="Please fill the void"
                    />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const Validate = () => (
    <AdminContext
        dataProvider={dataProvider}
        i18nProvider={defaultI18nProvider}
    >
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: '' }}>
                    <TextareaWithCompletion
                        source="body"
                        validate={[required(), minLength(5)]}
                    />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const Sx = () => (
    <AdminContext dataProvider={dataProvider}>
        <Card>
            <ResourceContextProvider value="users">
                <SimpleForm record={{ body: 'foo bar' }}>
                    <TextareaWithCompletion
                        source="body"
                        sx={{
                            backgroundColor: 'lightgrey',
                            border: '1px solid red',
                        }}
                    />
                    <FormInspector />
                </SimpleForm>
            </ResourceContextProvider>
        </Card>
    </AdminContext>
);

export const OpenAI = () => (
    <OpenAIWrapper>
        <AdminContext
            dataProvider={addAIMethodsBasedOnOpenAIAPI({
                dataProvider: testDataProvider(),
            })}
            i18nProvider={defaultI18nProvider}
        >
            <Card>
                <ResourceContextProvider value="users">
                    <SimpleForm
                        record={{
                            firstName: 'Marie',
                            lastName: 'Curie',
                            profession: 'Scientist',
                            biography:
                                'Marie Curie was a Polish and naturalized-French physicist and chemist who conducted pioneering research on radioactivity.',
                        }}
                    >
                        <TextInput
                            source="firstName"
                            sx={{ width: '50ch' }}
                            helperText={false}
                        />
                        <TextInput
                            source="lastName"
                            sx={{ width: '50ch' }}
                            helperText={false}
                        />
                        <TextInput
                            source="profession"
                            sx={{ width: '50ch' }}
                            helperText={false}
                        />

                        <TextareaWithCompletion
                            source="biography"
                            sx={{ width: '50ch' }}
                            locale="en"
                            helperText={false}
                        />
                    </SimpleForm>
                </ResourceContextProvider>
            </Card>
        </AdminContext>
    </OpenAIWrapper>
);

export const QueryOptions = () => {
    const [enabled, setEnabled] = React.useState(false);

    return (
        <AdminContext dataProvider={dataProvider}>
            <Card>
                <ResourceContextProvider value="users">
                    <SimpleForm record={{ body: 'foo bar' }}>
                        <TextareaWithCompletion
                            source="body"
                            queryOptions={{ enabled }}
                        />
                        <Button onClick={() => setEnabled(!enabled)}>
                            {enabled ? 'Disable' : 'Enable'}
                        </Button>
                        <FormInspector />
                    </SimpleForm>
                </ResourceContextProvider>
            </Card>
        </AdminContext>
    );
};

export const InsideDialog = () => {
    return (
        <AdminContext dataProvider={dataProvider}>
            <Card>
                <ResourceContextProvider value="users">
                    <Dialog open fullWidth maxWidth="md">
                        <SimpleForm record={{ body: 'foo bar' }}>
                            <TextareaWithCompletion source="body" />
                        </SimpleForm>
                    </Dialog>
                </ResourceContextProvider>
            </Card>
        </AdminContext>
    );
};
