import * as React from 'react';
import {
    FieldTitle,
    InputHelperText,
    sanitizeInputRestProps,
    useInput,
    useLocaleState,
    useNotify,
    useResourceContext,
    TextInputProps,
} from 'react-admin';
import { TextField, SxProps, useFormControl, styled } from '@mui/material';
import { useWatch } from 'react-hook-form';
import clsx from 'clsx';
import { singularize } from 'inflection';

import {
    UseGetCompletionOptions,
    useGetCompletion,
} from '../../../dataProvider';

/**
 * A TextareaInput that suggests completions when the user types.
 *
 * Warning: This input updates the form value onBlur, not on every keystroke.
 */
// eslint-disable-next-line prettier/prettier
export const TextareaWithCompletion = <ErrorType = Error,>(
    props: TextareaWithCompletionProps<ErrorType>
) => {
    const {
        className,
        debounce = 1000,
        defaultValue,
        format,
        fullWidth,
        helperText,
        label,
        locale,
        maxRows,
        maxSize,
        meta,
        minRows,
        parse,
        promptGenerator = defaultPromptGenerator,
        queryOptions,
        rows = maxRows,
        source,
        stop,
        sx,
        temperature,
        validate,
        variant,
        ...rest
    } = props;
    const resource = useResourceContext(props);
    if (!resource) {
        throw new Error(
            'The TextareaWithCompletion component must be used inside a ResourceContext or must be passed a resource prop.'
        );
    }
    const {
        field,
        id,
        isRequired,
        fieldState: { error, invalid, isTouched },
        formState: { isSubmitted },
    } = useInput({
        defaultValue,
        format,
        parse,
        resource,
        source,
        validate,
    });
    const renderHelperText =
        helperText !== false || ((isTouched || isSubmitted) && invalid);
    // the ref for the contentEditable div
    const inputRef = React.useRef<HTMLDivElement>(null);
    // local copy of the contenteditable value, used for the label shrink
    const [content, setContent] = React.useState(field.value);
    // the initial content of the contenteditable
    const [contentEditableInitialValue, setContentEditableInitialValue] =
        React.useState(field.value);
    // the content before completion is used to replace the content if the user dismisses the completion
    const contentBeforeCompletion = React.useRef('');
    // To detect when the user expects a completion, we must follow its position in the textarea
    const [caretPosition, setCaretPosition] = React.useState<number>(0);
    // To force a completion on focus, we track the focused state
    const [isFocused, setIsFocused] = React.useState(false);
    const [readyForCompletion, setReadyForCompletion] = React.useState(false);
    // we need to keep the latest suggested completion, so add it to the content it the user accepts it
    const completion = React.useRef('');

    const updateContent = text => {
        setContent(text);
        field.onChange({ target: { value: text } });
    };

    // if the form value has changed from outside, update the value on screen
    React.useEffect(() => {
        // Content and field.value are normally synchronized in this component (see updateContent above).
        // If they are ever out of sync, it's because the field value has changed from outside.
        if (content !== field.value) {
            // In that case, we reset the contenteditable value to match the field value.
            setContentEditableInitialValue(field.value);
        }
        // Otherwise we don't update it, or the cursor would move to the beginning of the field.
        // The contenteditable already displays the right content (the content modified by the user).
    }, [content, field.value]);

    const handleMove = () => {
        if (!inputRef.current) {
            return;
        }
        setReadyForCompletion(false);
        const input = inputRef.current;
        if (!elementContainsSelection(input)) {
            return;
        }
        const newCaretPosition = getCaretPosition(input);
        if (
            newCaretPosition.start != null &&
            newCaretPosition.start === newCaretPosition.end
        ) {
            setCaretPosition(newCaretPosition.start);
        }
    };

    const handleType = e => {
        if (!inputRef.current) {
            return;
        }
        setReadyForCompletion(false);
        const input = inputRef.current;
        // if user pressed tab and there is an active completion, change the content
        if (e.key === 'Tab' && completion.current) {
            e.preventDefault();
            input.textContent =
                contentBeforeCompletion.current.slice(0, caretPosition) +
                completion.current +
                contentBeforeCompletion.current.slice(caretPosition);
            updateContent(input.textContent);
            // Move the caret after the completion
            moveCaret(input, caretPosition + completion.current.length);
            // reset the completion
            completion.current = '';
        } else {
            // user didn't press tab
            if (completion.current) {
                // user dismissed the completion: empty it and remove it from the content
                completion.current = '';
                input.textContent = contentBeforeCompletion.current;
                // Move the caret to the recorded caretPosition
                moveCaret(input, caretPosition);
            }
            if (e.key === 'Enter') {
                // Browsers add a <div> after the <br> when pressing enter,
                // so we add the element manually instead.
                if (navigator.userAgent.toLowerCase().includes('firefox')) {
                    // FIXME: insertLineBreak messes the caret position in Firefox
                    // so we must find another way
                } else {
                    // execCommand is deprecated but there is no alternative and it's supported everywhere
                    document.execCommand('insertLineBreak');
                    e.preventDefault();
                }
            }
        }
        contentBeforeCompletion.current = input.textContent ?? '';
    };

    const handleFocus = () => {
        // used to trigger the completion when the user clicks in the field
        setIsFocused(true);
    };

    const handleBlur = e => {
        if (!inputRef.current) return;
        setReadyForCompletion(false);
        if (completion.current) {
            completion.current = '';
            inputRef.current.textContent = contentBeforeCompletion.current;
        }
        // @ts-ignore the onBlur signature expects no event, which is a mistake
        field.onBlur(e);
        setContentEditableInitialValue(inputRef.current.textContent);
        setIsFocused(false);
    };

    // Handle paste to avoid pasting HTML
    // @see https://developer.mozilla.org/en-US/docs/Web/API/Element/paste_event#examples
    const handlePaste = e => {
        e.preventDefault();
        const clipboardText = // @ts-ignore
            (event.clipboardData || window.clipboardData).getData('text');
        const selection = window.getSelection();
        if (!selection || !selection.rangeCount) return;
        selection.deleteFromDocument();
        selection
            .getRangeAt(0)
            .insertNode(document.createTextNode(clipboardText));
        selection.collapseToEnd();
    };

    // Determine when the input is ready for completion:
    // - only if the caret is at the end of a line,
    // - and if one second has passed without any change to the content)
    React.useEffect(() => {
        if (!inputRef.current) return;
        const input = inputRef.current;
        const timer = setTimeout(() => {
            const textContent = input.innerText;
            if (
                document.activeElement === input &&
                (textContent === '' ||
                    textContent?.[caretPosition] === '\n' ||
                    caretPosition === textContent?.length)
            ) {
                setReadyForCompletion(true);
            } else {
                setReadyForCompletion(false);
            }
        }, debounce);
        return () => {
            clearTimeout(timer);
        };
    }, [caretPosition, debounce, isFocused]);

    const record = useWatch();
    const [localeFromI18n] = useLocaleState();
    const contentLocale = locale || localeFromI18n;
    const notify = useNotify();

    // When ready for completion, use the AI backend to complete the text
    const onSuccess = ({ data }) => {
        const input = inputRef.current;
        if (!input) return;
        if (!data) return;
        if (!readyForCompletion) return;
        const textContent = input.innerText;
        contentBeforeCompletion.current = textContent;
        const cleanedUpCompletion = cleanupCompletion(data);
        completion.current = cleanedUpCompletion;
        setReadyForCompletion(false);
        // Add the completion to the content, at the caret position
        // we switch to HTMLContent instead of textContent
        // to be able to style the completion
        const newHtmlContent =
            textContent.slice(0, caretPosition) +
            `<span style="opacity:0.5">${cleanedUpCompletion}</span>` +
            textContent.slice(caretPosition);
        input.innerHTML = newHtmlContent;
        // Move the caret before the completion
        moveCaret(input, caretPosition);
    };
    const onError = error => {
        if (!readyForCompletion) return;
        completion.current = '';
        notify(error?.message || 'ra-ai.notification.getCompletion.error', {
            type: 'error',
            messageArgs: {
                _: error?.message || 'Error fetching completion',
            },
        });
    };
    useGetCompletion(
        {
            prompt: promptGenerator({
                resource,
                name: source,
                record,
                value: inputRef.current?.innerText,
                caretPosition,
                locale: contentLocale,
            }),
            stop,
            temperature,
            maxSize,
            meta,
        },
        {
            enabled: readyForCompletion,
            onSuccess,
            onError,
            ...queryOptions,
        }
    );

    return (
        <StyledTextField
            variant={variant}
            fullWidth={fullWidth}
            multiline
            className={clsx('ra-input', `ra-input-${source}`, className)}
            sx={{
                '& .MuiInputBase-input': {
                    width: theme =>
                        fullWidth == null
                            ? theme.components?.MuiTextField?.defaultProps
                                  ?.fullWidth
                                ? '100%'
                                : undefined
                            : fullWidth
                              ? '100%'
                              : undefined,
                    minHeight: theme =>
                        minRows
                            ? `calc(${minRows} * ${theme.typography.body1.lineHeight} * 1em)`
                            : undefined,
                    maxHeight: theme =>
                        rows
                            ? `calc(${rows} * ${theme.typography.body1.lineHeight} * 1em)`
                            : undefined,
                    overflowY: rows ? 'auto' : undefined,
                },
                ...sx,
            }}
            label={
                label !== '' && label !== false ? (
                    <FieldTitle
                        label={label}
                        source={source}
                        resource={resource}
                        isRequired={isRequired}
                    />
                ) : null
            }
            id={id}
            InputLabelProps={{ shrink: !!content || undefined }}
            InputProps={{
                slots: { input: ContentEditableDiv },
                slotProps: {
                    input: {
                        onKeyDown: handleType,
                        onMouseDown: handleType,
                        onKeyUp: handleMove,
                        onMouseUp: handleMove,
                        onInput: e =>
                            updateContent(
                                (e.target as HTMLDivElement).innerText
                            ),
                        onPaste: handlePaste,
                        dangerouslySetInnerHTML: {
                            __html: contentEditableInitialValue,
                        },
                        // @ts-ignore custom property
                        // @see ContentEditableDiv
                        isFilled: contentEditableInitialValue != '',
                    },
                },
            }}
            error={(isTouched || isSubmitted) && invalid}
            helperText={
                renderHelperText ? (
                    <InputHelperText
                        error={error?.message}
                        helperText={helperText}
                    />
                ) : null
            }
            inputRef={inputRef}
            onBlur={handleBlur}
            onFocus={handleFocus}
            {...sanitizeInputRestProps(rest)}
        />
    );
};

export interface TextareaWithCompletionProps<ErrorType = Error>
    extends TextInputProps {
    debounce?: number;
    locale?: string;
    maxSize?: number;
    maxRows?: string | number;
    rows?: string | number;
    meta?: any;
    minRows?: string | number;
    promptGenerator?: (params: {
        resource: string;
        name: string;
        caretPosition: number;
        value?: string;
        record?: Record<string, any>;
        locale?: string;
    }) => string;
    queryOptions?: UseGetCompletionOptions<ErrorType>;
    stop?: string[];
    sx?: SxProps;
    temperature?: number;
}

const StyledTextField = styled(TextField, {
    name: 'RaAiTextareaWithCompletion',
    overridesResolver: (props, styles) => styles.root,
})({
    '& .MuiInputBase-input': {
        minWidth: 190,
        whiteSpace: 'pre-wrap',
        padding: 0,
        paddingTop: 0,
        WebkitTapHighlightColor: 'transparent',
        '&:focus': {
            outline: 0,
        },
    },
});

/**
 * A <div contentEditable> that can be used as a slot for MUI's TextField.
 */
const ContentEditableDiv = React.forwardRef<HTMLDivElement, any>(
    function ContentEditableDiv(
        { isFilled, minRows, maxRows, ownerState, ...props },
        ref
    ) {
        // MUI's InputBase uses a custom context to tell the label
        // whether the input is filled or not so it can shrink.
        // As we don't use InputBase, we have to replicate this context
        const muiFormControl = useFormControl();
        const onFilled = muiFormControl && muiFormControl.onFilled;
        const onEmpty = muiFormControl && muiFormControl.onEmpty;
        React.useEffect(() => {
            if (isFilled) {
                onFilled && onFilled();
            } else {
                onEmpty && onEmpty();
            }
        }, [isFilled, onFilled, onEmpty]);

        return (
            <div
                ref={ref}
                role="textbox"
                tabIndex={0}
                contentEditable
                className="'text-editable"
                {...props}
            />
        );
    }
);

const defaultPromptGenerator = ({
    resource,
    name,
    value,
    record = {},
    locale,
    caretPosition,
}) => {
    const cleanedRecord = Object.keys(record).reduce(
        (acc, key) => {
            if (key !== name && record[key]) {
                acc[key] = record[key];
            }
            return acc;
        },
        {} as Record<string, any>
    );
    const recordRepresentation = Object.keys(cleanedRecord)
        .map(key => `${key}: ${cleanedRecord[key]}`)
        .join('\n');
    const resourceName = resource ? singularize(resource) : 'record';
    if (!value) {
        return `The following describes one ${resourceName}, using the ${locale} locale:
${recordRepresentation}
${name}: `;
    } else {
        const prompt = `
You will be provided with an incomplete ${resourceName} delimited by triple quotes. It contains a {{REDACTED}} portion that you must complete using the ${locale} locale.

"""
${recordRepresentation}
${name}: ${value.slice(0, caretPosition)}{{REDACTED}}${value.slice(
            caretPosition
        )}
"""

Write only the {{REDACTED}} portion, without the surrounding content.

{{REDACTED}}:`;
        return prompt;
    }
};

/**
 * Get the cleaned up completion, without the surrounding newlines and double quotes
 * @example cleanupCompletion(`  "lorem ipsum"`) === "lorem ipsum"
 */
const cleanupCompletion = (text: string) =>
    text
        .trim()
        .replace(/^"(.*)"$/, '$1')
        .replace(/^'(.*)'$/, '$1')
        .replace('{{REDACTED}}', '')
        .replace(/^\:(.*)$/, '$1')
        .trim();

const moveCaret = (element: HTMLElement, position: number) => {
    if (!(element.childNodes[0] instanceof Node)) {
        return;
    }
    const coord = getCoordinatesForPosition(element, position);
    const selection = window.getSelection();
    if (!selection) return;
    selection.removeAllRanges();
    const range = new Range();
    range.setStart(element.childNodes[coord.line], coord.column);
    range.collapse(true);
    selection.addRange(range);
};

function getCoordinatesForPosition(element: HTMLElement, position: number) {
    let counter = position;
    let line = 0;
    let column = 0;
    let finished = false;
    element.childNodes.forEach(node => {
        if (finished) {
            return;
        }
        if (node instanceof Node) {
            if (node.nodeName === 'BR') {
                line++;
                if (counter > 0) {
                    counter--;
                }
                column = 0;
            } else if (node.nodeName === '#text') {
                const textLength = node.nodeValue?.length ?? 0;
                if (counter <= textLength) {
                    column = counter;
                    finished = true;
                } else {
                    counter -= textLength;
                }
            }
        }
    });

    return { line, column };
}

// taken from https://stackoverflow.com/questions/8339857/how-to-know-if-selected-text-is-inside-a-specific-div
const elementContainsSelection = (el: HTMLElement) => {
    const selection = window.getSelection();
    if (!selection) return false;
    if (selection.rangeCount > 0) {
        for (let i = 0; i < selection.rangeCount; ++i) {
            if (!el.contains(selection.getRangeAt(i).commonAncestorContainer)) {
                return false;
            }
        }
        return true;
    }
    return false;
};

function getCaretPosition(element: HTMLElement): {
    start: number;
    end: number;
} {
    const selection = window.getSelection();
    if (!selection) return { start: 0, end: 0 };
    const range = selection.getRangeAt(0);

    const preCaretRange = range.cloneRange();
    preCaretRange.selectNodeContents(element);
    preCaretRange.setEnd(range.endContainer, range.endOffset);

    const end = countCharactersIncludingNewlines(preCaretRange);
    preCaretRange.setEnd(range.startContainer, range.startOffset);
    const start = countCharactersIncludingNewlines(preCaretRange);
    return { start, end };
}

function countCharactersIncludingNewlines(range: Range): number {
    const divs = range.cloneContents().querySelectorAll('div');
    let count = range.toString().length;
    divs.forEach(() => count++); // add 1 for each newline (div)
    return count;
}
