import * as React from 'react';
import {
    useInput,
    FieldTitle,
    InputHelperText,
    TextInputProps,
    sanitizeInputRestProps,
} from 'react-admin';
import clsx from 'clsx';

import { TextFieldWithCompletion } from './TextFieldWithCompletion';
import { usePredictiveTextInputController } from './usePredictiveTextInputController';
import { UseGetCompletionOptions } from 'packages/ra-ai/src/dataProvider';

/**
 * Implementation of PredictiveTextInput for monoline inputs
 */
// eslint-disable-next-line prettier/prettier
export const TextInputWithCompletion = <ErrorType = Error,>(
    props: TextInputWithCompletionProps<ErrorType>
) => {
    const {
        className,
        debounce,
        defaultValue,
        label,
        locale,
        format,
        helperText,
        maxSize,
        meta,
        onFocus,
        onBlur,
        onChange,
        parse,
        promptGenerator,
        queryOptions,
        resource,
        source,
        stop,
        temperature,
        validate,
        ...rest
    } = props;

    // @ts-ignore runtime check for people who don't have typescript
    if (props.resettable) {
        throw new Error('PredictiveTextInput does not support resettable yet');
    }

    const {
        field,
        fieldState: { error, invalid, isTouched },
        formState: { isSubmitted },
        id,
        isRequired,
    } = useInput({
        defaultValue,
        format,
        parse,
        resource,
        source,
        type: 'text',
        validate,
        onBlur,
        onChange,
        ...rest,
    });

    const { completion, handleFocus, handleBlur, handleKeyDown } =
        usePredictiveTextInputController<ErrorType>({
            field,
            locale,
            promptGenerator,
            debounce,
            maxSize,
            meta,
            stop,
            temperature,
            queryOptions,
        });

    return (
        <TextFieldWithCompletion
            id={id}
            {...field}
            className={clsx('ra-input', `ra-input-${source}`, className)}
            label={
                label !== '' && label !== false ? (
                    <FieldTitle
                        label={label}
                        source={source}
                        resource={resource}
                        isRequired={isRequired}
                    />
                ) : null
            }
            error={(isTouched || isSubmitted) && invalid}
            helperText={
                <InputHelperText
                    error={error?.message}
                    helperText={helperText}
                />
            }
            {...sanitizeInputRestProps(rest)}
            completion={completion}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
        />
    );
};

export interface TextInputWithCompletionProps<ErrorType = Error>
    extends Omit<TextInputProps, 'resettable'> {
    debounce?: number;
    locale?: string;
    promptGenerator?: (params: {
        resource: string;
        name: string;
        value?: string;
        record?: Record<string, any>;
    }) => string;
    maxSize?: number;
    meta?: any;
    stop?: string[];
    temperature?: number;
    queryOptions?: UseGetCompletionOptions<ErrorType>;
}
