import * as React from 'react';
import { TextField, useForkRef, useThemeProps } from '@mui/material';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';

/**
 * A version of material-ui's `<TextField>` that also renders a completion suggestion.
 *
 * @private for internal use only
 */
export const TextFieldWithCompletion = React.forwardRef<any, any>(
    (
        { completion, multiline, value, defaultValue, fullWidth, ...rest },
        ref
    ) => {
        const { variant } = useThemeProps({
            name: 'MuiTextField',
            props: { multiline, ...rest },
        });
        // We can have either an input or a textarea, so we type as any just like MUI inputRef
        const inputRef = React.useRef<any>(null);
        const secondInputRef = React.useRef<any>(null);
        const formControlRef = React.useRef<HTMLSpanElement>(null);
        const inputContainerRef = React.useRef<HTMLDivElement>(null);
        const forkedRef = useForkRef(ref, formControlRef);

        // copy the styles from the first input to the second one when the completion changes
        React.useEffect(() => {
            if (
                !inputRef.current ||
                !secondInputRef.current ||
                !formControlRef.current ||
                !inputContainerRef.current
            )
                return;
            const input = inputRef.current;
            const computedStyle = window.getComputedStyle(input);
            const secondInput = secondInputRef.current;
            // copy styles from the first input to the second one
            secondInput.style.cssText = getCssText(computedStyle);
            secondInput.style.letterSpacing = '0.00938em'; // FIXME: letterSpacing isn't properly copied with getComputedStyle
            // position the second input on top of the first one
            secondInput.style.position = 'absolute';
            secondInput.style.boxSizing = 'content-box';
            if (variant === 'standard') {
                const computedFormControlStyle = window.getComputedStyle(
                    formControlRef.current
                );
                const computedInputContainerStyle = window.getComputedStyle(
                    inputContainerRef.current
                );
                secondInput.style.marginTop = `calc(${computedFormControlStyle.marginTop}  + ${computedInputContainerStyle.marginTop})`;
            } else {
                const computedFormControlStyle = window.getComputedStyle(
                    formControlRef.current
                );
                secondInput.style.marginTop =
                    computedFormControlStyle.marginTop;
            }
            secondInput.style.top = `${inputRef.current?.offsetTop}px`;
            secondInput.style.left = `${inputRef.current?.offsetLeft}px`;
            secondInput.style.opacity = '0.5';
            secondInput.style.pointerEvents = 'none';
        }, [completion, variant]);

        // add a listener to copy the scrollLeft from the first input to the second one
        // so that they are aligned even when the input value overflows
        React.useEffect(() => {
            if (!inputRef.current || !secondInputRef.current) return;
            const input = inputRef.current;
            const eventListener = () => {
                if (!secondInputRef.current) return;
                secondInputRef.current.scrollLeft = input.scrollLeft;
                secondInputRef.current.scrollTop = input.scrollTop;
            };
            input.addEventListener('keyup', eventListener);
            input.addEventListener('scroll', eventListener);
            return () => {
                input.removeEventListener('keyup', eventListener);
                input.removeEventListener('scroll', eventListener);
            };
        }, []);

        return (
            <Root
                className={clsx(TextFieldWithCompletionClasses.root, {
                    [TextFieldWithCompletionClasses.fullWidth]:
                        fullWidth === true,
                    [TextFieldWithCompletionClasses.notFullWidth]:
                        fullWidth === false,
                })}
            >
                <TextField
                    ref={forkedRef}
                    inputRef={inputRef}
                    multiline={multiline}
                    value={value}
                    defaultValue={defaultValue}
                    fullWidth={fullWidth}
                    variant={variant}
                    InputProps={{
                        ref: inputContainerRef,
                    }}
                    {...rest}
                />
                {multiline ? (
                    <textarea
                        data-testid={`ra-ai.${rest.name}.completion`}
                        className={
                            TextFieldWithCompletionClasses.multilineCompletion
                        }
                        style={{ display: 'none' }}
                        tabIndex={-1}
                        ref={secondInputRef}
                        value={`${value ?? ''}${defaultValue ?? ''}${
                            completion ?? ''
                        }`}
                        readOnly
                    />
                ) : (
                    <input
                        data-testid={`ra-ai.${rest.name}.completion`}
                        style={{ display: 'none' }}
                        type="text"
                        tabIndex={-1}
                        ref={secondInputRef}
                        value={`${value ?? ''}${defaultValue ?? ''}${
                            completion ?? ''
                        }`}
                        readOnly
                    />
                )}
            </Root>
        );
    }
);
TextFieldWithCompletion.displayName = 'TextFieldWithCompletion';

const PREFIX = 'RaTextFieldWithCompletion';

const TextFieldWithCompletionClasses = {
    root: `${PREFIX}-root`,
    fullWidth: `${PREFIX}-fullWidth`,
    notFullWidth: `${PREFIX}-notFullWidth`,
    multilineCompletion: `${PREFIX}-multilineCompletion`,
};

const Root = styled('div', {
    name: PREFIX,
    overridesResolver: (props, styles) => styles.root,
})(({ theme }) => ({
    position: 'relative',
    width: theme.components?.MuiTextField?.defaultProps?.fullWidth
        ? '100%'
        : undefined,
    [`&.${TextFieldWithCompletionClasses.fullWidth}`]: {
        width: '100%',
    },
    [`&.${TextFieldWithCompletionClasses.notFullWidth}`]: {
        width: undefined,
    },
    [`& .${TextFieldWithCompletionClasses.multilineCompletion}::-webkit-scrollbar`]:
        {
            display: 'none',
        },
}));

/**
 * Convert the output of window.getComputedStyle() to a CSS string
 * @returns {string}
 */
const getCssText = (cssStyleDeclaration: CSSStyleDeclaration) => {
    const nbProperties = cssStyleDeclaration.length;
    let css = '';
    for (let i = 0; i < nbProperties; i++) {
        const propertyName = cssStyleDeclaration.item(i);
        const propertyValue =
            cssStyleDeclaration.getPropertyValue(propertyName);
        if (propertyValue !== '') {
            css += `${propertyName}:${propertyValue}; `;
        }
    }
    return css;
};
