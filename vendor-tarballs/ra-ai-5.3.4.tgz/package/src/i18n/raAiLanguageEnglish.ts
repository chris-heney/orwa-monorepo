import { RaAiTranslationMessages } from './RaAiTranslationMessages';

export const raAiLanguageEnglish: RaAiTranslationMessages = {
    'ra-ai': {
        fill_form_button: {
            fill_using_image: 'Fill using image',
            fill_using_camera: 'Fill using camera',
            select_fill_source: 'Select fill source',
            image: 'Image',
            camera: 'Camera',
        },
        scan_camera_dialog: {
            title: 'Place the source in the camera and press the Scan button',
            scan: 'Scan',
        },
        notification: {
            getCompletion: {
                error: 'Completion error',
            },
        },
        button: {
            autoCorrect: 'Auto-correct',
            complete: 'Complete',
            rephrase: 'Rephrase',
            summarize: 'Summarize',
        },
    },
};
