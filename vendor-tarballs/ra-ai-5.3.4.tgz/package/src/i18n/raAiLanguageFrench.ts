import { RaAiTranslationMessages } from './RaAiTranslationMessages';

export const raAiLanguageFrench: RaAiTranslationMessages = {
    'ra-ai': {
        fill_form_button: {
            fill_using_image: 'Remplir depuis une image',
            fill_using_camera: 'Remplir depuis la caméra',
            select_fill_source: 'Sélectionner la source',
            image: 'Image',
            camera: 'Appareil photo',
        },
        scan_camera_dialog: {
            title: "Remplir avec l'appareil photo",
            scan: 'Scanner',
        },
        notification: {
            getCompletion: {
                error: 'Erreur de complétion',
            },
        },
        button: {
            autoCorrect: 'Corriger',
            complete: 'Compléter',
            rephrase: 'Reformuler',
            summarize: 'Résumer',
        },
    },
};
