export interface RaAiTranslationMessages {
    'ra-ai': {
        fill_form_button: {
            fill_using_image: string;
            fill_using_camera: string;
            select_fill_source: string;
            image: string;
            camera: string;
        };
        scan_camera_dialog: {
            title: string;
            scan: string;
        };
        notification: {
            getCompletion: {
                error: string;
            };
        };
        button: {
            autoCorrect: string;
            complete: string;
            rephrase: string;
            summarize: string;
        };
    };
}
