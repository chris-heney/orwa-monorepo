import { useQuery, UseQueryOptions } from '@tanstack/react-query';
import { useEffect } from 'react';
import {
    DataProvider,
    OnError,
    OnSuccess,
    useDataProvider,
    useEvent,
} from 'react-admin';
import {
    AIDataProvider,
    GetCompletionParams,
    GetCompletionResult,
} from './types';

/**
 * Call the dataProvider.getCompletion() method via react-query, and return the result
 *
 * @example
 * const { data, isPending, error } = useGetCompletion({ prompt: 'Lorem ipsum' });
 * console.log(data);
 * // ' dolor sit amet, consectetur adipiscing elit.'
 *
 * @example // openAI Params
 * const { data, isPending, error } = useGetCompletion({
 *     prompt: 'Lorem ipsum',
 *     meta: { temperature: 0.5 },
 * });
 */
export const useGetCompletion = <ErrorType = Error>(
    params: GetCompletionParams,
    options: UseGetCompletionOptions<ErrorType> = {}
) => {
    const { systemPrompt, prompt, stop, maxSize, temperature, meta } = params;
    const dataProvider = useDataProvider<DataProvider & AIDataProvider>();
    const {
        onError = () => undefined,
        onSuccess = () => undefined,
        ...queryOptions
    } = options;
    const onSuccessEvent = useEvent(onSuccess);
    const onErrorEvent = useEvent(onError);
    const result = useQuery({
        queryKey: [
            'getCompletion',
            { prompt, stop, maxSize, temperature, meta },
        ],
        queryFn: ({ signal }) =>
            dataProvider.getCompletion({
                systemPrompt,
                prompt,
                stop,
                maxSize,
                temperature,
                meta,
                signal,
            }),
        ...queryOptions,
    });
    useEffect(() => {
        if (result.data === undefined || result.isFetching) return;
        onSuccessEvent(result.data);
    }, [onSuccessEvent, result.data, result.isFetching]);

    useEffect(() => {
        if (result.error == null || result.isFetching) return;
        onErrorEvent(result.error);
    }, [onErrorEvent, result.error, result.isFetching]);

    return result;
};

export type UseGetCompletionOptions<ErrorType = Error> = {
    onSuccess?: OnSuccess;
    onError?: OnError;
} & Omit<
    UseQueryOptions<GetCompletionResult, ErrorType>,
    'queryKey' | 'queryFn'
>;
