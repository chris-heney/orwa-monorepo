import merge from 'lodash/merge';
import { DataProvider, fetchUtils } from 'react-admin';
import { GetCompletionParams, GenerateContentParams } from './types';

const DEFAULT_PARAMS = {
    model: 'gpt-4o-mini',
    temperature: 1,
    max_tokens: 256,
    top_p: 1,
    frequency_penalty: 0,
    presence_penalty: 0,
};

const convertToBase64 = (file: File) => {
    return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

/**
 * Add a AI methods to the dataProvider based on the OpenAI API
 * @see https://beta.openai.com/docs/api-reference/completions/create
 *
 * The methods expect the OpenAI API key to be stored in the localStorage under the key 'ra-ai.openai-api-key'.
 * It's up to you to store the key in the localStorage (e.g. in authProvider.login()) and to remove it (e.g. in authProvider.logout())
 *
 * The getCompletion method will call the OpenAI completion API with the passed prompt
 * The generateContent method will generate content with optional attachments
 *
 * @example
 * const dataProvider = addAIMethodsBasedOnOpenAIAPI({
 *    dataProvider: restDataProvider,
 * });
 * dataProvider
 *   .getCompletion('lorem ipsum dolor')
 *   .then(({ data }) => {
 *      console.log(data); // 'sit amet'
 *   });
 *
 * @returns DataProvider
 */
export const addAIMethodsBasedOnOpenAIAPI = ({
    dataProvider,
    endpoint = 'https://api.openai.com/v1/chat/completions',
    defaultParams = DEFAULT_PARAMS,
    httpClient = fetchUtils.fetchJson,
}: {
    dataProvider: DataProvider;
    endpoint?: string;
    defaultParams?: any;
    httpClient?: (url: string, options?: any) => Promise<any>;
}) => ({
    ...dataProvider,
    getCompletion: async (parameters: GetCompletionParams = {}) => {
        const {
            systemPrompt = 'You are a completion AI. You are given a prompt and you should complete it. Reply with only the completion, not the original text.',
            prompt,
            stop,
            maxSize,
            temperature,
            meta = {},
            signal,
        } = parameters || {};
        const body = merge({}, defaultParams, meta, {
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: prompt },
            ],
            stop,
            max_tokens: maxSize,
            temperature,
        });
        const requestOptions = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json',
            }),
            body: JSON.stringify(body),
            signal,
        };
        const key = window.localStorage.getItem('ra-ai.openai-api-key');
        if (key) {
            requestOptions.headers.set('Authorization', `Bearer ${key}`);
        }
        const { json } = await httpClient(endpoint, requestOptions);

        return { data: json.choices[0]?.message?.content };
    },
    generateContent: async (parameters: GenerateContentParams = {}) => {
        const {
            systemPrompt = 'You are a helpful AI.',
            prompt,
            stop,
            maxSize,
            temperature,
            meta = {},
            attachments = [],
            signal,
        } = parameters || {};
        const attachmentUrls = await Promise.all(
            attachments.map(file => convertToBase64(file))
        );
        const body = merge({}, defaultParams, meta, {
            messages: [
                { role: 'system', content: systemPrompt },
                {
                    role: 'user',
                    content: [
                        { type: 'text', text: prompt },
                        ...attachmentUrls.map(url => ({
                            type: 'image_url',
                            image_url: { url },
                        })),
                    ],
                },
            ],
            stop,
            max_tokens: maxSize,
            temperature,
        });
        const requestOptions = {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json',
            }),
            body: JSON.stringify(body),
            signal,
        };
        const key = window.localStorage.getItem('ra-ai.openai-api-key');
        if (key) {
            requestOptions.headers.set('Authorization', `Bearer ${key}`);
        }
        const { json } = await httpClient(endpoint, requestOptions);

        return { data: json.choices[0]?.message?.content };
    },
});

// FIXME: This is a workaround to avoid breaking changes in the ra-ai package
export const addGetCompletionBasedOnOpenAIAPI = addAIMethodsBasedOnOpenAIAPI;
