import { useQuery, UseQueryOptions } from '@tanstack/react-query';
import { DataProvider, useDataProvider } from 'react-admin';
import {
    AIDataProvider,
    GenerateContentParams,
    GenerateContentResult,
} from './types';

/**
 * Call the dataProvider.generateContent() method via react-query, and return the result
 *
 * @example
 * const { data, isPending, error } = useGenerateContent({ prompt: 'Write me a poem' });
 * console.log(data);
 * // 'Roses are red, violets are blue...'
 *
 * @example // openAI Params
 * const { data, isPending, error } = useGenerateContent({
 *     prompt: 'Write me a poem',
 *     meta: { temperature: 0.5 } ,
 * });
 */
export const useGenerateContent = <ErrorType = Error>(
    params: GenerateContentParams,
    options: UseGenerateContentOptions<ErrorType> = {}
) => {
    const { systemPrompt, prompt, stop, maxSize, temperature, meta } = params;
    const dataProvider = useDataProvider<DataProvider & AIDataProvider>();
    const result = useQuery({
        queryKey: [
            'generateContent',
            { prompt, stop, maxSize, temperature, meta },
        ],
        queryFn: ({ signal }) =>
            dataProvider.generateContent({
                systemPrompt,
                prompt,
                stop,
                maxSize,
                temperature,
                meta,
                signal,
            }),
        ...options,
    });

    return result;
};

export type UseGenerateContentOptions<ErrorType = Error> = Omit<
    UseQueryOptions<GenerateContentResult, ErrorType>,
    'queryKey' | 'queryFn'
>;
