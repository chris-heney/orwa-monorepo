# CHANGELOG

## v5.3.4

> 2025-10-14

- Fix styling issues with `<PredictiveTextInput>` in some variants

## v5.3.3

> 2025-10-09

- Fix `<PredictiveTextInput>` does not display the completion correctly in dialogs

## v5.3.2

> 2025-09-22

- Fix `<PredictiveTextInput>` props types compatibility with react-admin >= 5.11.2

## v5.3.1

> 2025-09-15

- Fix `<PredictiveTextInput multiline>` props types compatibility with react-admin >= 5.11.2

## v5.3.0

> 2025-06-16

- Make components compatible with Material UI v7

## v5.2.0

> 2025-02-10

- Add `dataProvider.generateContent()` method
- Rename `addGetCompletionBasedOnOpenAIAPI` to `addAIMethodsBasedOnOpenAIAPI` 
- Update `<FormFillerButton sources>` to accept a list of sources

## v5.1.0

> 2025-02-05

- Add `<FormFillerButton>` component
- Update default OpenAI model to 'gpt40-mini'

## v5.0.0

> 2024-07-25

- Upgrade to react-admin v5
- [TypeScript]: Enable strictNullChecks

## v4.0.9

> 2024-04-05

- Fix `<PredictiveTextInput multiline>` completion reliability when the caret is not at the end of the text

## v4.0.8

> 2023-11-14

-   Update OpenAI Adapter to use the Chat Completions API instead of the Completions API
-   Fix `<PredictiveTextInput multiline>` only updates form value on blur

## v4.0.7

> 2023-11-08

-   Fix `<PredictiveTextInput multiline>` support

## v4.0.6

> 2023-09-25

-   Fix `<PredictiveTextInput fullWidth>` support

## v4.0.5

> 2023-09-21

-   Update OpenAI adapter to use `gpt-3.5-turbo-instruct` model instead of the deprecated `text-davinci-003` model

## v4.0.4

> 2023-07-28

-   Fix `<PredictiveTextInput sx>` rendering on Firefox

## v4.0.3

> 2023-07-05

-   Fix `package.json` entries for bundlers
-   Fix components exports
-   Fix `addGetCompletionBasedOnOpenAIAPI` examples in documentation

## v4.0.2

> 2023-06-26

-   Add `<SmartRichTextInput>` component

## v4.0.1

> 2023-06-16

-   Fix `<PredictiveTextInput sx>` isn't working
-   Fix `dataProvider.getCompletion()` in case of server error

## v4.0.0

> 2023-06-15

-   First release
-   Add `<PredictiveTextInput>` component
