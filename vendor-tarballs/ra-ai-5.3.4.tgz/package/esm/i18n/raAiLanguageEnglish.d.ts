import { RaAiTranslationMessages } from './RaAiTranslationMessages';
export declare const raAiLanguageEnglish: RaAiTranslationMessages;
//# sourceMappingURL=raAiLanguageEnglish.d.ts.map