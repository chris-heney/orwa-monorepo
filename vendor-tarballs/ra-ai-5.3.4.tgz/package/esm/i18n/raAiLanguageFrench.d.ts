import { RaAiTranslationMessages } from './RaAiTranslationMessages';
export declare const raAiLanguageFrench: RaAiTranslationMessages;
//# sourceMappingURL=raAiLanguageFrench.d.ts.map