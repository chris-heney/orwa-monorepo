export interface AIDataProvider {
    getCompletion: (params: GetCompletionParams) => Promise<GetCompletionResult>;
    generateContent: (params: GenerateContentParams) => Promise<GenerateContentResult>;
}
export type GetCompletionParams = {
    prompt?: string;
    systemPrompt?: string;
    stop?: string[];
    maxSize?: number;
    temperature?: number;
    meta?: any;
    signal?: AbortSignal;
};
export type GetCompletionResult = {
    data: string;
};
export type GenerateContentParams = {
    prompt?: string;
    systemPrompt?: string;
    attachments?: File[];
    stop?: string[];
    maxSize?: number;
    temperature?: number;
    meta?: any;
    signal?: AbortSignal;
};
export type GenerateContentResult = {
    data: string;
};
//# sourceMappingURL=types.d.ts.map