import { DataProvider } from 'react-admin';
import { GetCompletionParams, GenerateContentParams } from './types';
/**
 * Add a AI methods to the dataProvider based on the OpenAI API
 * @see https://beta.openai.com/docs/api-reference/completions/create
 *
 * The methods expect the OpenAI API key to be stored in the localStorage under the key 'ra-ai.openai-api-key'.
 * It's up to you to store the key in the localStorage (e.g. in authProvider.login()) and to remove it (e.g. in authProvider.logout())
 *
 * The getCompletion method will call the OpenAI completion API with the passed prompt
 * The generateContent method will generate content with optional attachments
 *
 * @example
 * const dataProvider = addAIMethodsBasedOnOpenAIAPI({
 *    dataProvider: restDataProvider,
 * });
 * dataProvider
 *   .getCompletion('lorem ipsum dolor')
 *   .then(({ data }) => {
 *      console.log(data); // 'sit amet'
 *   });
 *
 * @returns DataProvider
 */
export declare const addAIMethodsBasedOnOpenAIAPI: ({ dataProvider, endpoint, defaultParams, httpClient, }: {
    dataProvider: DataProvider;
    endpoint?: string;
    defaultParams?: any;
    httpClient?: (url: string, options?: any) => Promise<any>;
}) => {
    getCompletion: (parameters?: GetCompletionParams) => Promise<{
        data: any;
    }>;
    generateContent: (parameters?: GenerateContentParams) => Promise<{
        data: any;
    }>;
    getList: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetListParams & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetListResult<RecordType>>;
    getOne: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetOneParams<RecordType> & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetOneResult<RecordType>>;
    getMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetManyParams<RecordType> & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetManyResult<RecordType>>;
    getManyReference: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetManyReferenceParams & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetManyReferenceResult<RecordType>>;
    update: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").UpdateParams) => Promise<import("react-admin").UpdateResult<RecordType>>;
    updateMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").UpdateManyParams) => Promise<import("react-admin").UpdateManyResult<RecordType>>;
    create: <RecordType extends Omit<import("react-admin").RaRecord, "id"> = any, ResultRecordType extends import("react-admin").RaRecord = RecordType & {
        id: import("react-admin").Identifier;
    }>(resource: string, params: import("react-admin").CreateParams) => Promise<import("react-admin").CreateResult<ResultRecordType>>;
    delete: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").DeleteParams<RecordType>) => Promise<import("react-admin").DeleteResult<RecordType>>;
    deleteMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").DeleteManyParams<RecordType>) => Promise<import("react-admin").DeleteManyResult<RecordType>>;
    supportAbortSignal?: boolean;
};
export declare const addGetCompletionBasedOnOpenAIAPI: ({ dataProvider, endpoint, defaultParams, httpClient, }: {
    dataProvider: DataProvider;
    endpoint?: string;
    defaultParams?: any;
    httpClient?: (url: string, options?: any) => Promise<any>;
}) => {
    getCompletion: (parameters?: GetCompletionParams) => Promise<{
        data: any;
    }>;
    generateContent: (parameters?: GenerateContentParams) => Promise<{
        data: any;
    }>;
    getList: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetListParams & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetListResult<RecordType>>;
    getOne: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetOneParams<RecordType> & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetOneResult<RecordType>>;
    getMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetManyParams<RecordType> & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetManyResult<RecordType>>;
    getManyReference: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").GetManyReferenceParams & import("react-admin").QueryFunctionContext) => Promise<import("react-admin").GetManyReferenceResult<RecordType>>;
    update: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").UpdateParams) => Promise<import("react-admin").UpdateResult<RecordType>>;
    updateMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").UpdateManyParams) => Promise<import("react-admin").UpdateManyResult<RecordType>>;
    create: <RecordType extends Omit<import("react-admin").RaRecord, "id"> = any, ResultRecordType extends import("react-admin").RaRecord = RecordType & {
        id: import("react-admin").Identifier;
    }>(resource: string, params: import("react-admin").CreateParams) => Promise<import("react-admin").CreateResult<ResultRecordType>>;
    delete: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").DeleteParams<RecordType>) => Promise<import("react-admin").DeleteResult<RecordType>>;
    deleteMany: <RecordType extends import("react-admin").RaRecord = any>(resource: string, params: import("react-admin").DeleteManyParams<RecordType>) => Promise<import("react-admin").DeleteManyResult<RecordType>>;
    supportAbortSignal?: boolean;
};
//# sourceMappingURL=addAIMethodsBasedOnOpenAIAPI.d.ts.map