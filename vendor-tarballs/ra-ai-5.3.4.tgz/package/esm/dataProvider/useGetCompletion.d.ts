import { UseQueryOptions } from '@tanstack/react-query';
import { OnError, OnSuccess } from 'react-admin';
import { GetCompletionParams, GetCompletionResult } from './types';
/**
 * Call the dataProvider.getCompletion() method via react-query, and return the result
 *
 * @example
 * const { data, isPending, error } = useGetCompletion({ prompt: 'Lorem ipsum' });
 * console.log(data);
 * // ' dolor sit amet, consectetur adipiscing elit.'
 *
 * @example // openAI Params
 * const { data, isPending, error } = useGetCompletion({
 *     prompt: 'Lorem ipsum',
 *     meta: { temperature: 0.5 },
 * });
 */
export declare const useGetCompletion: <ErrorType = Error>(params: GetCompletionParams, options?: UseGetCompletionOptions<ErrorType>) => import("@tanstack/react-query").UseQueryResult<GetCompletionResult, ErrorType>;
export type UseGetCompletionOptions<ErrorType = Error> = {
    onSuccess?: OnSuccess;
    onError?: OnError;
} & Omit<UseQueryOptions<GetCompletionResult, ErrorType>, 'queryKey' | 'queryFn'>;
//# sourceMappingURL=useGetCompletion.d.ts.map