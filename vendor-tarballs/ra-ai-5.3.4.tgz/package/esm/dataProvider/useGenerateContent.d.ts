import { UseQueryOptions } from '@tanstack/react-query';
import { GenerateContentParams, GenerateContentResult } from './types';
/**
 * Call the dataProvider.generateContent() method via react-query, and return the result
 *
 * @example
 * const { data, isPending, error } = useGenerateContent({ prompt: 'Write me a poem' });
 * console.log(data);
 * // 'Roses are red, violets are blue...'
 *
 * @example // openAI Params
 * const { data, isPending, error } = useGenerateContent({
 *     prompt: 'Write me a poem',
 *     meta: { temperature: 0.5 } ,
 * });
 */
export declare const useGenerateContent: <ErrorType = Error>(params: GenerateContentParams, options?: UseGenerateContentOptions<ErrorType>) => import("@tanstack/react-query").UseQueryResult<GenerateContentResult, ErrorType>;
export type UseGenerateContentOptions<ErrorType = Error> = Omit<UseQueryOptions<GenerateContentResult, ErrorType>, 'queryKey' | 'queryFn'>;
//# sourceMappingURL=useGenerateContent.d.ts.map