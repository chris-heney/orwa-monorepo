import { UseMutationOptions } from '@tanstack/react-query';
export declare const SmartRichTextInputParamsContext: import("react").Context<SmartRichTextInputParamsContextType>;
export declare const useSmartRichTextInputParamsContext: (props: any) => SmartRichTextInputParamsContextType;
export interface SmartRichTextInputParamsContextType {
    locale?: string;
    stop?: string[];
    maxSize?: number;
    temperature?: number;
    meta?: any;
    mutationOptions?: Omit<UseMutationOptions<{
        data: string;
    }, Error, string>, 'mutationKey' | 'mutationFn'>;
}
//# sourceMappingURL=SmartRichTextInputParamsContext.d.ts.map