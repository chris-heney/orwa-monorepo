import * as React from 'react';
import { UseGetCompletionOptions } from '../../../dataProvider/useGetCompletion';
/**
 * Controller logic for the <TextInputWithCompletion> component
 */
export declare const usePredictiveTextInputController: <ErrorType = Error>(props: UsePredictiveTextInputControllerParams<ErrorType>) => {
    completion: string;
    handleFocus: (event: React.FocusEvent<HTMLInputElement>) => void;
    handleBlur: (event: React.FocusEvent<HTMLInputElement>) => void;
    handleKeyDown: (event: React.KeyboardEvent<HTMLInputElement>) => void;
};
export interface UsePredictiveTextInputControllerParams<ErrorType = Error> {
    field: {
        name: string;
        value: string;
        onFocus?: (event: React.FocusEvent<HTMLInputElement>) => void;
        onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
    };
    locale?: string;
    debounce?: number;
    resource?: string;
    promptGenerator?: (params: {
        resource: string;
        name: string;
        value?: string;
        record?: Record<string, any>;
    }) => string;
    maxSize?: number;
    meta?: any;
    stop?: string[];
    temperature?: number;
    queryOptions?: UseGetCompletionOptions<ErrorType>;
}
//# sourceMappingURL=usePredictiveTextInputController.d.ts.map