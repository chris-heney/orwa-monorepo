import * as React from 'react';
import { TextInputProps } from 'react-admin';
import { UseGetCompletionOptions } from 'packages/ra-ai/src/dataProvider';
/**
 * Implementation of PredictiveTextInput for monoline inputs
 */
export declare const TextInputWithCompletion: <ErrorType = Error>(props: TextInputWithCompletionProps<ErrorType>) => React.JSX.Element;
export interface TextInputWithCompletionProps<ErrorType = Error> extends Omit<TextInputProps, 'resettable'> {
    debounce?: number;
    locale?: string;
    promptGenerator?: (params: {
        resource: string;
        name: string;
        value?: string;
        record?: Record<string, any>;
    }) => string;
    maxSize?: number;
    meta?: any;
    stop?: string[];
    temperature?: number;
    queryOptions?: UseGetCompletionOptions<ErrorType>;
}
//# sourceMappingURL=TextInputWithCompletion.d.ts.map