import * as React from 'react';
import { TextInputWithCompletionProps } from './monoline/TextInputWithCompletion';
import { TextareaWithCompletionProps } from './multiline/TextareaWithCompletion';
/**
 * An alternative to `<TextInput>` that suggests completion for the input value.
 *
 * Users can accept the completion by pressing the `Tab` key. It's like Intellisense or Copilot for your forms.
 *
 * @example
 * import { Edit, SimpleForm, TextInput } from 'react-admin';
 * import { PredictiveTextInput } from '@react-admin/ra-ai';
 *
 * const PersonEdit = () => (
 *     <Edit>
 *         <SimpleForm>
 *             <TextInput source="firstName" />
 *             <TextInput source="lastName" />
 *             <TextInput source="company" />
 *             <PredictiveTextInput source="email" />
 *             <PredictiveTextInput source="website" />
 *             <PredictiveTextInput source="bio" multiline />
 *         </SimpleForm>
 *     </Edit>
 * );
 */
export declare const PredictiveTextInput: <ErrorType = Error>(props: PredictiveTextInputProps<ErrorType>) => React.JSX.Element;
export interface TextInputMonolineWithCompletionProps<ErrorType = Error> extends TextInputWithCompletionProps<ErrorType> {
    multiline?: false;
}
export interface TextInputMultilineWithCompletionProps<ErrorType = Error> extends TextareaWithCompletionProps<ErrorType> {
    multiline: true;
}
export type PredictiveTextInputProps<ErrorType = Error> = TextInputMonolineWithCompletionProps<ErrorType> | TextInputMultilineWithCompletionProps<ErrorType>;
//# sourceMappingURL=PredictiveTextInput.d.ts.map