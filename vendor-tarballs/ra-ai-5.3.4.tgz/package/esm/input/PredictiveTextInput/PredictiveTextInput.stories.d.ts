import * as React from 'react';
declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => React.JSX.Element;
export declare const Default: () => React.JSX.Element;
export declare const NotFullWidth: () => React.JSX.Element;
export declare const FullWidth: () => React.JSX.Element;
export declare const Variant: () => React.JSX.Element;
export declare const Debounce: {
    ({ debounce }: {
        debounce?: number | undefined;
    }): React.JSX.Element;
    args: {
        debounce: number;
    };
};
export declare const PromptGenerator: () => React.JSX.Element;
export declare const MaxSize: () => React.JSX.Element;
export declare const Stop: () => React.JSX.Element;
export declare const Temperature: () => React.JSX.Element;
export declare const Source: () => React.JSX.Element;
export declare const MultilineAutoSize: () => React.JSX.Element;
export declare const MultilineRows: () => React.JSX.Element;
export declare const MultilineRowsBasic: () => React.JSX.Element;
export declare const MultilineNotFullWidth: () => React.JSX.Element;
export declare const MultilineFullWidth: () => React.JSX.Element;
export declare const Sx: () => React.JSX.Element;
export declare const Type: () => React.JSX.Element;
export declare const DataProviderError: () => React.JSX.Element;
export declare const Context: () => React.JSX.Element;
export declare const Slow: () => React.JSX.Element;
export declare const Locale: () => React.JSX.Element;
export declare const QueryOptions: () => React.JSX.Element;
//# sourceMappingURL=PredictiveTextInput.stories.d.ts.map