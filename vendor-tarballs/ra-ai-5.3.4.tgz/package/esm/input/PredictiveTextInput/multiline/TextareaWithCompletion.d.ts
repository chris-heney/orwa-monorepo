import * as React from 'react';
import { TextInputProps } from 'react-admin';
import { SxProps } from '@mui/material';
import { UseGetCompletionOptions } from '../../../dataProvider';
/**
 * A TextareaInput that suggests completions when the user types.
 *
 * Warning: This input updates the form value onBlur, not on every keystroke.
 */
export declare const TextareaWithCompletion: <ErrorType = Error>(props: TextareaWithCompletionProps<ErrorType>) => React.JSX.Element;
export interface TextareaWithCompletionProps<ErrorType = Error> extends TextInputProps {
    debounce?: number;
    locale?: string;
    maxSize?: number;
    maxRows?: string | number;
    rows?: string | number;
    meta?: any;
    minRows?: string | number;
    promptGenerator?: (params: {
        resource: string;
        name: string;
        caretPosition: number;
        value?: string;
        record?: Record<string, any>;
        locale?: string;
    }) => string;
    queryOptions?: UseGetCompletionOptions<ErrorType>;
    stop?: string[];
    sx?: SxProps;
    temperature?: number;
}
//# sourceMappingURL=TextareaWithCompletion.d.ts.map