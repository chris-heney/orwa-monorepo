import * as React from 'react';
declare const _default: {
    title: string;
    decorators: ((Story: any) => React.JSX.Element)[];
};
export default _default;
export declare const Default: () => React.JSX.Element;
export declare const NoValue: () => React.JSX.Element;
export declare const Label: () => React.JSX.Element;
export declare const Margin: () => React.JSX.Element;
export declare const Size: () => React.JSX.Element;
export declare const Variant: () => React.JSX.Element;
export declare const NotFullWidth: () => React.JSX.Element;
export declare const FullWidth: () => React.JSX.Element;
export declare const MinRows: {
    ({ minRows }: {
        minRows: any;
    }): React.JSX.Element;
    args: {
        minRows: number;
    };
};
export declare const MaxRows: {
    ({ maxRows }: {
        maxRows: any;
    }): React.JSX.Element;
    args: {
        maxRows: number;
    };
};
export declare const MaxRowsBasic: () => React.JSX.Element;
export declare const MaxRowsFullWidth: () => React.JSX.Element;
export declare const MaxRowsNotFullWidth: () => React.JSX.Element;
export declare const HelperText: () => React.JSX.Element;
export declare const Validate: () => React.JSX.Element;
export declare const Sx: () => React.JSX.Element;
export declare const OpenAI: () => React.JSX.Element;
export declare const QueryOptions: () => React.JSX.Element;
export declare const InsideDialog: () => React.JSX.Element;
//# sourceMappingURL=TextareaWithCompletion.stories.d.ts.map