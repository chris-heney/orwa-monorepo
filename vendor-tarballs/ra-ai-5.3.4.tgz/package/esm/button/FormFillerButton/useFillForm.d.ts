type FieldName = string;
type FieldCompletionHint = string;
type UseFillFormPArams = {
    fields?: Record<FieldName, FieldCompletionHint>;
    onError?: (error: Error) => void;
    maxDimension?: number;
    allowOverride?: boolean;
    meta?: any;
};
export declare const useFillForm: (params: UseFillFormPArams) => {
    isPending: boolean;
    performCompletion: (file: File) => Promise<void>;
};
export {};
//# sourceMappingURL=useFillForm.d.ts.map