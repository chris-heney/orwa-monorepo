import { type DialogProps } from '@mui/material';
import { default as React } from 'react';
export interface ScanFromCameraDialogProps extends DialogProps {
    onClose: () => void;
    onCapture: (datUrl: string) => void;
}
export declare const ScanFromCameraDialog: ({ open, onClose, onCapture, ...DialogProps }: ScanFromCameraDialogProps) => React.JSX.Element;
//# sourceMappingURL=ScanFromCameraDialog.d.ts.map