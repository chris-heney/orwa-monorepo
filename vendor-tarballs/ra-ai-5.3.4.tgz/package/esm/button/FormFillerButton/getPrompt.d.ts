export declare const getObjectDescriptionParts: (formSchema: Record<string, unknown>, fieldsDescription: Record<string, unknown> | string | null | undefined, indentation?: string) => string[];
export declare const getPrompt: (formValues: Record<string, unknown>, fieldsDescription: Record<string, unknown> | null | undefined) => string;
//# sourceMappingURL=getPrompt.d.ts.map