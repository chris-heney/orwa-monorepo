import * as React from 'react';
declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => React.JSX.Element;
export declare const ErrorCase: () => React.JSX.Element;
export declare const AllowOverride: () => React.JSX.Element;
export declare const Fields: () => React.JSX.Element;
export declare const Sources: {
    ({ sources, }: {
        sources: Array<"image" | "camera">;
    }): React.JSX.Element;
    args: {
        sources: string[];
    };
    argTypes: {
        sources: {
            options: string[];
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=FormFillerButton.stories.d.ts.map