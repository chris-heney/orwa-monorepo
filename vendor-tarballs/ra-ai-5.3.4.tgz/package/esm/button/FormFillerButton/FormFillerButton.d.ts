import * as React from 'react';
import { type ButtonProps, type ButtonGroupProps, type DialogProps } from '@mui/material';
type FieldName = string;
type FieldCompletionHint = string;
type FormFillerButtonProps = {
    fields?: Record<FieldName, FieldCompletionHint>;
    acceptedFileTypes?: string;
    ButtonProps?: ButtonProps;
    ButtonGroupProps?: ButtonGroupProps;
    DialogProps?: DialogProps;
    sources?: Array<'image' | 'camera'>;
    maxDimension?: number;
    allowOverride?: boolean;
    meta?: any;
};
/**
 * A button that allows the user to fill a form using an image or a camera.
 */
export declare const FormFillerButton: ({ fields, acceptedFileTypes, sources, ButtonProps, ButtonGroupProps, DialogProps, maxDimension, allowOverride, meta, }: FormFillerButtonProps) => React.JSX.Element;
export {};
//# sourceMappingURL=FormFillerButton.d.ts.map