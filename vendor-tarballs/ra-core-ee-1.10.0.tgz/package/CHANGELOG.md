# CHANGELOG

## v1.10.0

> 2026-02-10

- Introduce `useListInputController`

## v1.9.0

> 2026-02-03

- `useAutoPersistInStore` and `<AutoPersistInStoreBase>` now accept a `maxAge` prop that will remove all auto-persisted values older than `maxAge` each time new values are persisted.

## v1.8.3

> 2026-02-03

- Refresh the deleted records list after a soft deletion of many records
- Refresh the related list after restoring a record
- Refresh the related lists after restoring many records

## v1.8.2

> 2026-01-29

- Refresh the deleted records list after a soft deletion

## v1.8.1

> 2026-01-20

- Fix `<ReferenceManyInputBase>` does not register the temporary field in form groups

## v1.8.0

> 2025-12-11

- Import headless hooks and functions from `ra-form-layout`
- Update and require `ra-core@5.13.1`
- Add `<AutoSaveBase>` and `useAutoSaveContext`
- Add `<BulkUpdateFormBase>`
- Add `<AutoPersistInStoreBase>` and `useAutoPersistInStore`

Note that `useAutoPersistInStore` requires a `SaveContext` with support for [middlewares](https://marmelab.com/ra-core/useregistermutationmiddleware/)

## v1.7.1

> 2025-12-05

- Fix compatibility with latest `react-hook-form` versions

## v1.7.0

> 2025-12-05

- Fix `addSoftDeleteInPlace` assumes the presence of the `deleted_at` field even on resource which do not support soft-delete
- Update `useHardDelete` and `useHardDeleteMany` to leverage `useMutationWithMutationMode`
- Upgraded `ra-core` peer dependency to `5.12.3`

## v1.6.0

> 2025-11-12

- Fix `<ReferenceManyInputBase>` compatibility with `react-hook-form` version 7.65.0 and above
- Fix `<ReferenceOneInputBase>` compatibility with `react-hook-form` version 7.65.0 and above
- Bump minimum `react-hook-form` version to 7.65.0

**Minor Breaking Change**

The temporary input source used by `<ReferenceManyInputBase>` has changed:

```diff
-`@@ra-many/${resource}/${reference}/${target}.0.${reference}`
+`@@ra-many/${resource}/${reference}/${target}.${reference}`
```

This should only affect you if you target this input source directly in your code.

If you are using the `getReferenceManyFormField` helper function to compute it, you don't need to change anything, as the function has been updated accordingly.

Likewise, the temporary input source used by `<ReferenceOneInputBase>` has changed:

```diff
-`@@ra-one/${resource}/${reference}/${target}.0`
+`@@ra-one/${resource}/${reference}/${target}`
```

This should only affect you if you target this input source directly in your code.

If you are using the `getReferenceOneFormField` helper function to compute it, you don't need to change anything, as the function has been updated accordingly.

## v1.5.2

> 2025-10-31

- Fix `<ReferenceManyInputBase>` in `pessimistic` mode should not keep the form dirty after submission
- Fix `<ReferenceManyInputBase>` should not mark the form as dirty when applying defaultValues

## v1.5.1

> 2025-10-24

- Fix a bug that caused `useReferenceManyToManyFieldController` to filter records with `id = 0` in referenced tables

## v1.5.0

> 2025-10-20

- Import headless hooks and functions from `ra-history`
- Introduce `useGenerateChangeMessage` hook
- Fix `useAddRevision` and `useDeleteRevisions` do not properly update cache from hook-time params

## v1.4.0

> 2025-10-14

- Add `getEnglishTranslations` and `getFrenchTranslations` functions

## v1.3.0

> 2025-10-09

- Import headless hooks and functions from `ra-soft-delete`

## v1.2.0

> 2025-09-30

- Import headless hooks from `ra-relationships`

## v1.1.0

> 2025-09-19

- Import headless hooks and functions from `ra-realtime`

## v1.0.0

> 2025-09-08

- Import headless hooks from `ra-rbac`
