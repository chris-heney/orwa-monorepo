# ra-core-ee

Headless hooks and components for building enterprise-grade applications with React Admin.

## Installation

```sh
npm install --save @react-admin/ra-core-ee
# or
yarn add @react-admin/ra-core-ee
```

**Tip**: `ra-core-ee` is part of the [React-Admin Enterprise Edition](https://marmelab.com/ra-enterprise/), and hosted in a private npm registry. You need to subscribe to one of the Enterprise Edition plans to access this package.

## Authorization

`ra-core-ee` provides helper functions that facilitates the implementation of Access Control policies based on an underlying list of user roles and permissions:

- [`canAccessWithPermissions`](https://marmelab.com/ra-core/canaccesswithpermissions/)
- [`getPermissionsFromRoles`](https://marmelab.com/ra-core/getpermissionsfromroles/)

## History

`@react-admin/ra-core-ee` contains hooks and components to help you track the changes made in your admin. See the history of revisions, compare differences between any two versions, and revert to a previous state if needed.

Read the documentation for this feature on the [headless documentation website](https://marmelab.com/ra-core/historyfeatures/).

## Realtime

`@react-admin/ra-core-ee` provides hooks and components for collaborative applications where several people work in parallel. It supports:

- publishing and subscribing to real-time events,
- updating views when another user pushes a change,
- notifying end users of events, and
- preventing data loss when two editors work on the same resource concurrently with locks.

Read the documentation for this feature on the [headless documentation website](https://marmelab.com/ra-core/realtimefeatures/).

## Soft Delete

`@react-admin/ra-core-ee` provides hooks and components that allows you to "delete" records without actually removing them from your database. It supports:

- Archive records safely instead of permanent deletion
- Browse and filter all deleted records in a dedicated interface
- Restore archived items individually or in bulk
- Track who deleted what and when

Read the documentation for this feature on the [headless documentation website](https://marmelab.com/ra-core/softdeletedataprovider/).

## Relationships

`@react-admin/ra-core-ee` provides components to manage relationships between resources in forms and views:

- [`<ReferenceOneInputBase>`](https://marmelab.com/ra-core/referenceoneinputbase/)
- [`<ReferenceManyInputBase>`](https://marmelab.com/ra-core/referencemanyinputbase/)
- [`<ReferenceManyToManyFieldBase>`](https://marmelab.com/ra-core/referencemanytomanyfieldbase/)
- [`<ReferenceManyToManyInputBase>`](https://marmelab.com/ra-core/referencemanytomanyinputbase/)

## Forms

`@react-admin/ra-core-ee` provides hooks and components to build advanced form features:

- [`<AutoSaveBase>`](https://marmelab.com/ra-core/autosavebase/)
- [`<AutoPersistInStoreBase>`](https://marmelab.com/ra-core/autopersistinstorebase/)
- [`<BulkUpdateFormBase>`](https://marmelab.com/ra-core/bulkupdateformbase/)
- [`useAutoSave`](https://marmelab.com/ra-core/useautosave)
- [`useAutoPersistInStore`](https://marmelab.com/ra-core/useautopersistinstore)
