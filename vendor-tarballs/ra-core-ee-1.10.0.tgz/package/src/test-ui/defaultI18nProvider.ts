import polyglotI18nProvider from 'ra-i18n-polyglot';
import englishMessages from 'ra-language-english';

export const defaultI18nProvider = polyglotI18nProvider(() => englishMessages);
