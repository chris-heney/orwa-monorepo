import { createContext, useContext } from 'react';
import { Lock } from './types';

export const LocksContext = createContext<Lock[]>([]);

export const useLocksContext = () => useContext(LocksContext);
