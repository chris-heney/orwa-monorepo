export interface RaRealTimeTranslationMessages {
    'ra-realtime': {
        notification: {
            title: string;
            record: {
                updated: string;
                deleted: string;
                unlocking: string;
            };
        };
        locks: {
            status: {
                locked_by_you: string;
                locked_by_another_user: string;
                unlocked: string;
            };
        };
    };
}

export default RaRealTimeTranslationMessages;
