import RaRealTimeTranslationMessages from './RaRealTimeTranslationMessages';

export const raRealTimeLanguageEnglish: RaRealTimeTranslationMessages = {
    'ra-realtime': {
        notification: {
            title: 'Warning',
            record: {
                updated: 'This record has been updated by another user',
                deleted:
                    'This record has been deleted and is no longer available',
                unlocking: 'Unlocking the record...',
            },
        },
        locks: {
            status: {
                locked_by_you: 'Locked by you, click to unlock',
                locked_by_another_user: 'Locked by another user: %{identity}',
                unlocked: 'Record is unlocked, click to lock',
            },
        },
    },
};

export default raRealTimeLanguageEnglish;
