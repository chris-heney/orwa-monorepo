import RaRealTimeTranslationMessages from './RaRealTimeTranslationMessages';

export const raRealTimeLanguageFrench: RaRealTimeTranslationMessages = {
    'ra-realtime': {
        notification: {
            title: 'Attention',
            record: {
                updated:
                    'Cet enregistrement a été modifié par un autre utilisateur',
                deleted:
                    "Cet enregistrement a été supprimé et n'est plus disponible",
                unlocking: "Déverrouillage de l'enregistrement...",
            },
        },
        locks: {
            status: {
                locked_by_you:
                    'Verrouillé par vous, cliquez pour déverrouiller',
                locked_by_another_user:
                    'Verrouillé par un autre utilisateur : %{identity}',
                unlocked:
                    'L’enregistrement est déverrouillé, cliquez pour verrouiller',
            },
        },
    },
};

export default raRealTimeLanguageFrench;
