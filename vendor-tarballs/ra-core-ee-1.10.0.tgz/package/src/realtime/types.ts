import { Identifier } from 'ra-core';
import { EventSourcePolyfill } from 'event-source-polyfill';

export enum EventType {
    Updated = 'updated',
    Created = 'created',
    Deleted = 'deleted',
}

export interface Event {
    topic?: string;
    type: string | EventType;
    payload?: any;
    [key: string]: any;
}

export interface RecordListEvent extends Event {
    payload?: {
        ids: Identifier[];
    };
}

export interface RecordEvent extends Event {
    payload?: {
        id: Identifier;
    };
}

export type SubscriptionCallback<T = Event> = (event: T) => void;
export type SubscriptionCallbackWithUnsubscribe<T = Event> = (
    event: T,
    unsubscribe: () => Promise<any>
) => void;

export type Subscriptions = {
    topic: string;
    subscriptionCallback: SubscriptionCallback;
}[];

export interface EventSources {
    [topic: string]: EventSourcePolyfill;
}

export type GetOrdersListEvents = (Array) => void;

export interface RealTimeDataProvider {
    subscribe: (
        topic: string,
        subscriptionCallback: SubscriptionCallback
    ) => Promise<any>;
    unsubscribe: (
        topic: string,
        subscriptionCallback: SubscriptionCallback
    ) => Promise<any>;
    publish: (topic: string, payload: Event) => Promise<any>;
}

export type Lock = {
    id?: Identifier;
    resource: string;
    recordId: Identifier;
    createdAt?: any;
    identity?: string;
};

export interface LocksDataProvider {
    lock: (resource: string, params: LockParams) => Promise<LockResult>;
    unlock: (resource: string, params: UnlockParams) => Promise<any>;
    getLock: (
        resource: string,
        params: GetLockParams
    ) => Promise<GetLockResult>;
    getLocks: (
        resource: string,
        params: GetLocksParams
    ) => Promise<GetLocksResult>;
}

export interface GetLockParams {
    id: Identifier;
    meta?: any;
}

export interface GetLockResult {
    data?: Lock;
}

export interface GetLocksParams {
    meta?: any;
}

export interface GetLocksResult {
    data: Lock[];
}

export interface LockParams {
    id: Identifier;
    identity: Identifier;
    meta?: any;
}

export interface LockResult {
    data: Lock;
}

export interface UnlockParams {
    id: Identifier;
    identity: Identifier;
    meta?: any;
}
