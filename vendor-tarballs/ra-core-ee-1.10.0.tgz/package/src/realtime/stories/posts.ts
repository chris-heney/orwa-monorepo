export const posts = [
    {
        id: 1,
        title: 'The Future of Artificial Intelligence: Predictions and Implications',
        headline:
            'Experts weigh in on the potential future of AI and its impact on society',
        author: 'Sarah Johnson',
    },
    {
        id: 2,
        title: '5 Ways Blockchain Technology is Revolutionizing Industries',
        headline:
            'From finance to supply chain management, see how blockchain is disrupting traditional systems',
        author: 'Elizabeth Williams',
    },
    {
        id: 3,
        title: 'The Pros and Cons of Cloud Computing: A Comprehensive Guide',
        headline:
            'Exploring the benefits and drawbacks of using cloud-based services for your business',
        author: 'David Kim',
    },
    {
        id: 4,
        title: 'Top 10 Tech Gadgets to Look Out for in 2022',
        headline:
            'From smart home devices to wearable technology, check out the top trends in tech for the coming year',
        author: 'Sarah Johnson',
    },
    {
        id: 5,
        title: 'The Ethics of Big Data: Privacy, Security, and Transparency',
        headline:
            'Examining the ethical considerations of collecting, storing, and using large amounts of data',
        author: 'William Taylor',
    },
    {
        id: 6,
        title: 'How Virtual Reality is Changing the Way We Learn and Work',
        headline:
            'Discover the innovative ways VR is being used for education and training in various industries',
        author: 'David Kim',
    },
    {
        id: 7,
        title: 'The Rise of the Internet of Things: Opportunities and Challenges',
        headline:
            'Explore the potential benefits and challenges of a world connected by billions of smart devices',
        author: 'John Rodriguez',
    },
    {
        id: 8,
        title: '10 Tips for Protecting Your Online Privacy',
        headline:
            'Learn how to secure your personal information and protect yourself from cyber threats',
        author: 'David Kim',
    },
    {
        id: 9,
        title: 'The Impact of Machine Learning on Healthcare and Medicine',
        headline:
            'Discover how AI is being used to improve patient care and streamline medical processes',
        author: 'Emily Brown',
    },
    {
        id: 10,
        title: '5G Technology: What It Is and Why It Matters',
        headline:
            'Understand the basics of 5G and the potential it has to transform the way we live and work',
        author: 'Elizabeth Williams',
    },
];
