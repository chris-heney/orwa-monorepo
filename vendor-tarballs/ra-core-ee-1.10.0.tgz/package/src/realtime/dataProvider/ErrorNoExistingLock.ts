export class ErrorNoExistingLock extends Error {
    constructor(message?: string) {
        super(message);
        Object.setPrototypeOf(this, ErrorNoExistingLock.prototype);
    }
}
