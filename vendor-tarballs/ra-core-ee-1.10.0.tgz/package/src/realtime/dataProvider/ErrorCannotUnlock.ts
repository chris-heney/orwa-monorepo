export class ErrorCannotUnlock extends Error {
    constructor(message?: string) {
        super(message);
        Object.setPrototypeOf(this, ErrorCannotUnlock.prototype);
    }
}
