import { RealtimePostgresChangesPayload } from '@supabase/supabase-js';
import {
    getIdFromTopic,
    getTableFromTopic,
    getCRUDEventTypeFromSupabaseType,
    getIdsFromPayload,
} from './addRealTimeMethodsBasedOnSupabase';

describe('addRealTimeMethodsBasedOnSupabase', () => {
    describe('getCRUDEventTypeFromSupabaseType', () => {
        it('should transform an UPDATE event to type "updated"', () => {
            expect(getCRUDEventTypeFromSupabaseType('UPDATE')).toEqual(
                'updated'
            );
        });
        it('should return the original event type when it is unknown', () => {
            expect(getCRUDEventTypeFromSupabaseType('unknown')).toEqual(
                'unknown'
            );
        });
    });

    describe('getTableFromTopic', () => {
        it('should return the resource from the topic', () => {
            const topic = 'resource/sales/1';
            expect(getTableFromTopic(topic)).toEqual('sales');
        });
    });

    describe('getIdFromTopic', () => {
        it('should return the id from the topic', () => {
            expect(getIdFromTopic('resource/posts/123')).toEqual('123');
        });
        it('should return undefined when there is no id in the topic', () => {
            expect(getIdFromTopic('resource/posts')).toBeUndefined();
        });
    });

    describe('getIdsFromPayload', () => {
        it('should return an array with the record id from the payload', () => {
            const payload: RealtimePostgresChangesPayload<{
                [key: string]: any;
            }> = {
                eventType: 'INSERT',
                old: {},
                new: {
                    id: '123',
                },
                schema: 'public',
                table: 'posts',
                commit_timestamp: '2021-01-01T00:00:00.000000+00:00',
                errors: [],
            };
            expect(getIdsFromPayload(payload)).toEqual(['123']);
        });
        it('should return an empty array when there is no id in the payload', () => {
            const payload: RealtimePostgresChangesPayload<{
                [key: string]: any;
            }> = {
                eventType: 'DELETE',
                old: {},
                new: {},
                schema: 'public',
                table: 'posts',
                commit_timestamp: '2021-01-01T00:00:00.000000+00:00',
                errors: [],
            };
            expect(getIdsFromPayload(payload)).toEqual([]);
        });
    });
});
