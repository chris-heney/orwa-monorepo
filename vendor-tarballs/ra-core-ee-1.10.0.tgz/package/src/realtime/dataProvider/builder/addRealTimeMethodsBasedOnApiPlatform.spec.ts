import { defaultTransformTopicFromRaRealtime } from './addRealTimeMethodsBasedOnApiPlatform';

describe('defaultTransformTopicFromRaRealtime', () => {
    it('should format the the ra-realtime record topic into a topic following the API-Platform convention', () => {
        expect(
            defaultTransformTopicFromRaRealtime(
                'resource/greetings//greetings/1'
            )
        ).toEqual('/greetings/1');
    });

    it('should format the the ra-realtime list topic into a topic following the API-Platform convention', () => {
        expect(
            defaultTransformTopicFromRaRealtime('resource/greetings')
        ).toEqual('/greetings/{id}');
    });
});
