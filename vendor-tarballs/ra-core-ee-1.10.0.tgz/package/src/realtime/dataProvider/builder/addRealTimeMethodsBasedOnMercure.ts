import { EventSourcePolyfill } from 'event-source-polyfill';
import qs from 'query-string';
import debounce from 'lodash/debounce';
import { DataProvider } from 'ra-core';

import { RealTimeDataProvider, Event, Subscriptions } from '../../types';
import { ErrorMissingTopic } from '../ErrorMissingTopic';
import { ErrorMissingEventType } from '../ErrorMissingEventType';

/**
 * Add realTime methods to a dataProvider based on a Mercure Hub.
 *
 * @see https://mercure.rocks/
 *
 * @param {DataProvider} dataProvider The dataProvider to augment
 * @param {string} mercureURL The adress of the Mercure hub
 * @param {string} jwt The JWT to connect to Mercure hub
 * @param {string} topicPrefix The prefix used for each subcription topics (without slash at the end)
 *
 * @example
 *
 * const realTimeDataProvider = addRealTimeMethodsBasedOnMercure(
 *     dataProvider,
 *     'eyJhbGciOiJIUzI1NiJ9.eyJtZXJjdXJlIjp7InB1Ymxpc2giOlsiKiJdLCJzdWJzY3JpYmUiOlsiKiJdfX0.SWKHNF9wneXTSjBg81YN5iH8Xb2iTf_JwhfUY5Iyhsw',
 *     'http://path.to.my.api/.well-known/mercure'
 * );
 *
 * await realTimeDataProvider.subscribe('resource/post', (event) => {
 *    console.log(`Post ${event.payload.id} modified`);
 * });
 *
 * await realTimeDataProvider.publish('resource/post', {
 *     type: 'updated',
 *     payload: { id: 1234 }
 * })
 */
export const addRealTimeMethodsBasedOnMercure = (
    dataProvider: DataProvider,
    mercureURL: string,
    jwt = 'set_jwt_key',
    topicPrefix = 'http://localhost/mercure'
): DataProvider & RealTimeDataProvider => {
    let subscriptions: Subscriptions = [];
    let eventSource: EventSourcePolyfill;

    const openEventSource = debounce(
        (): Promise<any> => {
            eventSource && eventSource.close && eventSource.close();
            // Calling mercure with no topic causes an error 400 to be raised.
            // Hence, if there are no subscriptions yet, we don't create an eventSource at all.
            if (!subscriptions.length) {
                return Promise.resolve({ data: true });
            }
            const url = new URL(mercureURL);
            const topics = Array.from(
                new Set(subscriptions.map(subscription => subscription.topic))
            );
            topics.forEach(topic =>
                url.searchParams.append('topic', `${topicPrefix}/${topic}`)
            );
            return new Promise((resolve, reject) => {
                eventSource = new EventSourcePolyfill(url, {
                    headers: { Authorization: `Bearer ${jwt}` },
                });
                eventSource.onmessage = (e: any): void => {
                    const event: Event = JSON.parse(e.data);
                    subscriptions.forEach(subscription => {
                        event.topic === subscription.topic &&
                            subscription.subscriptionCallback(event);
                    });
                };

                eventSource.onopen = (): any => {
                    return resolve({ data: true });
                };

                eventSource.onerror = (err): void => {
                    // eslint-disable-next-line no-console
                    console.warn('EventSource error: ', err);
                    return reject(err);
                };
            });
        },
        500,
        { leading: true } // lodash needs this option to return the result of the promise apparently - source https://stackoverflow.com/a/50837389/3975522
    );

    const pushEvent = (topic: string, payload: string): Promise<any> => {
        const body = {
            topic: `${topicPrefix}/${topic}`,
            data: payload,
        };

        const headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            Authorization: `Bearer ${jwt}`,
        };

        return fetch(mercureURL, {
            method: 'POST',
            body: qs.stringify(body),
            headers,
        })
            .then(mercureRes => {
                console.log('Push mercure done'); // eslint-disable-line no-console
                console.log(mercureRes); // eslint-disable-line no-console
                return { data: true };
            })
            .catch(mercureError => {
                return { data: new Error(mercureError) };
            });
    };

    return {
        ...dataProvider,

        subscribe: async (topic, subscriptionCallback): Promise<any> => {
            subscriptions.push({ topic, subscriptionCallback });
            return openEventSource();
        },

        unsubscribe: async (topic, subscriptionCallback): Promise<any> => {
            subscriptions = subscriptions.filter(
                subscription =>
                    subscription.topic !== topic ||
                    subscription.subscriptionCallback !== subscriptionCallback
            );
            return openEventSource();
        },

        publish: (topic, event): Promise<any> => {
            if (!topic) {
                return Promise.reject(new ErrorMissingTopic());
            }
            if (!event.type) {
                return Promise.reject(new ErrorMissingEventType());
            }
            const payload = JSON.stringify({ topic, ...event });
            return pushEvent(topic, payload);
        },
    };
};
