/* eslint-disable no-console */
import { DataProvider } from 'ra-core';

import { RealTimeDataProvider } from '../../types';

/**
 * Add realTime methods to a dataProvider based on a localstorage event bus.
 *
 * The publish/subscribe events happen only in the current browser - no event
 * broadcasting to other clients, except on other tabs of the same browser.
 * This is done only for testing purposes.
 *
 * @param {DataProvider} dataProvider The dataProvider to augment
 * @returns {DataProvider}
 *
 * @warning Do not use in production.
 *
 * @example
 *
 * const realTimeDataProvider = addRealTimeMethodsInLocalStorage(dataProvider);
 *
 * await realTimeDataProvider.subscribe('resource/post', (event) => {
 *    console.log(`Post ${event.payload.id} modified`);
 * });
 *
 * await realTimeDataProvider.publish('resource/post', {
 *     type: 'updated',
 *     payload: { id: 1234 }
 * })
 */
export const addRealTimeMethodsInLocalStorage = (
    dataProvider: DataProvider
): DataProvider & RealTimeDataProvider => {
    const listeners = {};
    window.addEventListener(
        'storage',
        event => {
            const topics = Object.keys(listeners);
            const topic = topics.find(
                topic => event.key === `__topic__${topic}`
            );
            if (topic && event.newValue) {
                const message = JSON.parse(event.newValue);
                listeners[topic].forEach(callback => {
                    callback(message);
                });
                process.env.NODE_ENV !== 'test' &&
                    console.debug(`Executed listeners on`, topic, message);
            }
        },
        false
    );

    return {
        ...dataProvider,
        publish: (topic, message): Promise<any> => {
            const dataKey = `__topic__${topic}`;
            const jsonData = JSON.stringify(message);
            localStorage.setItem(dataKey, jsonData);

            // The storage event is not triggered on the current window;
            // Manually dispatch to current window
            const event = new StorageEvent('storage', {
                key: dataKey,
                newValue: jsonData,
            });
            window.dispatchEvent(event);

            process.env.NODE_ENV !== 'test' &&
                console.debug(`Published to`, topic, message);

            return Promise.resolve({ data: null });
        },

        subscribe: (topic, callback): Promise<any> => {
            if (listeners[topic] == null) {
                listeners[topic] = [];
            }
            listeners[topic].push(callback);
            process.env.NODE_ENV !== 'test' &&
                console.debug(`Subscribed to`, topic);

            return Promise.resolve({ data: null });
        },

        unsubscribe: (topic, callback): Promise<any> => {
            if (listeners[topic] == null) {
                return Promise.resolve({ data: null });
            }
            listeners[topic] = listeners[topic].filter(
                v => v.toString() !== callback.toString()
            );
            process.env.NODE_ENV !== 'test' &&
                console.debug(`Unsubscribed from`, topic);
            return Promise.resolve({ data: null });
        },
    };
};
