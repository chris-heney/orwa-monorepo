import {
    SupabaseClient,
    RealtimePostgresChangesPayload,
} from '@supabase/supabase-js';
import { DataProvider, Identifier } from 'ra-core';
import { RealTimeDataProvider, Subscriptions } from '../../types';

/**
 * Add real time methods to a dataProvider based on a Supabase client.
 *
 * @see https://supabase.com/docs/guides/realtime
 * @see https://supabase.com/docs/guides/realtime/extensions/postgres-changes
 *
 * @param dataProvider The dataProvider to augment
 * @param supabaseClient The Supabase client
 *
 * @example
 * ```tsx
 * import { addRealTimeMethodsBasedOnSupabase } from '@react-admin/ra-core-ee';
 * import { supabaseDataProvider } from 'ra-supabase';
 * import { CoreAdmin, Resource } from 'ra-core';
 * import { supabaseClient, instanceUrl, apiKey } from './supabaseClient';
 * import { SaleList } from './sales';
 *
 * const dataProvider = supabaseDataProvider({
 *     instanceUrl, apiKey, supabaseClient
 * });
 *
 * const realTimeDataProvider = addRealTimeMethodsBasedOnSupabase({
 *     dataProvider,
 *     supabaseClient,
 * });
 *
 * export const App = () => (
 *     <CoreAdmin dataProvider={realTimeDataProvider}>
 *         <Resource name="sales" list={SaleList} />
 *     </CoreAdmin>
 * );
 * ```
 */
export const addRealTimeMethodsBasedOnSupabase = ({
    dataProvider,
    supabaseClient,
}: AddRealTimeMethodsBasedOnSupabaseParams): DataProvider &
    RealTimeDataProvider => {
    let subscriptions: Subscriptions = [];

    const subscribeToChannel = async (topic: string) => {
        const channels = supabaseClient.getChannels();
        const channel = channels.find(c => c.topic === `realtime:${topic}`);
        if (!channel) {
            const table = getTableFromTopic(topic);
            const schema = 'public';
            const id = getIdFromTopic(topic);
            supabaseClient
                .channel(topic)
                .on(
                    'postgres_changes',
                    {
                        event: '*',
                        schema,
                        table,
                        filter: id != null ? `id=eq.${id}` : undefined,
                    },
                    payload => {
                        subscriptions.forEach(subscription => {
                            if (subscription.topic === topic) {
                                subscription.subscriptionCallback({
                                    topic,
                                    type: getCRUDEventTypeFromSupabaseType(
                                        payload.eventType
                                    ),
                                    payload: {
                                        ids: getIdsFromPayload(payload),
                                        ...payload,
                                    },
                                });
                            }
                        });
                    }
                )
                .subscribe();
            return { data: true };
        } else {
            // The channel already exists
            return { data: true };
        }
    };

    const unsubscribeFromChannel = async (topic: string) => {
        // We unsubscribe from the whole channel only if there is no more subscription for this topic
        const topicSubscriptions = subscriptions.filter(
            subscription => subscription.topic === topic
        );
        if (topicSubscriptions.length > 0) {
            return { data: true };
        }

        const channels = supabaseClient.getChannels();
        const channel = channels.find(c => c.topic === `realtime:${topic}`);
        if (channel) {
            await supabaseClient.removeChannel(channel);
        }
        return { data: true };
    };

    return {
        ...dataProvider,

        subscribe: async (topic, subscriptionCallback) => {
            subscriptions.push({
                topic,
                subscriptionCallback,
            });

            return subscribeToChannel(topic);
        },

        unsubscribe: async (topic, subscriptionCallback) => {
            subscriptions = subscriptions.filter(
                subscription =>
                    subscription.topic !== topic ||
                    subscription.subscriptionCallback !== subscriptionCallback
            );

            return unsubscribeFromChannel(topic);
        },

        publish: (): Promise<any> => {
            // Postgres Changes events should be published by Supabase
            return Promise.reject();
        },
    } as DataProvider & RealTimeDataProvider;
};

export interface AddRealTimeMethodsBasedOnSupabaseParams {
    dataProvider: DataProvider;
    supabaseClient: SupabaseClient;
}

export const getCRUDEventTypeFromSupabaseType = (eventType: string) => {
    switch (eventType) {
        case 'INSERT':
            return 'created';
        case 'UPDATE':
            return 'updated';
        case 'DELETE':
            return 'deleted';
        default:
            return eventType;
    }
};

export const getTableFromTopic = (topic: string) => {
    return topic.split('/')[1];
};

export const getIdFromTopic = (topic: string): Identifier => {
    return topic.split('/')[2];
};

export const getIdsFromPayload = (
    payload: RealtimePostgresChangesPayload<{
        [key: string]: any;
    }>
): Identifier[] => {
    // Even in the case of an event affecting multiple rows, supabase
    // will publish one event per row, with only one id at a time.
    const data = payload.new as {
        id: any;
        [key: string]: any;
    };
    const id = data != null ? data.id : undefined;
    return id != null ? [id] : [];
};
