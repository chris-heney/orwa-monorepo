/* eslint-disable no-console */
import { DataProvider } from 'ra-core';

import { RealTimeDataProvider, Subscriptions } from '../../types';
import { ErrorMissingTopic } from '../ErrorMissingTopic';
import { ErrorMissingEventType } from '../ErrorMissingEventType';

/**
 * Add realTime methods to a dataProvider based on a local (in memory) event bus.
 *
 * The publish/subscribe events happen only in the current browser tab - no
 * event broadcasting to other clients. This is done only for testing purposes.
 *
 * @param {DataProvider} dataProvider The dataProvider to augment
 * @returns {DataProvider}
 *
 * @warning Do not use in production.
 *
 * @example
 *
 * const realTimeDataProvider = addRealTimeMethodsInLocalBrowser(dataProvider);
 *
 * await realTimeDataProvider.subscribe('resource/post', (event) => {
 *    console.log(`Post ${event.payload.id} modified`);
 * });
 *
 * await realTimeDataProvider.publish('resource/post', {
 *     type: 'updated',
 *     payload: { id: 1234 }
 * })
 */
export const addRealTimeMethodsInLocalBrowser = (
    dataProvider: DataProvider
): DataProvider & RealTimeDataProvider => {
    let subscriptions: Subscriptions = [];

    return {
        ...dataProvider,

        subscribe: async (topic, subscriptionCallback): Promise<any> => {
            subscriptions.push({ topic, subscriptionCallback });
            process.env.NODE_ENV !== 'test' &&
                console.debug(`Subscribed to topic ${topic}`);
            return Promise.resolve({ data: null });
        },

        unsubscribe: async (topic, subscriptionCallback): Promise<any> => {
            subscriptions = subscriptions.filter(
                subscription =>
                    subscription.topic !== topic ||
                    subscription.subscriptionCallback !== subscriptionCallback
            );
            process.env.NODE_ENV !== 'test' &&
                console.debug(`Unsubscribed from topic ${topic}`);
            return Promise.resolve({ data: null });
        },

        publish: (topic, event): Promise<any> => {
            if (!topic) {
                return Promise.reject(new ErrorMissingTopic());
            }
            if (!event.type) {
                return Promise.reject(new ErrorMissingEventType());
            }
            process.env.NODE_ENV !== 'test' &&
                console.debug(`Published to topic ${topic}`);

            subscriptions.forEach(subscription => {
                if (topic === subscription.topic) {
                    subscription.subscriptionCallback(event);

                    process.env.NODE_ENV !== 'test' &&
                        console.debug(
                            `Executed listener ${subscription.subscriptionCallback.toString()}`,
                            event
                        );
                }
            });
            return Promise.resolve({ data: null });
        },
    };
};
