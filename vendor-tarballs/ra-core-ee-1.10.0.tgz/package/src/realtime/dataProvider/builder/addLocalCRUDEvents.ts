import { DataProvider } from 'ra-core';

export const addLocalCRUDEvents = (dataProvider: DataProvider) => ({
    ...dataProvider,
    create: (resource, params) => {
        return dataProvider.create(resource, params).then(res => {
            const { id } = res.data;
            const event = {
                type: 'created',
                payload: { ids: [id], data: res.data },
                date: new Date(),
            };
            // delay the publication to ensure it arrives after a storage event
            // synchronizing localStorage with the other tabs
            setTimeout(
                () => dataProvider.publish(`resource/${resource}`, event),
                100
            );
            return res;
        });
    },
    update: (resource, params) => {
        return dataProvider.update(resource, params).then(res => {
            const { id } = params;
            const event = {
                type: 'updated',
                payload: { ids: [id], data: res.data },
                date: new Date(),
            };
            // delay the publication to ensure it arrives after a storage event
            // synchronizing localStorage with the other tabs
            setTimeout(() => {
                dataProvider.publish(`resource/${resource}`, event);
                dataProvider.publish(`resource/${resource}/${id}`, event);
            }, 100);
            return res;
        });
    },
    delete: (resource, params) => {
        return dataProvider.delete(resource, params).then(res => {
            const { id } = params;
            const event = {
                type: 'deleted',
                payload: { ids: [id] },
                date: new Date(),
            };
            // delay the publication to ensure it arrives after a storage event
            // synchronizing localStorage with the other tabs
            setTimeout(() => {
                dataProvider.publish(`resource/${resource}`, event);
                dataProvider.publish(`resource/${resource}/${id}`, event);
            }, 100);
            return res;
        });
    },
});
