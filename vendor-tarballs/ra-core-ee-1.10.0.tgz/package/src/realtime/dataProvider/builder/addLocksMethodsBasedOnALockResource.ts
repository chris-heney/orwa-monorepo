/* eslint-disable no-console */
import { DataProvider, RaRecord } from 'ra-core';
import {
    LocksDataProvider,
    Lock,
    GetLockParams,
    GetLockResult,
    GetLocksParams,
    GetLocksResult,
    LockResult,
    LockParams,
    UnlockParams,
} from '../../types';
import { ErrorLockedBySomeoneElse } from '../ErrorLockedBySomeoneElse';
import { ErrorNoExistingLock } from '../ErrorNoExistingLock';
import { ErrorCannotUnlock } from '../ErrorCannotUnlock';

const LOCKS_RESOURCE_NAME = 'locks';

/**
 * Add locks methods to a dataProvider based on a lock resource which has been declared in the admin.
 *
 * A lock is a semaphore for the unique combinaison (resource, record id). For example "posts/12" is unique.
 *
 * Thanks to the methods provided by this helper, you can list, create and delete the semaphores on a resource.
 *
 * A lock is composed of the following keys:
 * - `id`: a unique identifier. For example "posts/28".
 * - `resource`: the resource to lock. For example "posts".
 * - `recordId`: the record id to lock. For example "28".
 * - `createdAt`: the creation date. For example "2020/09/29 23:00"
 * - `identity`: the lock's owner. For example "Adrien". It could be an auth token.
 *
 * @param {DataProvider} dataProvider The dataProvider to augment
 * @param {string} locksRessourceName The name of the resource used to store locks. Default to "locks".
 * @returns {DataProvider}
 *
 * @example
 *
 * const locksDataProvider = addLocksMethods(dataProvider);
 *
 * await locksDataProvider.lock('post', {
 *     id: 143,
 *     identity: 'adrien' // It could be an authentication token
 * });
 *
 * await locksDataProvider.unlock('post', {
 *     id: 143,
 *     identity: 'adrien'
 * });
 *
 */
export const addLocksMethodsBasedOnALockResource = (
    dataProvider: DataProvider,
    locksRessourceName: string = LOCKS_RESOURCE_NAME,
    publishEvents?: boolean
): DataProvider & LocksDataProvider => {
    return {
        ...dataProvider,

        /**
         * Create a lock on a record
         *
         * @param {string} resource A React-Admin resource name
         * @param {LockParams} params The data used to create a lock
         *
         * @returns A promise resolved with the created lock
         *
         * @example
         *
         * const locksDataProvider = addLocksMethods(dataProvider);
         *
         * await locksDataProvider.lock('post', {
         *     id: 143,
         *     identity: 'adrien' // It could be an authentication token
         * });
         *
         */
        lock: async (
            resource: string,
            params: LockParams
        ): Promise<LockResult> => {
            const { id: recordId, identity, meta } = params;
            const createdAt = new Date();

            const { data: existingLocks, total } = await dataProvider.getList(
                locksRessourceName,
                {
                    pagination: { page: 1, perPage: 1 },
                    sort: { field: 'id', order: 'ASC' },
                    filter: {
                        resource,
                        recordId,
                    },
                }
            );

            if (total != null && total > 0) {
                if (existingLocks[0].identity === identity) {
                    return Promise.resolve({ data: existingLocks[0] });
                } else {
                    return Promise.reject(new ErrorLockedBySomeoneElse());
                }
            }

            const res = await dataProvider.create<Lock & RaRecord>(
                locksRessourceName,
                {
                    data: {
                        identity,
                        resource,
                        recordId,
                        createdAt,
                    },
                    meta,
                }
            );

            if (publishEvents) {
                // wait for 100 milliseconds before publishing events
                await new Promise(resolve =>
                    setTimeout(() => resolve(res), 100)
                );
                await Promise.all([
                    dataProvider.publish(`lock/${resource}/${recordId}`, {
                        type: 'created',
                        payload: { ids: [res.data.id] },
                        date: Date.now(),
                    }),
                    dataProvider.publish(`lock/${resource}`, {
                        type: 'created',
                        payload: { ids: [res.data.id] },
                        date: Date.now(),
                    }),
                ]);
            }
            return res;
        },

        /**
         * Unlock a record
         *
         * @param {string} resource A React-Admin resource name
         * @param {UnlockParams} params The data used to remove a lock
         *
         * @returns A promise resolved with the removed lock
         *
         * @example
         *
         * const locksDataProvider = addLocksMethods(dataProvider);
         *
         * await locksDataProvider.unlock('post', {
         *     id: 143,
         *     identity: 'adrien' // It could be an authentication token
         * });
         *
         */
        unlock: async (
            resource: string,
            params: UnlockParams
        ): Promise<any> => {
            const { id: recordId, identity, meta } = params;

            const { data: locks, total } = await dataProvider.getList(
                locksRessourceName,
                {
                    pagination: { page: 1, perPage: 1 },
                    sort: { field: 'id', order: 'ASC' },
                    filter: {
                        resource,
                        recordId,
                    },
                    meta,
                }
            );

            if (total === 0) {
                return Promise.reject(new ErrorNoExistingLock());
            }

            if (locks[0].identity !== identity) {
                return Promise.reject(new ErrorCannotUnlock());
            }

            const currentLock = locks[0];
            const res = await dataProvider.delete(locksRessourceName, {
                id: currentLock.id,
                previousData: {
                    ...currentLock,
                },
                meta,
            });
            if (publishEvents) {
                // wait for 100 milliseconds before publishing events
                await new Promise(resolve =>
                    setTimeout(() => resolve(res), 100)
                );
                await Promise.all([
                    dataProvider.publish(
                        `lock/${resource}/${currentLock.recordId}`,
                        {
                            type: 'deleted',
                            payload: { ids: [currentLock.recordId] },
                            date: Date.now(),
                        }
                    ),
                    dataProvider.publish(`lock/${resource}`, {
                        type: 'deleted',
                        payload: { ids: [currentLock.recordId] },
                        date: Date.now(),
                    }),
                ]);
            }
            return res;
        },

        /**
         * Get an existing lock on a record
         *
         * @param {string} resource A React-Admin resource name
         * @param {GetLockParams} params The data used to get a lock
         *
         * @returns A promise resolved with the lock
         *
         * @example
         *
         * const locksDataProvider = addLocksMethods(dataProvider);
         *
         * await locksDataProvider.getLock('post', {
         *     id: 143,
         * });
         *
         */
        getLock: async (
            resource: string,
            params: GetLockParams
        ): Promise<GetLockResult> => {
            const { id: recordId, meta } = params;

            const { data: locks, total } = await dataProvider.getList<
                Lock & RaRecord
            >(locksRessourceName, {
                pagination: { page: 1, perPage: 1 },
                sort: { field: 'id', order: 'ASC' },
                filter: {
                    resource,
                    recordId,
                },
                meta,
            });

            if (total === 0) {
                return Promise.resolve({ data: undefined });
            }
            return Promise.resolve({ data: locks[0] });
        },

        /**
         * Get the list of locks for a resource
         *
         * @param {string} resource A React-Admin resource name
         * @param {GetLocksParams} params The optional metadata used to get the locks
         *
         * @returns A promise resolved with the locks
         *
         * @example
         *
         * const locksDataProvider = addLocksMethods(dataProvider);
         *
         * await locksDataProvider.getLocks('post');
         *
         */
        getLocks: async (
            resource: string,
            params: GetLocksParams = {}
        ): Promise<GetLocksResult> => {
            const { meta } = params;
            return dataProvider.getList<Lock & RaRecord>(locksRessourceName, {
                // "pagination" and "sort" field are required by getList
                pagination: { page: 1, perPage: 1000 },
                sort: { field: 'id', order: 'ASC' },
                filter: {
                    resource,
                },
                meta,
            });
        },
    };
};
