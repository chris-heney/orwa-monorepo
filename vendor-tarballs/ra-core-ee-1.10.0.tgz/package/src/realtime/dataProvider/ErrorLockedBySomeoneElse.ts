export class ErrorLockedBySomeoneElse extends Error {
    constructor(message?: string) {
        super(message);
        Object.setPrototypeOf(this, ErrorLockedBySomeoneElse.prototype);
    }
}
