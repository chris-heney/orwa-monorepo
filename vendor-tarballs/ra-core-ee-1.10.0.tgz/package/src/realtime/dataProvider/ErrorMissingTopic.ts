export class ErrorMissingTopic extends Error {
    constructor(message?: string) {
        super(message);
        Object.setPrototypeOf(this, ErrorMissingTopic.prototype);
    }
}
