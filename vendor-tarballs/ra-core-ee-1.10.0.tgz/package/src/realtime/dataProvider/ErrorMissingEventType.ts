export class ErrorMissingEventType extends Error {
    constructor(message?: string) {
        super(message);
        Object.setPrototypeOf(this, ErrorMissingEventType.prototype);
    }
}
