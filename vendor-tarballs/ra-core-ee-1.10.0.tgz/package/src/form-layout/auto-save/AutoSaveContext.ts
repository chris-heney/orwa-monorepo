import * as React from 'react';

export type AutoSaveContextValue = {
    isSaving: boolean;
    lastSaveAt: Date | null;
    error: string | null;
};

export const AutoSaveContext = React.createContext<AutoSaveContextValue | null>(
    null
);

export const AutoSaveContextProvider = AutoSaveContext.Provider;
