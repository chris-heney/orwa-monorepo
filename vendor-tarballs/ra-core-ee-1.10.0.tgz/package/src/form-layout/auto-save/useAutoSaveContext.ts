import * as React from 'react';
import { AutoSaveContext } from './AutoSaveContext';

export const useAutoSaveContext = () => {
    const context = React.useContext(AutoSaveContext);
    if (!context) {
        throw new Error(
            'useAutoSaveContext must be used within a AutoSaveContextProvider'
        );
    }
    return context;
};
