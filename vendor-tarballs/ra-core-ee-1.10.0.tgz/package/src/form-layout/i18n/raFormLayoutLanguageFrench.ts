import { RaFormLayoutTranslationMessages } from './RaFormLayoutTranslationMessages';

export const raFormLayoutLanguageFrench: RaFormLayoutTranslationMessages = {
    'ra-form-layout': {
        action: {
            next: 'Suivant',
            previous: 'Précédent',
            bulk_update:
                'Modifier un(e) %{resource} |||| Modifier les %{resource}',
        },
        inputs: {
            datatable_input: {
                dialog_title:
                    'Sélectionner un(e) %{resource} |||| Sélectionner des %{resource}',
                add_button:
                    'Ajouter %{resource} |||| Ajouter %{smart_count} %{resource}',
            },
        },
        autosave: {
            last_saved_at: 'Modifications enregistrées',
            saving: 'Enregistrement...',
            error: 'Erreur serveur, modifications non enregistrées: %{error}',
        },
        auto_persist_in_store: {
            applied_changes: 'Modifications non sauvegardées appliquées',
        },
        filters: {
            apply_filters: 'Appliquer',
            remove_all_filters: 'Supprimer tous les filtres',
            filters_button_label: 'Filtres',
            source: 'Source',
            operator: 'Opérateur',
            value: 'Valeur',
            operators: {
                q: 'Contient',
                eq: 'Egal à',
                neq: 'Différent de',
                gt: 'Plus grand que',
                lt: 'Plus petit que',
                eq_any: "Egal à n'importe lequel",
                neq_any: "Différent de n'importe lequel",
                boolean: 'Est vrai',
                inc: 'Inclut',
                inc_any: "Inclut n'importe lequel",
                ninc_any: "N'inclut aucun",
            },
        },
        input_selector_form: {
            select_inputs: 'Sélectionnez les champs',
            select_values: 'Sélectionnez les valeurs',
        },
    },
};
