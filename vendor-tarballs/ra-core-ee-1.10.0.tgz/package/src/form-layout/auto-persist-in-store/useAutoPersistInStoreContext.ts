import * as React from 'react';
import {
    AutoPersistInStoreContext,
    AutoPersistInStoreContextValue,
} from './AutoPersistInStoreContext';

export const useAutoPersistInStoreContext =
    (): AutoPersistInStoreContextValue => {
        const context = React.useContext(AutoPersistInStoreContext);
        if (!context) {
            throw new Error(
                'useAutoPersistInStoreContext must be used within a AutoPersistInStoreContextProvider'
            );
        }
        return context;
    };
