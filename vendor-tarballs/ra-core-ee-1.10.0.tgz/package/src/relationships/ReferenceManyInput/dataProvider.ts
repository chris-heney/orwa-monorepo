import fakeRestProvider from 'ra-data-fakerest';
import { DataProvider } from 'ra-core';
import cloneDeep from 'lodash/cloneDeep';

import data from './data';

export const rawDataProvider = () =>
    fakeRestProvider(cloneDeep(data), process.env.NODE_ENV !== 'test');

const addDelay = (
    dataProvider: DataProvider,
    delay = process.env.NODE_ENV === 'test' ? 10 : 300
): DataProvider =>
    new Proxy(dataProvider, {
        get: (target, name) => (resource, params) => {
            if (typeof name === 'symbol' || name === 'then') {
                return;
            }
            return new Promise(resolve =>
                setTimeout(
                    () => resolve(dataProvider[name](resource, params)),
                    delay
                )
            );
        },
    });

export const dataProvider = (
    delay = process.env.NODE_ENV === 'test' ? 10 : 300,
    baseDataProvider = rawDataProvider()
) => addDelay(baseDataProvider, delay);
