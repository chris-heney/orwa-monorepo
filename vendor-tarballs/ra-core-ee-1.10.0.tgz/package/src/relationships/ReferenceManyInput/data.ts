export default {
    teachers: [
        { id: 1, name: 'Felicity Wright' },
        { id: 2, name: 'Finn Ortiz' },
        { id: 3, name: 'Fiona Stanley' },
    ],
    students: [
        { id: 1, first_name: 'Elliott', last_name: 'Thompson', teacher_id: 1 },
        { id: 2, first_name: 'Gracelyn', last_name: 'Clark', teacher_id: 1 },
        { id: 3, first_name: 'Alyssa', last_name: 'Walker', teacher_id: 2 },
        { id: 4, first_name: 'Lia', last_name: 'Johnson', teacher_id: 1 },
        { id: 5, first_name: 'Maverick', last_name: 'Tyler', teacher_id: 1 },
        { id: 6, first_name: 'Sydney', last_name: 'Miller', teacher_id: 2 },
        { id: 7, first_name: 'Aaliyah', last_name: 'Patel', teacher_id: 2 },
        { id: 8, first_name: 'Angelo', last_name: 'Martin', teacher_id: 1 },
        { id: 9, first_name: 'Kaitlyn', last_name: 'Nguyen', teacher_id: 1 },
        { id: 10, first_name: 'Jonathan', last_name: 'Sanders', teacher_id: 2 },
    ],
};
