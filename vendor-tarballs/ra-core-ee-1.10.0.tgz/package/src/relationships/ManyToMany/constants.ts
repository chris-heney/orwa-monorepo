export const ReferenceManyToManyUsingRegexp =
    /^([A-Za-z0-9_-]+),([A-Za-z0-9_-]+)$/;
export const ReferenceManyToManyFieldPrefix = '@@ra-many-to-many/';
