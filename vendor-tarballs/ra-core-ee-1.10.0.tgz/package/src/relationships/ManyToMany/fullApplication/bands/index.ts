import list from './BandList';
import edit from './BandEdit';
import create from './BandCreate';
import show from './BandShow';

export default { list, edit, show, create };
