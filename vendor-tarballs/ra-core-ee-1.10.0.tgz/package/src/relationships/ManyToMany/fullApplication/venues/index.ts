import create from './VenueCreate';
import edit from './VenueEdit';
import list from './VenueList';

export default { list, edit, create };
