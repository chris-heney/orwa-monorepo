import list from './ArtistList';
import edit from './ArtistEdit';
import create from './ArtistCreate';

export default { list, edit, create };
