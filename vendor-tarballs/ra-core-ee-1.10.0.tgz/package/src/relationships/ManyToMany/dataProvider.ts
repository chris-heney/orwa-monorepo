import fakeRestProvider from 'ra-data-fakerest';
import { withLifecycleCallbacks } from 'ra-core';
import cloneDeep from 'lodash/cloneDeep';

import defaultData from './data';

const dataProvider = (
    data: any = cloneDeep(defaultData),
    delay = process.env.NODE_ENV === 'test' ? 10 : 300
) =>
    withLifecycleCallbacks(
        fakeRestProvider(data, process.env.NODE_ENV !== 'test', delay),
        [
            {
                resource: 'performances',
                beforeCreate: params => {
                    return Promise.resolve({
                        ...params,
                        data: { ...params.data, isDeleted: false },
                    });
                },
            },
        ]
    );

export default dataProvider;
