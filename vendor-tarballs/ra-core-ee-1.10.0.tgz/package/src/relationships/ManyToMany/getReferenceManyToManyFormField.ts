import { ReferenceManyToManyFieldPrefix } from './constants';

export const getReferenceManyToManyFormField = ({
    resource,
    through,
    reference,
}: Options): string =>
    `${ReferenceManyToManyFieldPrefix}${resource}/${through}/${reference}`;

interface Options {
    reference: string;
    resource: string;
    through: string;
}
