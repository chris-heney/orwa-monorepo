export const ReferenceOneInputPrefix = '@@ra-one/';
