import { RaRelationshipsTranslationMessages } from './RaRelationshipsTranslationMessages';

export const raRelationshipsLanguageEnglish: RaRelationshipsTranslationMessages =
    {
        'ra-relationships': {
            duallistinput: {
                select: 'Select',
                unselect: 'Unselect',
                availableItems: 'Available items',
                selectedItems: 'Selected items',
            },
            referenceManyInput: {
                fetchError: 'Error fetching references',
                saveError:
                    'Server error: your changes were not completely saved',
            },
            referenceOneInput: {
                fetchError: 'Error fetching references',
                saveError:
                    'Server error: your changes were not completely saved',
            },
            referenceManyToManyInput: {
                saveError:
                    'Server error: your changes were not completely saved',
            },
        },
    };
