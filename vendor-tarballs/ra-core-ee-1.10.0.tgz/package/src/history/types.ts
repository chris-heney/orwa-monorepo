import { Identifier } from 'ra-core';

export interface RecordRevision {
    id: Identifier;
    resource: string;
    recordId: Identifier;
    date: string;
    message: string;
    description?: string;
    authorId?: Identifier;
    data: any;
}
