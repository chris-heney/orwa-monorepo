import * as React from 'react';

import { useRegisterMutationMiddleware, Identifier } from 'ra-core';
import { useAddRevision } from './dataProvider';

export interface UseAddRevisionAfterMutationParams {
    /**
     * A function that returns the revision metadata (message, description, authorId) in a promise
     */
    getMetadata: (params: { resource: string; data: any }) => Promise<{
        message: string;
        description?: string;
        authorId?: Identifier;
    }>;
}

/**
 * Modify the save handler of a create or edit view to add a revision on save
 *
 * Registers a mutation middleware that asks revision metadata before the
 * mutation, and creates a revision with the save data after the mutation.
 */
export const useAddRevisionAfterMutation = () => {
    const [addRevision] = useAddRevision();
    const middleware = async (resource: string, params: any, next: any) => {
        // Extract the revision metadata from the data
        const { [REVISION_FIELD]: revision, ...data } = params.data;
        const { message, description, authorId } = revision;
        const result = await next(resource, { ...params, data });

        await addRevision(resource, {
            recordId: result.data.id,
            data: result.data,
            date: new Date().toISOString(),
            message,
            description,
            authorId,
        });

        return result;
    };
    const memoizedMiddleWare = React.useCallback(middleware, [addRevision]);
    useRegisterMutationMiddleware(memoizedMiddleWare);
};

export const REVISION_FIELD = '@ra-history/revision';
