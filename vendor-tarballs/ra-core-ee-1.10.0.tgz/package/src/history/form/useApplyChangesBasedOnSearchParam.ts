import * as React from 'react';
import { useFormContext } from 'react-hook-form';
import { useSearchParams } from 'react-router-dom';

export const useApplyChangesBasedOnSearchParam = () => {
    const [hasCustomParams, setHasCustomParams] = React.useState(false);
    const {
        setValue,
        formState: { isDirty },
        watch,
    } = useFormContext();
    const [searchParams, setSearchParams] = useSearchParams();
    const changeSearchParam = searchParams.get('_change');

    watch(() => {
        // whenever the user changes a field, we remove the alert
        setHasCustomParams(false);
    });

    React.useEffect(() => {
        if (!changeSearchParam) {
            return;
        }
        try {
            const changedFields = JSON.parse(changeSearchParam);
            Object.entries(changedFields).forEach(([key, value]) => {
                setValue(key, value, { shouldDirty: true });
            });
            setHasCustomParams(true);
            setSearchParams();
        } catch (e) {
            // invalid JSON, do nothing
        }
    }, [changeSearchParam, setSearchParams, setValue]);

    return isDirty && hasCustomParams;
};
