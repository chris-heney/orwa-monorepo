import { Identifier, useDataProvider, useEvent } from 'ra-core';
import {
    useMutation,
    useQueryClient,
    UseMutationResult,
    MutateOptions,
} from '@tanstack/react-query';
import { RecordRevision } from '../types';

export const useAddRevision = (
    resource?: string,
    params?: {
        recordId: Identifier;
        data: any;
        date: string;
        authorId?: Identifier;
        message?: string;
        description?: string;
    },
    options: any = {}
): UseAddRevisionResult<boolean> => {
    const dataProvider = useDataProvider();
    const queryClient = useQueryClient();
    const mutation = useMutation<RecordRevision, any, any>({
        mutationFn: (
            args: { resource: string } & UseAddRevisionParams
        ): Promise<{ data: RecordRevision }> => {
            const {
                resource: callTimeRessource = resource,
                recordId = params?.recordId,
                data = params?.data,
                date = params?.date,
                authorId = params?.authorId,
                message = params?.message,
                description = params?.description,
            } = args;
            return dataProvider.addRevision(callTimeRessource, {
                recordId,
                data,
                date,
                authorId,
                message,
                description,
            });
        },
        onSuccess: (_, callTimeParams) => {
            queryClient.invalidateQueries({
                queryKey: [
                    'getRevisions',
                    callTimeParams?.resource ?? resource,
                    { recordId: callTimeParams?.recordId ?? params?.recordId },
                ],
            });
        },
        ...options,
    });

    const addRevision = async (
        resource,
        params: UseAddRevisionParams,
        calltimeOptions: any = {}
    ) => {
        const { returnPromise = options.returnPromise, ...otherOptions } =
            calltimeOptions;

        return returnPromise
            ? mutation.mutateAsync({ resource, ...params }, otherOptions)
            : mutation.mutate({ resource, ...params }, otherOptions);
    };

    return [useEvent(addRevision), mutation];
};

export interface UseAddRevisionParams {
    recordId: Identifier;
    data: any;
    date: string;
    authorId?: Identifier;
    message?: string;
    description?;
}

export interface UseAddRevisionMutateParams extends UseAddRevisionParams {
    resource: string;
}

export type AddRevisionMutationFunction<
    TReturnPromise extends boolean = boolean,
> = (
    resource?: string,
    params?: Partial<UseAddRevisionParams>,
    options?: MutateOptions<
        { data: RecordRevision },
        unknown,
        Partial<UseAddRevisionMutateParams>,
        unknown
    > & { returnPromise?: TReturnPromise }
) => Promise<TReturnPromise extends true ? { data: RecordRevision } : void>;

export type UseAddRevisionResult<TReturnPromise extends boolean = boolean> = [
    AddRevisionMutationFunction<TReturnPromise>,
    UseMutationResult<
        { data: RecordRevision },
        unknown,
        Partial<UseAddRevisionParams & { resource?: string }>,
        unknown
    >,
];
