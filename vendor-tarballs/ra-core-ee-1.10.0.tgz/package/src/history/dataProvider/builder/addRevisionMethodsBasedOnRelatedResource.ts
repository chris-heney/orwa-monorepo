import { DataProvider } from 'ra-core';
import { singularize } from 'inflection';

export const addRevisionMethodsBasedOnRelatedResource = (
    dataProvider: DataProvider,
    { getRevisionResourceName } = {
        getRevisionResourceName: resource =>
            `${singularize(resource)}_revisions`,
    }
) => ({
    ...dataProvider,
    getRevisions: (resource, { recordId }) =>
        dataProvider
            .getList(getRevisionResourceName(resource), {
                filter: { recordId },
                sort: { field: 'date', order: 'DESC' },
                pagination: { page: 1, perPage: 100 },
            })
            .then(result => ({
                ...result,
                data: result.data.map(revision => ({
                    ...revision,
                    resource,
                })),
            })),
    addRevision: (
        resource,
        { recordId, data, authorId, message, description }
    ) =>
        dataProvider
            .create(getRevisionResourceName(resource), {
                data: {
                    recordId,
                    date: new Date().toISOString(),
                    message,
                    description,
                    authorId,
                    data,
                },
            })
            .then(result => ({
                ...result,
                data: {
                    ...result.data,
                    resource,
                },
            })),
    deleteRevisions: async (resource, { recordId }) => {
        const revisionResourceName = getRevisionResourceName(resource);
        const { data: deletedRevisions } = await dataProvider.getList(
            revisionResourceName,
            {
                filter: { recordId },
                sort: { field: 'date', order: 'DESC' },
                pagination: { page: 1, perPage: 100 },
            }
        );
        return dataProvider.deleteMany(revisionResourceName, {
            ids: deletedRevisions.map(revision => revision.id),
        });
    },
});
