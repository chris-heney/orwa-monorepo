import { DataProvider } from 'ra-core';

export const addRevisionMethodsBasedOnSingleResource = (
    dataProvider: DataProvider,
    { resourceName } = { resourceName: 'revisions' }
) => ({
    ...dataProvider,
    getRevisions: (resource, { recordId }) =>
        dataProvider.getList(resourceName, {
            filter: { resource, recordId },
            sort: { field: 'date', order: 'DESC' },
            pagination: { page: 1, perPage: 100 },
        }),
    addRevision: (
        resource,
        { recordId, data, authorId, message, description }
    ) =>
        dataProvider.create(resourceName, {
            data: {
                resource,
                recordId,
                date: new Date().toISOString(),
                message,
                description,
                authorId,
                data,
            },
        }),
    deleteRevisions: async (resource, { recordId }) => {
        const { data: deletedRevisions } = await dataProvider.getList(
            resourceName,
            {
                filter: { resource, recordId },
                sort: { field: 'date', order: 'DESC' },
                pagination: { page: 1, perPage: 100 },
            }
        );
        return dataProvider.deleteMany(resourceName, {
            ids: deletedRevisions.map(revision => revision.id),
        });
    },
});
