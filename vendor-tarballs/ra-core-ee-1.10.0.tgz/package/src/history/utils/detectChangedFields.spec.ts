import { detectChangedFields } from './detectChangedFields';

describe('detectChangedFields', () => {
    it('should return an empty array if both objects are empty', () => {
        expect(detectChangedFields({}, {})).toEqual([]);
    });
    it('should return an empty array if both objects are equal', () => {
        expect(
            detectChangedFields(
                { foo: 'bar', bar: 'foo' },
                { foo: 'bar', bar: 'foo' }
            )
        ).toEqual([]);
    });
    it('should return the keys of the changed fields', () => {
        expect(
            detectChangedFields(
                { foo: 'bar', bar: 'foo' },
                { foo: 'bar', bar: 'baz' }
            )
        ).toEqual(['bar']);
    });
    it('should return the keys of the changed fields, even if the new value is undefined', () => {
        expect(
            detectChangedFields(
                { foo: 'bar', bar: 'foo' },
                { foo: 'bar', bar: undefined }
            )
        ).toEqual(['bar']);
    });
    it('should return the keys of the changed fields, even if the old value is undefined', () => {
        expect(
            detectChangedFields(
                { foo: 'bar', bar: undefined },
                { foo: 'bar', bar: 'foo' }
            )
        ).toEqual(['bar']);
    });
});
