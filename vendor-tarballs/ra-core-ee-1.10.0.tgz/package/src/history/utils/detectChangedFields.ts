export const detectChangedFields = (object1, object2) => {
    if (!object1 || !object2) {
        return [];
    }
    const keys = new Set([...Object.keys(object1), ...Object.keys(object2)]);
    const changedFields = Array.from(keys).filter(
        key => object1[key] !== object2[key]
    );
    return changedFields;
};
