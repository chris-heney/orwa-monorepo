import { RaHistoryTranslationMessages } from './RaHistoryTranslationMessages';

export const raHistoryLanguageEnglish: RaHistoryTranslationMessages = {
    'ra-history': {
        revisions: {
            name: 'Revision |||| Revisions',
            name_with_count: '1 revision |||| %{smart_count} revisions',
        },
        info: {
            changes_applied:
                'This form has been pre-filled with the changes from a previous revision. You can still modify the data before saving it.',
        },
        on_save: {
            title: 'Save Changes',
            message: 'Revision message',
            description: 'Extended description',
            author: 'Author',
            initial_changes: 'Initial Revision',
            no_changes: 'No changes',
            one_change: 'Changed %{field}',
            many_changes: 'Changed %{fields}',
            missing_revision_message: 'Message is required',
        },
        revision_details: {
            title: 'Revision Details',
            revert: 'Revert to revision %{number}',
            compare: 'Compare with revision %{revision2}',
            compare_with: 'Compare with...',
            revision: 'Revision %{number}',
            revision_selected: 'Revision %{number} (selected)',
        },
    },
};
