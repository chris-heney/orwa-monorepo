import { RaHistoryTranslationMessages } from './RaHistoryTranslationMessages';

export const raHistoryLanguageFrench: RaHistoryTranslationMessages = {
    'ra-history': {
        revisions: {
            name: 'Version |||| Versions',
            name_with_count: '1 version |||| %{smart_count} versions',
        },
        info: {
            changes_applied:
                "Ce formulaire a été pré-rempli avec les modifications d'une version précédente. Vous pouvez toujours modifier les données avant de l'enregistrer.",
        },
        on_save: {
            title: 'Enregistrer les modifications',
            message: 'Message de version',
            description: 'Commentaires',
            author: 'Auteur',
            initial_changes: 'Première version',
            no_changes: 'Pas de modifications',
            one_change: '%{field} modifié(e)',
            many_changes: '%{fields} modifié(e)s',
            missing_revision_message: 'Le message est requis',
        },
        revision_details: {
            title: 'Détails de la version',
            revert: 'Revenir à la version %{number}',
            compare: 'Comparer avec la version %{revision2}',
            compare_with: 'Comparer avec...',
            revision: 'Version %{number}',
            revision_selected: 'Version %{number} (sélectionnée)',
        },
    },
};
