import { raFormLayoutLanguageFrench } from '../form-layout';
import { raRealTimeLanguageFrench } from '../realtime';
import { raRelationshipsLanguageFrench } from '../relationships';
import { raSoftDeleteLanguageFrench } from '../soft-delete';
import { getFrenchTranslations } from './getFrenchTranslations';

describe('getFrenchTranslations', () => {
    it('should merge the translations of each requested module', () => {
        const translations = getFrenchTranslations(
            'ra-realtime',
            'ra-relationships',
            'ra-soft-delete',
            'ra-form-layout'
        );

        expect(translations['ra-realtime']).toEqual(
            raRealTimeLanguageFrench['ra-realtime']
        );
        expect(translations['ra-relationships']).toEqual(
            raRelationshipsLanguageFrench['ra-relationships']
        );
        expect(translations['ra-soft-delete']).toEqual(
            raSoftDeleteLanguageFrench['ra-soft-delete']
        );
        expect(translations['ra-form-layout']).toEqual(
            raFormLayoutLanguageFrench['ra-form-layout']
        );
    });
    it('should not merge the translations of not requested module', () => {
        const translations = getFrenchTranslations(
            'ra-realtime',
            'ra-relationships'
        );

        expect(translations['ra-realtime']).toEqual(
            raRealTimeLanguageFrench['ra-realtime']
        );
        expect(translations['ra-relationships']).toEqual(
            raRelationshipsLanguageFrench['ra-relationships']
        );
        // @ts-expect-error We expect TS to complain about the missing property here
        expect(translations['ra-soft-delete']).toEqual(undefined);
    });
});
