import { RaFormLayoutTranslationMessages } from '../form-layout';
import { RaHistoryTranslationMessages } from '../history';
import { RaRealTimeTranslationMessages } from '../realtime';
import { RaRelationshipsTranslationMessages } from '../relationships';
import { RaSoftDeleteTranslationMessages } from '../soft-delete';

export type Module =
    | 'ra-history'
    | 'ra-realtime'
    | 'ra-relationships'
    | 'ra-soft-delete'
    | 'ra-form-layout';

// Merge two types into a new type. Keys of the second type overrides keys of the first type
// Taken (simplified for our case) from https://github.com/sindresorhus/type-fest/blob/main/source/merge.d.ts#L6
type Merge<Destination, Source> = {
    [Key in keyof Destination as Key extends keyof Source
        ? never
        : Key]: Destination[Key];
} & Source;

// Flatten the type output to improve type hints shown in editors
// Taken from https://github.com/sindresorhus/type-fest/blob/main/source/simplify.d.ts#L58
// eslint-disable-next-line @typescript-eslint/ban-types
type Simplify<T> = { [KeyType in keyof T]: T[KeyType] } & {};

// This type is a reducer like type where:
// - Modules is the array to reduce,
// - Result is the accumulator, which starts as unknown
type MergeModuleTranslations<
    Modules extends Module[],
    MergedTranslations extends any = unknown,
> =
    // We know Modules is an array
    Modules extends [
        // Ask TS to extract and infer the first element of the Modules array, which must be a Module
        infer First extends Module,
        // Ask TS to infer the rest of the Modules array, which must be an array of Modules
        ...infer Rest extends Module[],
    ]
        ? First extends 'ra-history'
            ? // Merge history translations with the result of the recursive call with the rest of the array
              Merge<
                  MergeModuleTranslations<Rest, MergedTranslations>,
                  RaHistoryTranslationMessages
              >
            : First extends 'ra-realtime'
              ? // Merge realtime translations with the result of the recursive call with the rest of the array
                Merge<
                    MergeModuleTranslations<Rest, MergedTranslations>,
                    RaRealTimeTranslationMessages
                >
              : First extends 'ra-relationships'
                ? // Merge relationships translations with the result of the recursive call with the rest of the array
                  Merge<
                      MergeModuleTranslations<Rest, MergedTranslations>,
                      RaRelationshipsTranslationMessages
                  >
                : First extends 'ra-form-layout'
                  ? // Merge form-layout translations with the result of the recursive call with the rest of the array
                    Merge<
                        MergeModuleTranslations<Rest, MergedTranslations>,
                        RaFormLayoutTranslationMessages
                    >
                  : First extends 'ra-soft-delete'
                    ? // Merge soft-delete translations with the result of the recursive call with the rest of the array
                      Merge<
                          MergeModuleTranslations<Rest, MergedTranslations>,
                          RaSoftDeleteTranslationMessages
                      >
                    : MergedTranslations
        : MergedTranslations;

export type RaCoreEETranslations<Modules extends Module[]> = Simplify<
    MergeModuleTranslations<Modules>
>;
