import { raFormLayoutLanguageEnglish } from '../form-layout';
import { raRealTimeLanguageEnglish } from '../realtime';
import { raRelationshipsLanguageEnglish } from '../relationships';
import { raSoftDeleteLanguageEnglish } from '../soft-delete';
import { getEnglishTranslations } from './getEnglishTranslations';

describe('getEnglishTranslations', () => {
    it('should merge the translations of each requested module', () => {
        const translations = getEnglishTranslations(
            'ra-realtime',
            'ra-relationships',
            'ra-soft-delete',
            'ra-form-layout'
        );

        expect(translations['ra-realtime']).toEqual(
            raRealTimeLanguageEnglish['ra-realtime']
        );
        expect(translations['ra-relationships']).toEqual(
            raRelationshipsLanguageEnglish['ra-relationships']
        );
        expect(translations['ra-soft-delete']).toEqual(
            raSoftDeleteLanguageEnglish['ra-soft-delete']
        );
        expect(translations['ra-form-layout']).toEqual(
            raFormLayoutLanguageEnglish['ra-form-layout']
        );
    });
    it('should not merge the translations of not requested module', () => {
        const translations = getEnglishTranslations(
            'ra-realtime',
            'ra-relationships'
        );

        expect(translations['ra-realtime']).toEqual(
            raRealTimeLanguageEnglish['ra-realtime']
        );
        expect(translations['ra-relationships']).toEqual(
            raRelationshipsLanguageEnglish['ra-relationships']
        );
        // @ts-expect-error We expect TS to complain about the missing property here
        expect(translations['ra-soft-delete']).toEqual(undefined);
    });
});
