import { mergeTranslations } from 'ra-core';
import { raHistoryLanguageEnglish } from '../history/i18n/raHistoryLanguageEnglish';
import { raRealTimeLanguageEnglish } from '../realtime/i18n/raRealTimeLanguageEnglish';
import { raRelationshipsLanguageEnglish } from '../relationships/i18n/raRelationshipsLanguageEnglish';
import { raSoftDeleteLanguageEnglish } from '../soft-delete/i18n/raSoftDeleteLanguageEnglish';
import { Module, RaCoreEETranslations } from './types';
import { raFormLayoutLanguageEnglish } from '../form-layout';

export const getEnglishTranslations = <Modules extends Module[]>(
    ...modules: Modules
): RaCoreEETranslations<Modules> => {
    return modules.reduce((acc, module) => {
        switch (module) {
            case 'ra-history':
                return mergeTranslations(acc, raHistoryLanguageEnglish);
            case 'ra-realtime':
                return mergeTranslations(acc, raRealTimeLanguageEnglish);
            case 'ra-relationships':
                return mergeTranslations(acc, raRelationshipsLanguageEnglish);
            case 'ra-soft-delete':
                return mergeTranslations(acc, raSoftDeleteLanguageEnglish);
            case 'ra-form-layout':
                return mergeTranslations(acc, raFormLayoutLanguageEnglish);
            default:
                return acc;
        }
    }, {});
};
