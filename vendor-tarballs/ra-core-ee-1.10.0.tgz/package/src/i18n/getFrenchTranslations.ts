import { mergeTranslations } from 'ra-core';
import { raHistoryLanguageFrench } from '../history/i18n/raHistoryLanguageFrench';
import { raRealTimeLanguageFrench } from '../realtime/i18n/raRealTimeLanguageFrench';
import { raRelationshipsLanguageFrench } from '../relationships/i18n/raRelationshipsLanguageFrench';
import { raSoftDeleteLanguageFrench } from '../soft-delete/i18n/raSoftDeleteLanguageFrench';
import { Module, RaCoreEETranslations } from './types';
import { raFormLayoutLanguageFrench } from '../form-layout';

export const getFrenchTranslations = <Modules extends Module[]>(
    ...modules: Modules
): RaCoreEETranslations<Modules> => {
    return modules.reduce((acc, module) => {
        switch (module) {
            case 'ra-history':
                return mergeTranslations(acc, raHistoryLanguageFrench);
            case 'ra-realtime':
                return mergeTranslations(acc, raRealTimeLanguageFrench);
            case 'ra-relationships':
                return mergeTranslations(acc, raRelationshipsLanguageFrench);
            case 'ra-soft-delete':
                return mergeTranslations(acc, raSoftDeleteLanguageFrench);
            case 'ra-form-layout':
                return mergeTranslations(acc, raFormLayoutLanguageFrench);
            default:
                return acc;
        }
    }, {});
};
