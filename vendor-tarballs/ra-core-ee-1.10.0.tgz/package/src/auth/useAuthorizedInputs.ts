import {
    Children,
    cloneElement,
    isValidElement,
    ReactElement,
    ReactNode,
    useMemo,
} from 'react';
import {
    useCanAccessResources,
    useRecordContext,
    useResourceContext,
} from 'ra-core';
import type {
    UseAuthorizedChildrenProps,
    UseAuthorizedChildrenResult,
} from './useAuthorizedChildren';

export const useAuthorizedInputs = (
    options: UseAuthorizedInputsProps
): UseAuthorizedChildrenResult => {
    const {
        children,
        filterChildren = DefaultFilterChildren,
        getResourceKey = DefaultGetResourceKey,
        showReadOnly = false,
    } = options;
    const resource = useResourceContext(options);
    if (!resource) {
        throw new Error(
            'useAuthorizedInputs used outside of a ResourceContext. You must pass a resource prop.'
        );
    }
    const record = useRecordContext(options);

    const childrenResource = Children.toArray(children)
        .filter(
            child => isValidElement(child) && filterChildren(child, resource)
        )
        .map(child => getResourceKey(child as ReactElement, resource));

    const {
        canAccess: canRead,
        isPending: isCanReadPending,
        error: canReadError,
    } = useCanAccessResources({
        resources: childrenResource,
        action: 'read',
        record,
    });
    const {
        canAccess: canWrite,
        isPending: isCanWritePending,
        error: canWriteError,
    } = useCanAccessResources({
        resources: childrenResource,
        action: 'write',
        record,
    });

    const authorizedChildren = useMemo(() => {
        if (
            isCanReadPending ||
            canRead == null ||
            isCanWritePending ||
            canWrite == null
        ) {
            return [];
        }

        return Children.toArray(children).reduce<ReactNode[]>((acc, child) => {
            if (
                // This will always include children that are not React elements or that don't match the filter (by default, children without a `source` prop)
                !isValidElement(child) ||
                !filterChildren(child, resource) ||
                // Include children for which users have write access
                canWrite[getResourceKey(child, resource)] === true
            ) {
                acc.push(child);
                return acc;
            }

            // For children for which users have read access, set them as read-only
            if (
                showReadOnly &&
                canRead[getResourceKey(child, resource)] === true
            ) {
                acc.push(cloneElement<any>(child, { readOnly: true }));
            }

            return acc;
        }, []);
    }, [
        canRead,
        canWrite,
        children,
        filterChildren,
        getResourceKey,
        isCanReadPending,
        isCanWritePending,
        resource,
        showReadOnly,
    ]);

    return {
        authorizedChildren,
        isPending: isCanReadPending || isCanWritePending,
        error: canReadError || canWriteError,
    };
};

const DefaultFilterChildren = (child: ReactElement<any>) =>
    child.props.source != null;

const DefaultGetResourceKey = (child: ReactElement<any>, resource: string) =>
    `${resource}.${child.props.source}`;

export interface UseAuthorizedInputsProps
    extends Omit<UseAuthorizedChildrenProps, 'action'> {
    showReadOnly?: boolean;
}
