import {
    Children,
    isValidElement,
    ReactElement,
    ReactNode,
    useEffect,
    useState,
} from 'react';
import {
    useCanAccessResources,
    UseCanAccessResourcesResult,
    useRecordContext,
    useResourceContext,
} from 'ra-core';

/**
 * A hook that filters children based on the user's permissions.
 * Note that it requires the children to be valid React elements and having a `source` prop.
 * It will always render children that are not React elements or that do not have a `source` prop.
 * @param options {Object} The hook props
 * @param options.children {ReactNode} The children to filter
 * @param options.action {string} The action to check for. Defaults to 'read'
 * @param options.record {Object} The record to check for. Defaults to the record from RecordContext
 * @param options.resource {string} The resource to check for. Defaults to the resource from ResourceContext
 * @param options.getResourceKey {Function} A function to get the resource key from a child. Defaults to `${resource}.${child.props.source}`
 * @param options.filterChildren {Function} A function to filter children for which to check permissions. Defaults to `child => child.props.source != null`
 * @returns {Object} An array of the children users have access to, the pending state, and the error
 *
 * @example
 * // in src/MyCustomShowLayout.tsx
 * import * as React from 'react';
 * import { useAuthorizedChildren } from '@react-admin/ra-core-ee';
 * import { Stack } from 'react-admin';
 *
 * const MyCustomShowLayout = ({ children }: { children: React.ReactNode }) => {
 *   const { authorizedChildren, isPending, error } = useAuthorizedChildren({
 *     children,
 *   });
 *   if (error) {
 *     return <div>Error</div>;
 *   }
 *   if (isPending) {
 *     return <div>Loading...</div>;
 *   }
 *   return (
 *     <Stack>
 *       {authorizedChildren}
 *     </Stack>
 *   );
 * };
 *
 * // in src/posts/PostShow.tsx
 * import * as React from 'react';
 * import { TextField, Show } from 'react-admin';
 * import { MyCustomShowLayout } from '../MyCustomShowLayout';
 *
 * export const PostShow = (props) => (
 *   <Show>
 *     <MyCustomShowLayout>
 *       <TextField source="title" />
 *       <TextField source="body" />
 *     </MyCustomShowLayout>
 *   </Show>
 */
export const useAuthorizedChildren = (
    options: UseAuthorizedChildrenProps
): UseAuthorizedChildrenResult => {
    const {
        children,
        action = 'read',
        enabled,
        filterChildren = DefaultFilterChildren,
        getResourceKey = DefaultGetResourceKey,
    } = options;
    const resource = useResourceContext(options);
    if (!resource) {
        throw new Error(
            'useAuthorizedChildren used outside of a ResourceContext. You must pass a resource prop.'
        );
    }
    const record = useRecordContext(options);
    const [authorizedChildren, setAuthorizedChildren] = useState<ReactNode[]>(
        []
    );

    const childrenResource = Children.toArray(children)
        .filter(
            child => isValidElement(child) && filterChildren(child, resource)
        )
        .map(child => getResourceKey(child as ReactElement, resource));
    const { canAccess, isPending, error } = useCanAccessResources({
        resources: childrenResource,
        action,
        record,
        enabled,
    });

    useEffect(() => {
        if (enabled === false || isPending || canAccess == null) {
            return;
        }

        const authorizedChildren = Children.toArray(children).filter(child => {
            // This will exclude children that are not React elements or that don't match the filter (by default, children without a `source` prop)
            if (!isValidElement(child) || !filterChildren(child, resource)) {
                return true;
            }

            return canAccess[getResourceKey(child, resource)];
        });
        setAuthorizedChildren(authorizedChildren);
    }, [
        canAccess,
        children,
        enabled,
        filterChildren,
        getResourceKey,
        isPending,
        resource,
    ]);

    return {
        authorizedChildren: enabled !== false ? authorizedChildren : children,
        isPending: enabled !== false ? isPending : false,
        error: enabled !== false ? error : null,
    };
};

export interface UseAuthorizedChildrenProps {
    children: ReactNode;
    enabled?: boolean;
    action?: string;
    record?: any;
    resource?: string;
    getResourceKey?: UseAuthorizedChildrenGetResourceKey;
    filterChildren?: UseAuthorizedChildrenFilterChildren;
}

export type UseAuthorizedChildrenGetResourceKey = (
    child: ReactElement<any>,
    resource: string
) => string;

export type UseAuthorizedChildrenFilterChildren = (
    child: ReactElement<any>,
    resource: string
) => boolean;

export interface UseAuthorizedChildrenResult
    extends Pick<UseCanAccessResourcesResult, 'error' | 'isPending'> {
    authorizedChildren: ReactNode;
}

const DefaultFilterChildren = (child: ReactElement<any>) =>
    child.props.source != null;

const DefaultGetResourceKey = (child: ReactElement<any>, resource: string) =>
    `${resource}.${child.props.source}`;
