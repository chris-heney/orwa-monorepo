import { canAccessWithPermissions } from './canAccessWithPermissions';

describe('canAccessWithPermissions', () => {
    it('should return false if the user has no permissions', () => {
        expect(
            canAccessWithPermissions({
                permissions: [],
                resource: 'foo',
                action: 'bar',
            })
        ).toBe(false);
    });
    it('should return false if at least one permission denies access', () => {
        expect(
            canAccessWithPermissions({
                permissions: [
                    { resource: 'posts', action: 'read' },
                    { resource: 'posts', action: ['write', 'delete'] },
                    { type: 'deny', resource: 'posts', action: 'write' },
                ],
                resource: 'posts',
                action: 'write',
            })
        ).toBe(false);
    });
    it('should return false if the user has permissions only on other resources', () => {
        expect(
            canAccessWithPermissions({
                permissions: [
                    { resource: 'foo1', action: 'bar' },
                    { resource: 'foo2', action: 'bar' },
                ],
                resource: 'foo3',
                action: 'bar',
            })
        ).toBe(false);
    });
    it('should return false if the user has permissions only on other resources using array', () => {
        expect(
            canAccessWithPermissions({
                permissions: [{ resource: ['foo1', 'foo2'], action: 'bar' }],
                resource: 'foo3',
                action: 'bar',
            })
        ).toBe(false);
    });
    it('should return false if the user has the right resource but not the right action permission', () => {
        expect(
            canAccessWithPermissions({
                permissions: [{ resource: 'foo', action: 'baz' }],
                resource: 'foo',
                action: 'bar',
            })
        ).toBe(false);
        expect(
            canAccessWithPermissions({
                permissions: [{ resource: 'foo', action: ['baz'] }],
                resource: 'foo',
                action: 'bar',
            })
        ).toBe(false);
    });
    it('should return true if the user only has access to certain records and no record is passed', () => {
        expect(
            canAccessWithPermissions({
                permissions: [
                    {
                        resource: 'posts',
                        action: 'read',
                        record: { id: 1 },
                    },
                ],
                resource: 'posts',
                action: 'read',
            })
        ).toBe(true);
    });
    it('should return true if the user only has access to all records and a record is passed', () => {
        expect(
            canAccessWithPermissions({
                permissions: [
                    {
                        resource: 'posts',
                        action: 'read',
                    },
                ],
                resource: 'posts',
                action: 'read',
                record: { id: 2, title: 'where am I?' },
            })
        ).toBe(true);
    });
    it('should return false if the user only has access to certain records and another record is passed', () => {
        expect(
            canAccessWithPermissions({
                permissions: [
                    {
                        resource: 'posts',
                        action: 'read',
                        record: { id: 1 },
                    },
                ],
                resource: 'posts',
                action: 'read',
                record: { id: 2, title: 'where am I?' },
            })
        ).toBe(false);
    });
    it('should return true if the user only has access to certain records and a matching record is passed', () => {
        expect(
            canAccessWithPermissions({
                permissions: [
                    {
                        resource: 'posts',
                        action: 'read',
                        record: { id: 1 },
                    },
                ],
                resource: 'posts',
                action: 'read',
                record: { id: 1, title: 'where am I?' },
            })
        ).toBe(true);
    });

    describe('allow permissions', () => {
        it('should return true if the user has wildcard permissions', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: '*', action: '*' }],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(true);
        });
        it('should return true if the user a permission for an array of resources including the requested one', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: ['a', 'b', 'foo'], action: '*' }],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(true);
        });
        it('should return true if the user has the right resource and action permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: 'foo', action: 'read' }],
                    resource: 'foo',
                    action: 'read',
                })
            ).toBe(true);
        });
        it('should return true if the user has the right resource path and action permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: 'foo.bar', action: 'read' }],
                    resource: 'foo.bar',
                    action: 'read',
                })
            ).toBe(true);
        });
        it('should return true if the user has the right resource wildcard and action permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: 'foo.*', action: 'read' }],
                    resource: 'foo.bar',
                    action: 'read',
                })
            ).toBe(true);
        });
        it('should return true if the user has the wildcard resource and the right action permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: '*', action: 'bar' }],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(true);
        });
        it('should return true if the user has the right action for the right resource', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: 'foo', action: ['bar', 'baz'] }],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(true);
        });
        it('should return true if the user has the wildcard action for the right resource', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: 'foo', action: '*' }],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(true);
        });
        it('should return true if at least one permission grants access', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { resource: 'posts', action: 'read' },
                        { resource: 'posts', action: ['write', 'delete'] },
                    ],
                    resource: 'posts',
                    action: 'write',
                })
            ).toBe(true);
        });
        it('should return true if the user has access to all records', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ resource: 'posts', action: 'read' }],
                    resource: 'posts',
                    action: 'read',
                    record: { id: '1', title: 'hello, world' },
                })
            ).toBe(true);
        });
        it('should return true if the user has access to the right record', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        {
                            resource: 'posts',
                            action: 'read',
                            record: { id: 1 },
                        },
                    ],
                    resource: 'posts',
                    action: 'read',
                    record: { id: 1, title: 'hello, world' },
                })
            ).toBe(true);
        });
        it('should return true if the user has access to something for the resource and action is *', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        {
                            resource: 'posts',
                            action: 'read',
                        },
                    ],
                    resource: 'posts',
                    action: '*',
                })
            ).toBe(true);
        });
        it('should return true if the user has access to something for the resource and action not defined', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        {
                            resource: 'posts',
                            action: 'read',
                        },
                    ],
                    resource: 'posts',
                })
            ).toBe(true);
        });
    });

    describe('deny permissions', () => {
        it('should return false if the user has wildcard deny permissions', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [{ type: 'deny', resource: '*', action: '*' }],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(false);
        });
        it('should return false if the user has the right resource and action deny permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { type: 'deny', resource: 'foo', action: 'read' },
                    ],
                    resource: 'foo',
                    action: 'read',
                })
            ).toBe(false);
        });
        it('should return false if the user has the right resource path and action deny permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { type: 'deny', resource: 'foo.bar', action: 'read' },
                    ],
                    resource: 'foo.bar',
                    action: 'read',
                })
            ).toBe(false);
        });
        it('should return false if the user has the right resource wildcard and action deny permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { type: 'deny', resource: 'foo.*', action: 'read' },
                    ],
                    resource: 'foo.bar',
                    action: 'read',
                })
            ).toBe(false);
        });
        it('should return false if the user has the wildcard resource and the right action deny permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { type: 'deny', resource: '*', action: 'bar' },
                    ],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(false);
        });
        it('should return false if the user has the right action for the right resource deny permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        {
                            type: 'deny',
                            resource: 'foo',
                            action: ['bar', 'baz'],
                        },
                    ],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(false);
        });
        it('should return false if the user has the wildcard action for the right resource in deny permission', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { type: 'deny', resource: 'foo', action: '*' },
                    ],
                    resource: 'foo',
                    action: 'bar',
                })
            ).toBe(false);
        });
        it('should return false if the user has denied access to all records', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        { type: 'deny', resource: 'posts', action: 'read' },
                    ],
                    resource: 'posts',
                    action: 'read',
                    record: { id: '1', title: 'hello, world' },
                })
            ).toBe(false);
        });
        it('should return false if the user has denied access to the right record', () => {
            expect(
                canAccessWithPermissions({
                    permissions: [
                        {
                            type: 'deny',
                            resource: 'posts',
                            action: 'read',
                            record: { id: 1 },
                        },
                    ],
                    resource: 'posts',
                    action: 'read',
                    record: { id: 1, title: 'hello, world' },
                })
            ).toBe(false);
        });
    });
});
