import { RaSoftDeleteTranslationMessages } from './RaSoftDeleteTranslationMessages';

export const raSoftDeleteLanguageEnglish: RaSoftDeleteTranslationMessages = {
    'ra-soft-delete': {
        message: {
            bulk_soft_delete_title: 'Archive |||| Archive %{smart_count} items',
            bulk_soft_delete_content:
                'Are you sure you want to archive this item? |||| Are you sure you want to archive these %{smart_count} items?',
            bulk_delete_permanently_title:
                'Delete permanently |||| Delete %{smart_count} items permanently',
            bulk_delete_permanently_content:
                'Are you sure you want to delete this item permanently? |||| Are you sure you want to delete these %{smart_count} items permanently?',
            bulk_restore_title: 'Restore |||| Restore %{smart_count} items',
            bulk_restore_content:
                'Are you sure you want to restore this item? |||| Are you sure you want to restore these %{smart_count} items?',
            soft_delete_title: 'Archive %{name} %{recordRepresentation}',
            soft_delete_content:
                'Are you sure you want to archive this %{name}?',
            delete_permanently_title:
                'Delete %{name} %{recordRepresentation} permanently',
            delete_permanently_content:
                'Are you sure you want to delete this %{name} permanently?',
            restore_title: 'Restore %{name} %{recordRepresentation}',
            restore_content: 'Are you sure you want to restore this %{name}?',
        },
        action: {
            restore: 'Restore',
            soft_delete: 'Archive',
            delete_permanently: 'Delete permanently',
        },
        notification: {
            restored: 'Element restored |||| %{smart_count} elements restored',
            soft_deleted:
                'Element archived |||| %{smart_count} elements archived',
            deleted_permanently:
                'Element deleted permanently |||| %{smart_count} elements deleted permanently',
        },
        deleted_records_list: {
            menu: 'Archives',
            deleted_at: 'Deleted at',
            resource: 'Resource',
            title: 'Archives',
            resource_title: 'Archived %{resource}',
            empty: 'The list is empty.',
            no_filtered_results: 'No results found with the current filters.',
        },
    },
};
