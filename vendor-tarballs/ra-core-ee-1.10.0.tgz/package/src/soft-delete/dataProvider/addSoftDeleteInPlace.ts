import {
    DataProvider,
    GetListParams,
    GetListResult,
    GetManyParams,
    GetOneParams,
    Identifier,
    QueryFunctionContext,
    RaRecord,
    SortPayload,
} from 'ra-core';
import get from 'lodash/get';
import {
    DeletedRecordType,
    GetListDeletedParams,
    HardDeleteManyParams,
    HardDeleteParams,
    RestoreManyParams,
    RestoreOneParams,
    SoftDeleteManyParams,
    SoftDeleteParams,
} from './types';

type ResourcePage<ResourceType extends string = string> = {
    resource: ResourceType;
    currentPage: number;
    currentRecordIndex: number;
    result: GetListResult;
};

const defaultSort: SortPayload = {
    field: 'deleted_at',
    order: 'DESC',
};

/**
 * Add soft delete based on a `deleted_at` field in the same resource.
 * All soft deleted records will be stored in the same resource, with a not null `deleted_at`.
 */
export function addSoftDeleteInPlace<ResourceType extends string = string>(
    dataProvider: DataProvider<ResourceType>,
    resourcesWithSoftDelete?: Record<
        string,
        {
            deletedAtFieldName?: string;
            deletedByFieldName?: string;
        }
    >
) {
    const getDeletedAtFieldName = (resource: ResourceType) =>
        resourcesWithSoftDelete?.[resource]?.deletedAtFieldName ?? 'deleted_at';

    const getDeletedByFieldName = (resource: ResourceType) =>
        resourcesWithSoftDelete?.[resource]?.deletedByFieldName ?? 'deleted_by';

    const getSoftDeletableResources = () =>
        Object.keys(resourcesWithSoftDelete ?? {}) as ResourceType[];

    const buildDeletedRecordId = <DeletedDataType extends RaRecord = any>(
        resource: ResourceType,
        record: DeletedDataType
    ) => `${resource}:${record.id}`;

    const buildDeletedRecord = <DeletedDataType extends RaRecord = any>(
        resource: ResourceType,
        record: DeletedDataType
    ): DeletedRecordType<DeletedDataType> => {
        return {
            id: buildDeletedRecordId(resource, record),
            resource,
            deleted_at: record?.[getDeletedAtFieldName(resource)],
            deleted_by: record?.[getDeletedByFieldName(resource)],
            data: record,
        };
    };

    const parseDeletedRecordId = (id: Identifier) => {
        if (typeof id !== 'string') {
            throw new Error(
                `Invalid deleted record id: ${id}. Expected a string in the format "resource:id".`
            );
        }

        const indexOfSeparator = id.lastIndexOf(':');
        if (indexOfSeparator === -1) {
            throw new Error(
                `Invalid deleted record id: ${id}. Expected a string in the format "resource:id".`
            );
        }

        const resource = id.slice(0, indexOfSeparator) as ResourceType;
        const recordId = id.slice(indexOfSeparator + 1);
        return {
            resource,
            recordId,
        };
    };

    return {
        ...dataProvider,

        getOne: async <RecordType extends RaRecord = any>(
            resource: ResourceType,
            params: GetOneParams<RecordType> & QueryFunctionContext
        ) => {
            const result = await dataProvider.getOne<RecordType>(
                resource,
                params
            );

            if (!getSoftDeletableResources().includes(resource)) {
                return result;
            }

            if (get(result.data, getDeletedAtFieldName(resource)) != null) {
                throw new Error('Cannot get a soft-deleted record.');
            }

            return result;
        },

        getMany: async <RecordType extends RaRecord = any>(
            resource: ResourceType,
            params: GetManyParams<RecordType> & QueryFunctionContext
        ) => {
            const result = await dataProvider.getMany<RecordType>(
                resource,
                params
            );

            if (!getSoftDeletableResources().includes(resource)) {
                return result;
            }

            if (
                result.data.some(
                    record =>
                        get(record, getDeletedAtFieldName(resource)) != null
                )
            ) {
                throw new Error('Cannot get a soft-deleted record.');
            }

            return result;
        },

        getList: <RecordType extends RaRecord = any>(
            resource: ResourceType,
            params: GetListParams & QueryFunctionContext
        ) => {
            if (!getSoftDeletableResources().includes(resource)) {
                return dataProvider.getList<RecordType>(resource, params);
            }

            return dataProvider.getList<RecordType>(resource, {
                ...params,
                filter: {
                    ...params.filter,
                    [getDeletedAtFieldName(resource) + '_eq']: null,
                },
            });
        },

        softDelete: async <DeletedDataType extends RaRecord = any>(
            resource: ResourceType,
            {
                authorId,
                previousData,
                ...params
            }: SoftDeleteParams<DeletedDataType>
        ) => {
            if (!getSoftDeletableResources().includes(resource)) {
                throw new Error(
                    `Resource "${resource}" does not support soft delete.`
                );
            }

            let recordToDelete: DeletedDataType | undefined = previousData;
            if (!recordToDelete) {
                recordToDelete = (await dataProvider.getOne(resource, params))
                    .data;
            }

            const result = await dataProvider.update(resource, {
                ...params,
                data: {
                    [getDeletedAtFieldName(resource)]: new Date().toISOString(),
                    [getDeletedByFieldName(resource)]: authorId,
                },
                previousData: recordToDelete,
            });

            return {
                ...result,
                data: recordToDelete,
                deletedRecord: buildDeletedRecord(resource, result.data),
            };
        },

        softDeleteMany: async <DeletedDataType extends RaRecord = any>(
            resource: ResourceType,
            { authorId, ...params }: SoftDeleteManyParams<DeletedDataType>
        ) => {
            if (!getSoftDeletableResources().includes(resource)) {
                throw new Error(
                    `Resource "${resource}" does not support soft delete.`
                );
            }

            const result = await dataProvider.updateMany(resource, {
                ...params,
                data: {
                    [getDeletedAtFieldName(resource)]: new Date().toISOString(),
                    [getDeletedByFieldName(resource)]: authorId,
                },
            });

            const deletedRecordsResult = await dataProvider.getMany(
                resource,
                params
            );

            return {
                ...result,
                data: deletedRecordsResult.data.map(record => record.id),
                deletedRecords: deletedRecordsResult.data.map(record =>
                    buildDeletedRecord(resource, record)
                ),
            };
        },

        getOneDeleted: async params => {
            const { resource, recordId } = parseDeletedRecordId(params.id);

            const result = await dataProvider.getOne(resource, {
                ...params,
                id: recordId,
            });

            return {
                ...result,
                data: buildDeletedRecord(resource, result.data),
            };
        },

        getListDeleted: async (params: GetListDeletedParams) => {
            // Prepare IDs filters.
            const idsByResource: Partial<Record<ResourceType, Identifier[]>> =
                {};
            if (params.filter?.id) {
                let ids: string[] = [];
                if (Array.isArray(params.filter?.id)) {
                    ids = params.filter.id;
                } else if (typeof params.filter?.id === 'string') {
                    ids = [params.filter.id];
                }

                for (const id of ids) {
                    const { resource, recordId } = parseDeletedRecordId(id);
                    if (!idsByResource[resource]) {
                        idsByResource[resource] = [];
                    }
                    idsByResource[resource].push(recordId);
                }
            }

            /**
             * The parameters of getListDeleted are not exactly the same as getList.
             * The `filter` parameter can contain a `resource` field to filter by the resource of the deleted record,
             * or filters on `deleted_at` and `deleted_by`.
             * Filters on the actual record data are prefixed with "data.".
             * Sort fields need the same transformation.
             */
            const transformParams = (
                params: GetListParams,
                resource: ResourceType
            ): GetListParams => {
                // Transform filter fields: remove "data." prefix and query the configured columns for `deleted_at` and `deleted_by`.
                const filters = Object.fromEntries(
                    Object.entries(params.filter ?? {})
                        .map(([filterField, filterValue]) => {
                            if (filterField.startsWith('data.')) {
                                return [filterField.substring(5), filterValue];
                            }

                            if (filterField === 'resource') {
                                return [];
                            }

                            const deletedAtMatch =
                                filterField.match(/^deleted_at(.*)/);
                            if (deletedAtMatch) {
                                return [
                                    getDeletedAtFieldName(resource) +
                                        deletedAtMatch[1],
                                    filterValue,
                                ];
                            }

                            const deletedByMatch =
                                filterField.match(/^deleted_by(.*)/);
                            if (deletedByMatch) {
                                return [
                                    getDeletedByFieldName(resource) +
                                        deletedByMatch[1],
                                    filterValue,
                                ];
                            }

                            return [filterField, filterValue];
                        })
                        .filter(entry => entry?.[1] !== undefined)
                );

                // Always only get records with deleted_at not null.
                filters[getDeletedByFieldName(resource) + '_neq'] = null;

                // Add filter from id of deleted record.
                if (idsByResource[resource]) {
                    filters['id'] = !filters['id']
                        ? idsByResource[resource]
                        : [...filters['id'], ...idsByResource[resource]];
                }

                // Transform sort fields: remove "data." prefix and query the configured columns for `deleted_at` and `deleted_by`.
                const sort = params.sort ?? { ...defaultSort };
                if (sort.field.startsWith('data.')) {
                    sort.field = sort.field.substring(5);
                }
                if (sort.field === 'deleted_at') {
                    sort.field = getDeletedAtFieldName(resource);
                }
                if (sort.field === 'deleted_by') {
                    sort.field = getDeletedByFieldName(resource);
                }

                return {
                    ...params,
                    sort: sort,
                    filter: filters,
                };
            };

            if (typeof params.filter?.resource === 'string') {
                const result = await dataProvider.getList(
                    params.filter.resource,
                    transformParams(params, params.filter.resource)
                );
                return {
                    ...result,
                    data: result.data.map(record =>
                        buildDeletedRecord(params.filter.resource, record)
                    ),
                };
            }

            // Get all soft deletable resources and filter them.
            let resources = getSoftDeletableResources();
            if (Array.isArray(params.filter?.resource))
                resources = resources.filter(resource =>
                    params.filter.resource.includes(resource)
                );

            // Retrieve results using sort and paginate params.

            const targetPage = params.pagination?.page ?? 1;
            const perPage = params.pagination?.perPage ?? 20;

            const retrieveResourcePage = async (
                resource: ResourceType,
                params: GetListParams
            ): Promise<ResourcePage<ResourceType>> => {
                return {
                    resource,
                    currentPage: params?.pagination?.page ?? 1,
                    currentRecordIndex: 0,
                    result: await dataProvider.getList(
                        resource,
                        transformParams(params, resource)
                    ),
                };
            };
            const retrieveResourceNextPage = async (
                resourcePage: ResourcePage<ResourceType>,
                params: GetListParams
            ): Promise<ResourcePage<ResourceType>> => {
                const nextPage = resourcePage.currentPage + 1;
                return retrieveResourcePage(resourcePage.resource, {
                    ...params,
                    pagination: {
                        page: nextPage,
                        perPage: perPage,
                    },
                });
            };

            // Initial resources pages.
            const resourcesPages: Record<
                ResourceType,
                ResourcePage<ResourceType>
            > = Object.fromEntries(
                await Promise.all(
                    resources.map(async resource => [
                        resource,
                        await retrieveResourcePage(resource, {
                            ...params,
                            pagination: {
                                page: 1,
                                perPage: perPage,
                            },
                        }),
                    ])
                )
            );

            const { field, order } = params.sort ?? defaultSort;
            const compare = (a, b) => {
                if (!field) return 0;

                if (order === 'ASC') {
                    if (get(a, field) < get(b, field)) return -1;
                    if (get(a, field) > get(b, field)) return 1;
                    return 0;
                }

                // DESC order
                if (get(a, field) < get(b, field)) return 1;
                if (get(a, field) > get(b, field)) return -1;
                return 0;
            };

            // Build all pages up to the target page.
            // We must do that as there is no way to know exactly which pages to query
            // for each resource without building all the previous pages.
            const pages: DeletedRecordType[][] = [[]];
            const pageIsFull = (page: number) =>
                (pages?.[page - 1]?.length ?? 0) >= perPage;

            let currentPage = 1;
            while (!pageIsFull(targetPage)) {
                // Find the next record to add to the current page.
                let nextRecord:
                    | { resource: ResourceType; record: DeletedRecordType }
                    | undefined;
                for (const resource in resourcesPages) {
                    const resourceRecord =
                        resourcesPages[resource].result.data[
                            resourcesPages[resource].currentRecordIndex
                        ];

                    if (!resourceRecord) continue;

                    const resourceDeletedRecord = buildDeletedRecord(
                        resource,
                        resourceRecord
                    );

                    if (
                        !nextRecord ||
                        compare(resourceDeletedRecord, nextRecord?.record) < 0
                    ) {
                        nextRecord = {
                            resource,
                            record: resourceDeletedRecord,
                        };
                    }
                }

                // No more records to add.
                if (!nextRecord?.record) {
                    break;
                }

                pages[currentPage - 1].push(nextRecord.record);
                resourcesPages[nextRecord.resource].currentRecordIndex++;

                if (
                    resourcesPages[nextRecord.resource].result.data.length <=
                    resourcesPages[nextRecord.resource].currentRecordIndex
                ) {
                    resourcesPages[nextRecord.resource] =
                        await retrieveResourceNextPage(
                            resourcesPages[nextRecord.resource],
                            params
                        );
                }

                if (pageIsFull(currentPage)) {
                    currentPage++;
                    pages.push([]);
                }
            }

            return {
                data: pages?.[targetPage - 1] ?? [],
                pageInfo: {
                    hasNextPage: Object.values(resourcesPages).some(
                        (resourcePage: ResourcePage) =>
                            resourcePage.result.pageInfo
                                ? resourcePage.result.pageInfo.hasNextPage
                                : (resourcePage.result.data?.length ?? 0) -
                                      resourcePage.currentRecordIndex >
                                  0
                    ),
                    hasPreviousPage: Object.values(resourcesPages).some(
                        (resourcePage: ResourcePage) =>
                            resourcePage.result.pageInfo
                                ? resourcePage.result.pageInfo.hasPreviousPage
                                : targetPage > 1
                    ),
                },
            };
        },

        restoreOne: async <DeletedDataType extends RaRecord = any>({
            id,
            ...params
        }: RestoreOneParams<DeletedDataType>) => {
            const { resource, recordId } = parseDeletedRecordId(id);

            const recordToRestore = (
                await dataProvider.getOne(resource, {
                    ...params,
                    id: recordId,
                })
            ).data;

            const result = await dataProvider.update(resource, {
                ...params,
                id: recordId,
                data: {
                    [getDeletedAtFieldName(resource)]: null,
                    [getDeletedByFieldName(resource)]: null,
                },
                previousData: recordToRestore,
            });

            return {
                ...result,
                data: buildDeletedRecord(resource, recordToRestore),
            };
        },

        restoreMany: async <DeletedDataType extends RaRecord = any>({
            ids,
            ...params
        }: RestoreManyParams<DeletedDataType>) => {
            const idsByResource = ids.reduce(
                (ids, id) => {
                    const { resource, recordId } = parseDeletedRecordId(id);
                    if (!ids[resource]) {
                        ids[resource] = [];
                    }
                    ids[resource].push(recordId);
                    return ids;
                },
                {} as Record<ResourceType, Identifier[]>
            );

            // Retrieve all records to restore.
            const recordsToRestore = (
                await Promise.all(
                    Object.entries(idsByResource).map(
                        async ([resource, recordIds]: [
                            ResourceType,
                            Identifier[],
                        ]) =>
                            (
                                await dataProvider.getMany(resource, {
                                    ...params,
                                    ids: recordIds,
                                })
                            ).data.map(record =>
                                buildDeletedRecord(resource, record)
                            )
                    )
                )
            ).flat();

            await Promise.all(
                Object.entries(idsByResource).map(
                    ([resource, recordIds]: [ResourceType, Identifier[]]) =>
                        dataProvider.updateMany(resource, {
                            ...params,
                            ids: recordIds,
                            data: {
                                [getDeletedAtFieldName(resource)]: null,
                                [getDeletedByFieldName(resource)]: null,
                            },
                        })
                )
            );

            return {
                data: recordsToRestore,
            };
        },

        hardDelete: async <DeletedDataType extends RaRecord = any>(
            params: HardDeleteParams<DeletedDataType>
        ) => {
            const { resource, recordId } = parseDeletedRecordId(params.id);

            const result = await dataProvider.delete(resource, {
                ...params,
                id: recordId,
            });

            return {
                ...result,
                data: buildDeletedRecord(resource, result.data),
            };
        },

        hardDeleteMany: async <DeletedDataType extends RaRecord = any>({
            ids,
            ...params
        }: HardDeleteManyParams<DeletedDataType>) => {
            const idsByResource = ids.reduce(
                (ids, id) => {
                    const { resource, recordId } = parseDeletedRecordId(id);
                    if (!ids[resource]) {
                        ids[resource] = [];
                    }
                    ids[resource].push(recordId);
                    return ids;
                },
                {} as Record<ResourceType, Identifier[]>
            );

            const results = await Promise.all(
                Object.entries(idsByResource).map(
                    ([resource, recordIds]: [ResourceType, Identifier[]]) =>
                        dataProvider.deleteMany(resource, {
                            ...params,
                            ids: recordIds,
                        })
                )
            );

            return {
                data: ids,
                meta: results.map(result => result.meta),
            };
        },
    };
}
