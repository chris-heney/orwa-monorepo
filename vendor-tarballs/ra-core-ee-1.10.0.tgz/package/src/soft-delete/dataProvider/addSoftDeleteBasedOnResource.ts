import { DataProvider, RaRecord } from 'ra-core';
import {
    DeletedRecordType,
    HardDeleteManyParams,
    HardDeleteParams,
    RestoreManyParams,
    RestoreOneParams,
    SoftDeleteDataProvider,
    SoftDeleteManyParams,
    SoftDeleteParams,
} from './types';
import { defaultCreateMany } from './createMany';

/**
 * Add soft delete based on a resource for a provided data provider.
 * All soft deleted records will be stored in the configured resource (`deleted_records` by default).
 */
export function addSoftDeleteBasedOnResource<
    ResourceType extends string = string,
>(
    dataProvider: DataProvider<ResourceType>,
    {
        deletedRecordsResourceName,
    }: {
        deletedRecordsResourceName: ResourceType | string;
    } = { deletedRecordsResourceName: 'deleted_records' }
): SoftDeleteDataProvider<ResourceType> {
    return {
        ...dataProvider,

        softDelete: async <DeletedDataType extends RaRecord = any>(
            resource: ResourceType,
            {
                authorId,
                previousData,
                ...params
            }: SoftDeleteParams<DeletedDataType>
        ) => {
            let recordToDelete: DeletedDataType | undefined = previousData;
            if (!recordToDelete) {
                recordToDelete = (await dataProvider.getOne(resource, params))
                    .data;
            }

            const { data: newDeletedRecord } = await dataProvider.create<
                DeletedRecordType<DeletedDataType>
            >(deletedRecordsResourceName as any, {
                data: {
                    resource: resource,
                    deleted_at: new Date().toISOString(),
                    deleted_by: authorId,
                    data: recordToDelete,
                },
            });

            const result = await dataProvider.delete(resource, {
                id: recordToDelete.id,
                previousData: recordToDelete,
            });

            return {
                ...result,
                deletedRecord: newDeletedRecord,
            };
        },
        softDeleteMany: async <DeletedDataType extends RaRecord = any>(
            resource: ResourceType,
            { authorId, ...params }: SoftDeleteManyParams<DeletedDataType>
        ) => {
            const { data: recordsToDelete } = await dataProvider.getMany(
                resource,
                params
            );

            const { data: deletedRecords } = await (
                dataProvider.createMany ?? defaultCreateMany(dataProvider)
            )(deletedRecordsResourceName as any, {
                data: recordsToDelete.map(recordToDelete => ({
                    resource: resource,
                    deleted_at: new Date().toISOString(),
                    deleted_by: authorId,
                    data: recordToDelete,
                })),
            });

            const result = await dataProvider.deleteMany(resource, {
                ids: recordsToDelete.map(recordToDelete => recordToDelete.id),
            });

            return {
                ...result,
                deletedRecords,
            };
        },

        getOneDeleted: async params => {
            return await dataProvider.getOne(
                deletedRecordsResourceName as any,
                params
            );
        },
        getListDeleted: async params => {
            return await dataProvider.getList(
                deletedRecordsResourceName as any,
                params
            );
        },

        restoreOne: async <DeletedDataType extends RaRecord = any>({
            id,
            ...params
        }: RestoreOneParams<DeletedDataType>) => {
            const recordToRestore = await dataProvider.getOne<
                DeletedRecordType<DeletedDataType>
            >(deletedRecordsResourceName as any, { id });

            const result = await dataProvider.create<DeletedDataType>(
                recordToRestore.data.resource as any,
                {
                    ...params,
                    data: recordToRestore.data.data,
                }
            );

            await dataProvider.delete(deletedRecordsResourceName as any, {
                id,
            });

            return {
                ...result,
                data: {
                    ...recordToRestore.data,
                    data: result.data,
                },
            };
        },
        restoreMany: async <DeletedDataType extends RaRecord = any>({
            ids,
            ...params
        }: RestoreManyParams<DeletedDataType>) => {
            const recordsToRestore = await dataProvider.getMany<
                DeletedRecordType<DeletedDataType>
            >(deletedRecordsResourceName as any, { ids });

            // Create a batch for create many for every resource type in the records to restore.
            const createManyBatches: Partial<
                Record<ResourceType, DeletedDataType[]>
            > = {};
            for (const recordToRestore of recordsToRestore.data) {
                if (!createManyBatches[recordToRestore.resource])
                    createManyBatches[recordToRestore.resource] = [];
                createManyBatches[recordToRestore.resource].push(
                    recordToRestore.data
                );
            }

            // Restore all records by batch using createMany.
            const createMany =
                dataProvider.createMany ?? defaultCreateMany(dataProvider);
            await Promise.all(
                Object.entries(createManyBatches).map(([resourceType, data]) =>
                    createMany(resourceType, {
                        ...params,
                        data,
                    })
                )
            );

            await dataProvider.deleteMany(deletedRecordsResourceName as any, {
                ids,
            });

            return {
                data: recordsToRestore.data,
            };
        },

        hardDelete: async <DeletedDataType extends RaRecord = any>(
            params: HardDeleteParams<DeletedDataType>
        ) => dataProvider.delete(deletedRecordsResourceName as any, params),

        hardDeleteMany: async <DeletedDataType extends RaRecord = any>(
            params: HardDeleteManyParams<DeletedDataType>
        ) => dataProvider.deleteMany(deletedRecordsResourceName as any, params),
    };
}
