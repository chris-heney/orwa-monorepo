import { DataProvider, RaRecord } from 'ra-core';
import { CreateManyParams, CreateManyResult } from './types';

/**
 * Make a default createMany using the provided data provider.
 * @param dataProvider
 */
export const defaultCreateMany = <ResourceType extends string = string>(
    dataProvider: DataProvider<ResourceType>
) => {
    return async <RecordType extends RaRecord = any>(
        resource: ResourceType,
        { data, ...params }: CreateManyParams<RecordType>
    ) => {
        const results = await Promise.all(
            data.map(newRecord =>
                dataProvider.create(resource, { data: newRecord, ...params })
            )
        );

        return {
            data: results.map(newRecordResult => newRecordResult.data),
            meta: results.map(newRecordResult => newRecordResult.meta),
        } as CreateManyResult<RecordType>;
    };
};
