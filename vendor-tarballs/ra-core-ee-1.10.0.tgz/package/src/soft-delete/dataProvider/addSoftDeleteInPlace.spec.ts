import { testDataProvider } from 'ra-core';
import fakeRestDataProvider from 'ra-data-fakerest';

import { addSoftDeleteInPlace } from './addSoftDeleteInPlace';

describe('addSoftDeleteInPlace', () => {
    it('should soft delete the provided record', async () => {
        const deletionDate = new Date().toISOString();
        const getOneMock = jest.fn((_resource, _params) =>
            Promise.resolve({
                data: {
                    id: 1,
                    deleted_at: null,
                    deleted_by: null,
                },
            } as any)
        );
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                getOne: getOneMock,
                update: jest.fn(() =>
                    Promise.resolve({
                        data: {
                            id: 1,
                            deleted_at: deletionDate,
                            deleted_by: 'johndoe',
                        },
                    } as any)
                ),
            }),
            { posts: {} }
        );

        expect(
            await dataProvider.softDelete('posts', {
                id: 1,
                authorId: 'johndoe',
            })
        ).toMatchObject({
            data: {
                id: 1,
                deleted_at: null,
                deleted_by: null,
            },
            deletedRecord: {
                id: 'posts:1',
                resource: 'posts',
                deleted_at: deletionDate,
                deleted_by: 'johndoe',
                data: {
                    id: 1,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            },
        });

        expect(getOneMock).toHaveBeenCalledTimes(1);
        expect(getOneMock.mock.calls[0][0]).toBe('posts');
        expect(getOneMock.mock.calls[0][1]).toMatchObject({
            id: 1,
        });

        expect(dataProvider.update).toHaveBeenCalledTimes(1);
        expect((dataProvider.update as jest.Mock).mock.calls[0][0]).toBe(
            'posts'
        );
        expect(
            (dataProvider.update as jest.Mock).mock.calls[0][1]
        ).toMatchObject({
            id: 1,
            data: {
                deleted_by: 'johndoe',
            },
        });
    });

    it('should soft delete many provided records', async () => {
        const deletionDate = new Date().toISOString();
        const getManyMock = jest.fn((_resource, params) =>
            Promise.resolve({
                data: params.ids.map((id: any) => ({
                    id,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                })),
            } as any)
        );
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                getMany: getManyMock,
                updateMany: jest.fn((_resource, { ids }) =>
                    Promise.resolve({ data: ids } as any)
                ),
            }),
            { posts: {} }
        );

        expect(
            await dataProvider.softDeleteMany('posts', {
                ids: [1, 5, 12],
                authorId: 'johndoe',
            })
        ).toMatchObject({
            data: [1, 5, 12],
            deletedRecords: [
                {
                    id: 'posts:1',
                    resource: 'posts',
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                    data: {
                        id: 1,
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    },
                },
                {
                    id: 'posts:5',
                    resource: 'posts',
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                    data: {
                        id: 5,
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    },
                },
                {
                    id: 'posts:12',
                    resource: 'posts',
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                    data: {
                        id: 12,
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    },
                },
            ],
        });

        expect(dataProvider.updateMany).toHaveBeenCalledTimes(1);
        expect((dataProvider.updateMany as jest.Mock).mock.calls[0][0]).toBe(
            'posts'
        );
        expect(
            (dataProvider.updateMany as jest.Mock).mock.calls[0][1]
        ).toMatchObject({
            ids: [1, 5, 12],
            data: {
                deleted_by: 'johndoe',
            },
        });

        expect(getManyMock).toHaveBeenCalledTimes(1);
        expect(getManyMock.mock.calls[0][0]).toBe('posts');
        expect(getManyMock.mock.calls[0][1]).toStrictEqual({
            ids: [1, 5, 12],
        });
    });

    it('should get one deleted record', async () => {
        const deletionDate = new Date().toISOString();
        const getOneMock = jest.fn((_resource, _params) =>
            Promise.resolve({
                data: {
                    id: 1,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            } as any)
        );
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                getOne: getOneMock,
            })
        );

        expect(
            await dataProvider.getOneDeleted({ id: 'posts:1' })
        ).toStrictEqual({
            data: {
                id: 'posts:1',
                resource: 'posts',
                deleted_at: deletionDate,
                deleted_by: 'johndoe',

                data: {
                    id: 1,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            },
        });

        expect(getOneMock).toHaveBeenCalledTimes(1);
        expect(getOneMock.mock.calls[0][0]).toBe('posts');
        expect(getOneMock.mock.calls[0][1]).toStrictEqual({
            id: '1',
        });
    });

    it('should restore one deleted record', async () => {
        const deletionDate = new Date().toISOString();
        const getOneMock = jest.fn((_resource, _params) =>
            Promise.resolve({
                data: {
                    id: 1,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            } as any)
        );
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                getOne: getOneMock,
                update: jest.fn(() =>
                    Promise.resolve({
                        data: {
                            id: 1,
                            deleted_at: null,
                            deleted_by: null,
                        },
                    } as any)
                ),
            })
        );

        expect(
            await dataProvider.restoreOne({
                id: 'posts:1',
            })
        ).toStrictEqual({
            data: {
                id: 'posts:1',
                resource: 'posts',
                data: {
                    id: 1,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
                deleted_at: deletionDate,
                deleted_by: 'johndoe',
            },
        });

        expect(dataProvider.update).toHaveBeenCalledTimes(1);
        expect((dataProvider.update as jest.Mock).mock.calls[0][0]).toBe(
            'posts'
        );
        expect(
            (dataProvider.update as jest.Mock).mock.calls[0][1]
        ).toStrictEqual({
            id: '1',
            data: {
                deleted_at: null,
                deleted_by: null,
            },
            previousData: {
                id: 1,
                deleted_at: deletionDate,
                deleted_by: 'johndoe',
            },
        });

        expect(getOneMock).toHaveBeenCalledTimes(1);
        expect(getOneMock.mock.calls[0][0]).toBe('posts');
        expect(getOneMock.mock.calls[0][1]).toStrictEqual({
            id: '1',
        });
    });

    it('should restore many deleted records', async () => {
        const deletionDate = new Date().toISOString();
        const getManyMock = jest.fn((_resource, params) =>
            Promise.resolve({
                data: params.ids.map((id: any) => ({
                    id: typeof id === 'string' ? Number.parseInt(id) : id,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                })),
            } as any)
        );
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                getMany: getManyMock,
                updateMany: jest.fn((_resource, { ids }) =>
                    Promise.resolve({ data: ids } as any)
                ),
            })
        );

        expect(
            await dataProvider.restoreMany({
                ids: ['posts:1', 'comments:5'],
            })
        ).toStrictEqual({
            data: [
                {
                    id: 'posts:1',
                    resource: 'posts',
                    data: {
                        id: 1,
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    },
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
                {
                    id: 'comments:5',
                    resource: 'comments',
                    data: {
                        id: 5,
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    },
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            ],
        });

        expect(getManyMock).toHaveBeenCalledTimes(2);
        expect(getManyMock.mock.calls[0][0]).toBe('posts');
        expect(getManyMock.mock.calls[0][1]).toStrictEqual({
            ids: ['1'],
        });
        expect(getManyMock.mock.calls[1][0]).toBe('comments');
        expect(getManyMock.mock.calls[1][1]).toStrictEqual({
            ids: ['5'],
        });

        expect(dataProvider.updateMany).toHaveBeenCalledTimes(2);
        expect((dataProvider.updateMany as jest.Mock).mock.calls[0][0]).toBe(
            'posts'
        );
        expect(
            (dataProvider.updateMany as jest.Mock).mock.calls[0][1]
        ).toStrictEqual({
            ids: ['1'],
            data: {
                deleted_at: null,
                deleted_by: null,
            },
        });
        expect((dataProvider.updateMany as jest.Mock).mock.calls[1][0]).toBe(
            'comments'
        );
        expect(
            (dataProvider.updateMany as jest.Mock).mock.calls[1][1]
        ).toStrictEqual({
            ids: ['5'],
            data: {
                deleted_at: null,
                deleted_by: null,
            },
        });
    });

    it('should hard delete one deleted record', async () => {
        const deletionDate = new Date().toISOString();
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                delete: jest.fn((_resource, { id }) =>
                    Promise.resolve({
                        data: {
                            id:
                                typeof id === 'string'
                                    ? Number.parseInt(id)
                                    : id,
                            deleted_at: deletionDate,
                            deleted_by: 'johndoe',
                        },
                    } as any)
                ),
            })
        );

        expect(
            await dataProvider.hardDelete({
                id: 'posts:1',
            })
        ).toStrictEqual({
            data: {
                id: 'posts:1',
                resource: 'posts',
                deleted_at: deletionDate,
                deleted_by: 'johndoe',
                data: {
                    id: 1,
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            },
        });

        expect(dataProvider.delete).toHaveBeenCalledTimes(1);
        expect((dataProvider.delete as jest.Mock).mock.calls[0][0]).toBe(
            'posts'
        );
        expect(
            (dataProvider.delete as jest.Mock).mock.calls[0][1]
        ).toStrictEqual({
            id: '1',
        });
    });

    it('should hard delete many deleted records', async () => {
        const dataProvider = addSoftDeleteInPlace(
            testDataProvider({
                deleteMany: jest.fn((_resource, { ids }) =>
                    Promise.resolve({
                        data: ids,
                    } as any)
                ),
            })
        );

        expect(
            await dataProvider.hardDeleteMany({
                ids: ['posts:1', 'comments:5', 'posts:12'],
            })
        ).toStrictEqual({
            data: ['posts:1', 'comments:5', 'posts:12'],
            meta: [undefined, undefined],
        });

        expect(dataProvider.deleteMany).toHaveBeenCalledTimes(2);
        expect((dataProvider.deleteMany as jest.Mock).mock.calls[0][0]).toBe(
            'posts'
        );
        expect(
            (dataProvider.deleteMany as jest.Mock).mock.calls[0][1]
        ).toStrictEqual({
            ids: ['1', '12'],
        });
        expect((dataProvider.deleteMany as jest.Mock).mock.calls[1][0]).toBe(
            'comments'
        );
        expect(
            (dataProvider.deleteMany as jest.Mock).mock.calls[1][1]
        ).toStrictEqual({
            ids: ['5'],
        });
    });

    it('should get a list of deleted records after deletions', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(84)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                comments: [...Array(452)].map((_, index) => ({
                    id: index + 1,
                    text: 'A comment',
                    deletion_date: null,
                    deletion_user: null,
                })),
            }),
            {
                posts: {},
                comments: {
                    deletedAtFieldName: 'deletion_date',
                    deletedByFieldName: 'deletion_user',
                },
            }
        );

        // By default, nothing is deleted.
        expect(
            await dataProvider.getListDeleted({
                pagination: {
                    page: 1,
                    perPage: 20,
                },
            })
        ).toStrictEqual({
            data: [],
            pageInfo: {
                hasNextPage: false,
                hasPreviousPage: false,
            },
        });

        await dataProvider.softDelete('posts', { id: 3, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 66,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('posts', { id: 7, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 5,
            authorId: 'johndoe',
        });

        expect(
            await dataProvider.getListDeleted({
                pagination: {
                    page: 1,
                    perPage: 20,
                },
            })
        ).toMatchObject({
            data: [
                {
                    id: 'comments:5',
                    deleted_by: 'johndoe',
                },
                {
                    id: 'posts:7',
                    deleted_by: 'johndoe',
                },
                {
                    id: 'comments:66',
                    deleted_by: 'johndoe',
                },
                {
                    id: 'posts:3',
                    deleted_by: 'johndoe',
                },
            ],
            pageInfo: {
                hasNextPage: false,
                hasPreviousPage: false,
            },
        });

        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDeleteMany('comments', {
            ids: [101, 102, 103, 104, 105, 106, 107],
            authorId: 'johndoe',
        });

        expect(
            await dataProvider.getListDeleted({
                pagination: {
                    page: 1,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [
                { id: 'comments:101' },
                { id: 'comments:102' },
                { id: 'comments:103' },
                { id: 'comments:104' },
                { id: 'comments:105' },
            ],
            pageInfo: {
                hasNextPage: true,
                hasPreviousPage: false,
            },
        });
        expect(
            await dataProvider.getListDeleted({
                pagination: {
                    page: 2,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [
                { id: 'comments:106' },
                { id: 'comments:107' },
                { id: 'comments:5' },
                { id: 'posts:7' },
                { id: 'comments:66' },
            ],
            pageInfo: {
                hasNextPage: true,
                hasPreviousPage: true,
            },
        });
        expect(
            await dataProvider.getListDeleted({
                pagination: {
                    page: 3,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [{ id: 'posts:3' }],
            pageInfo: {
                hasNextPage: false,
                hasPreviousPage: true,
            },
        });
    });

    it('should get a list of deleted records with custom sort parameter', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(84)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                comments: [...Array(452)].map((_, index) => ({
                    id: index + 1,
                    text: 'A comment',
                    deletion_date: null,
                    deletion_user: null,
                })),
            }),
            {
                posts: {},
                comments: {
                    deletedAtFieldName: 'deletion_date',
                    deletedByFieldName: 'deletion_user',
                },
            }
        );

        await dataProvider.softDelete('posts', { id: 3, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 66,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('posts', { id: 7, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 5,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDeleteMany('comments', {
            ids: [101, 102, 103, 104, 105, 106, 107],
            authorId: 'johndoe',
        });

        expect(
            await dataProvider.getListDeleted({
                sort: {
                    field: 'id',
                    order: 'ASC',
                },
                pagination: {
                    page: 1,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [
                { id: 'comments:5' },
                { id: 'comments:66' },
                { id: 'comments:101' },
                { id: 'comments:102' },
                { id: 'comments:103' },
            ],
            pageInfo: {
                hasNextPage: true,
                hasPreviousPage: false,
            },
        });

        expect(
            await dataProvider.getListDeleted({
                sort: {
                    field: 'id',
                    order: 'ASC',
                },
                pagination: {
                    page: 2,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [
                { id: 'comments:104' },
                { id: 'comments:105' },
                { id: 'comments:106' },
                { id: 'comments:107' },
                { id: 'posts:3' },
            ],
            pageInfo: {
                hasNextPage: true,
                hasPreviousPage: true,
            },
        });

        expect(
            await dataProvider.getListDeleted({
                sort: {
                    field: 'id',
                    order: 'ASC',
                },
                pagination: {
                    page: 3,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [{ id: 'posts:7' }],
            pageInfo: {
                hasNextPage: false,
                hasPreviousPage: true,
            },
        });
    });

    it('should get a list of deleted records with custom filters', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(84)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                comments: [...Array(452)].map((_, index) => ({
                    id: index + 1,
                    text: 'A comment',
                    deletion_date: null,
                    deletion_user: null,
                })),
            }),
            {
                posts: {},
                comments: {
                    deletedAtFieldName: 'deletion_date',
                    deletedByFieldName: 'deletion_user',
                },
            }
        );

        await dataProvider.softDelete('posts', { id: 3, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 66,
            authorId: 'johndoe',
        });
        const before7Deletion = new Date().toISOString();
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('posts', { id: 7, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 5,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        const beforeBatchDeletion = new Date().toISOString();
        await dataProvider.softDeleteMany('comments', {
            ids: [101, 102, 103, 104, 105, 106, 107],
            authorId: 'johndoe',
        });

        expect(
            await dataProvider.getListDeleted({
                filter: {
                    resource: 'posts',
                },
                pagination: {
                    page: 1,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [{ id: 'posts:7' }, { id: 'posts:3' }],
            total: 2,
        });

        expect(
            await dataProvider.getListDeleted({
                filter: {
                    resource: 'posts',
                    deleted_at_gte: before7Deletion,
                },
                pagination: {
                    page: 1,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [{ id: 'posts:7' }],
            total: 1,
        });

        expect(
            await dataProvider.getListDeleted({
                filter: {
                    resource: ['comments', 'posts'],
                    deleted_at_gte: beforeBatchDeletion,
                },
                pagination: {
                    page: 1,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [
                { id: 'comments:101' },
                { id: 'comments:102' },
                { id: 'comments:103' },
                { id: 'comments:104' },
                { id: 'comments:105' },
            ],
            pageInfo: {
                hasNextPage: true,
                hasPreviousPage: false,
            },
        });
        expect(
            await dataProvider.getListDeleted({
                filter: {
                    resource: ['comments', 'posts'],
                    deleted_at_gte: beforeBatchDeletion,
                },
                pagination: {
                    page: 2,
                    perPage: 5,
                },
            })
        ).toMatchObject({
            data: [{ id: 'comments:106' }, { id: 'comments:107' }],
            pageInfo: {
                hasNextPage: false,
                hasPreviousPage: true,
            },
        });
    });

    it("shouldn't allow to getOne a deleted record", async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(84)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                comments: [...Array(452)].map((_, index) => ({
                    id: index + 1,
                    text: 'A comment',
                    deletion_date: null,
                    deletion_user: null,
                })),
            }),
            {
                posts: {},
                comments: {
                    deletedAtFieldName: 'deletion_date',
                    deletedByFieldName: 'deletion_user',
                },
            }
        );

        await dataProvider.softDelete('posts', { id: 3, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 66,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('posts', { id: 7, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 5,
            authorId: 'johndoe',
        });

        await expect(
            dataProvider.getOne('comments', { id: 5 })
        ).rejects.toThrow(new Error('Cannot get a soft-deleted record.'));
        await expect(
            dataProvider.getOne('comments', { id: 6 })
        ).resolves.toMatchObject({
            data: {
                id: 6,
                deletion_date: null,
                deletion_user: null,
            },
        });
    });

    it("shouldn't allow to getMany deleted records", async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(84)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                comments: [...Array(452)].map((_, index) => ({
                    id: index + 1,
                    text: 'A comment',
                    deletion_date: null,
                    deletion_user: null,
                })),
            }),
            {
                posts: {},
                comments: {
                    deletedAtFieldName: 'deletion_date',
                    deletedByFieldName: 'deletion_user',
                },
            }
        );

        await dataProvider.softDelete('posts', { id: 3, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 66,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('posts', { id: 7, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 5,
            authorId: 'johndoe',
        });

        await expect(
            dataProvider.getMany('comments', { ids: [67, 68] })
        ).resolves.toMatchObject({
            data: [{ id: 67 }, { id: 68 }],
        });
        await expect(
            dataProvider.getMany('comments', { ids: [66, 67, 68] })
        ).rejects.toThrow(new Error('Cannot get a soft-deleted record.'));
    });

    it('should exclude deleted records from getList result', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(84)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                comments: [...Array(452)].map((_, index) => ({
                    id: index + 1,
                    text: 'A comment',
                    deletion_date: null,
                    deletion_user: null,
                })),
            }),
            {
                posts: {},
                comments: {
                    deletedAtFieldName: 'deletion_date',
                    deletedByFieldName: 'deletion_user',
                },
            }
        );

        await dataProvider.softDelete('posts', { id: 3, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 66,
            authorId: 'johndoe',
        });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('posts', { id: 7, authorId: 'johndoe' });
        await new Promise(resolve => setTimeout(resolve, 10));
        await dataProvider.softDelete('comments', {
            id: 5,
            authorId: 'johndoe',
        });

        const testData = (
            await dataProvider.getList('comments', {
                pagination: {
                    page: 1,
                    perPage: 20,
                },
                sort: {
                    field: 'id',
                    order: 'DESC',
                },
                filter: { id: [66, 67, 68, 5] },
            })
        )?.data;
        expect(testData).toHaveLength(2);
        expect(testData[0].id).toBe(68);
        expect(testData[1].id).toBe(67);

        expect(
            (
                await dataProvider.getList('comments', {
                    pagination: {
                        page: 1,
                        perPage: 20,
                    },
                    sort: {
                        field: 'id',
                        order: 'DESC',
                    },
                    filter: { deleted_at_neq: null },
                })
            )?.data
        ).toHaveLength(0);
    });

    it('should not throw when calling getOne on a resource which does not support soft delete', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                categories: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    name: `category ${index + 1}`,
                })),
            }),
            {
                posts: {},
            }
        );

        await expect(
            dataProvider.getOne('categories', { id: 5 })
        ).resolves.toMatchObject({
            data: {
                id: 5,
                name: expect.any(String),
            },
        });
    });

    it('should not throw when calling getMany on a resource which does not support soft delete', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                categories: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    name: `category ${index + 1}`,
                })),
            }),
            {
                posts: {},
            }
        );

        await expect(
            dataProvider.getMany('categories', { ids: [5, 6, 7] })
        ).resolves.toMatchObject({
            data: [
                { id: 5, name: expect.any(String) },
                { id: 6, name: expect.any(String) },
                { id: 7, name: expect.any(String) },
            ],
        });
    });

    it("shouldn't exclude deleted records from getList result on resource which does not support soft delete", async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: null,
                    deleted_by: null,
                })),
                categories: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    name: `category ${index + 1}`,
                    deleted_at: index === 4 ? new Date().toISOString() : null,
                })),
            }),
            {
                posts: {},
            }
        );

        const result = await dataProvider.getList('categories', {
            pagination: {
                page: 1,
                perPage: 20,
            },
            sort: {
                field: 'id',
                order: 'ASC',
            },
            filter: {},
        });

        // Should return all records including the one with deleted_at set
        expect(result.data).toHaveLength(10);
        expect(result.data.find(record => record.id === 5)).toMatchObject({
            id: 5,
            deleted_at: expect.any(String),
        });
    });

    it('should allow to getOne a record with deleted_at equal to undefined', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: undefined,
                    deleted_by: undefined,
                })),
            }),
            {
                posts: {},
            }
        );

        await expect(
            dataProvider.getOne('posts', { id: 5 })
        ).resolves.toMatchObject({
            data: {
                id: 5,
                title: expect.any(String),
                deleted_at: undefined,
                deleted_by: undefined,
            },
        });
    });

    it('should allow to getMany records with deleted_at equal to undefined', async () => {
        const dataProvider = addSoftDeleteInPlace(
            fakeRestDataProvider({
                posts: [...Array(10)].map((_, index) => ({
                    id: index + 1,
                    title: `title ${index + 1}`,
                    deleted_at: undefined,
                    deleted_by: undefined,
                })),
            }),
            {
                posts: {},
            }
        );

        await expect(
            dataProvider.getMany('posts', { ids: [5, 6, 7] })
        ).resolves.toMatchObject({
            data: [
                { id: 5, title: expect.any(String), deleted_at: undefined },
                { id: 6, title: expect.any(String), deleted_at: undefined },
                { id: 7, title: expect.any(String), deleted_at: undefined },
            ],
        });
    });
});
