import { testDataProvider as raTestDataProvider } from 'ra-core';

import { SoftDeleteDataProvider } from './types';

/**
 * A dataProvider meant to be used in tests only. You can override any of its methods by passing a partial dataProvider.
 *
 * @example
 * const dataProvider = testDataProvider({
 *    getOne: async () => ({ data: { id: 123, title: 'foo' }})
 * })
 */

const defaultTestDataProvider: SoftDeleteDataProvider = {
    ...raTestDataProvider(),

    softDelete: async () => {
        throw new Error('softDelete not implemented');
    },
    softDeleteMany: async () => {
        throw new Error('softDeleteMany not implemented');
    },
    getOneDeleted: async () => {
        throw new Error('getOneDeleted not implemented');
    },
    getListDeleted: async () => {
        throw new Error('getListDeleted not implemented');
    },
    restoreOne: async () => {
        throw new Error('restoreOne not implemented');
    },
    restoreMany: async () => {
        throw new Error('restoreMany not implemented');
    },
    hardDelete: async () => {
        throw new Error('hardDelete not implemented');
    },
    hardDeleteMany: async () => {
        throw new Error('hardDeleteMany not implemented');
    },
};
export const testDataProvider = (
    overrides?: Partial<SoftDeleteDataProvider>
): SoftDeleteDataProvider => ({
    ...defaultTestDataProvider,
    ...overrides,
});
