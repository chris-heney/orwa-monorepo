import { DataProvider } from 'ra-core';
import { addSoftDeleteBasedOnResource } from './addSoftDeleteBasedOnResource';
import { DeletedRecordType } from './types';

describe('addSoftDeleteBasedOnResource', () => {
    it('should soft delete the provided record', async () => {
        const mockDataProvider = {
            getOne: jest.fn((_resource, params) =>
                Promise.resolve({ data: { id: params.id } })
            ),
            getMany: jest.fn(() => Promise.resolve({ data: undefined })),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn((_resource, { data }) => Promise.resolve({ data })),
            delete: jest.fn((_resource, { previousData }) =>
                Promise.resolve({ data: previousData })
            ),
            deleteMany: jest.fn(() => Promise.resolve({ data: undefined })),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.softDelete('posts', {
                id: 1,
                authorId: 'johndoe',
            })
        ).toMatchObject({
            data: {
                id: 1,
            },
            deletedRecord: {
                resource: 'posts',
                deleted_by: 'johndoe',
                data: {
                    id: 1,
                },
            },
        });

        expect(mockDataProvider.getOne).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.getOne.mock.calls[0][0]).toBe('posts');
        expect(mockDataProvider.getOne.mock.calls[0][1]).toStrictEqual({
            id: 1,
        });

        expect(mockDataProvider.create).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.create.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.create.mock.calls[0][1]).toMatchObject({
            data: {
                resource: 'posts',
                deleted_by: 'johndoe',
                data: {
                    id: 1,
                },
            },
        });

        expect(mockDataProvider.delete).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.delete.mock.calls[0][0]).toBe('posts');
        expect(mockDataProvider.delete.mock.calls[0][1]).toStrictEqual({
            id: 1,
            previousData: { id: 1 },
        });
    });

    it('should soft delete many provided records', async () => {
        const mockDataProvider = {
            getOne: jest.fn(() => Promise.resolve({ data: undefined })),
            getMany: jest.fn((_resource, params) =>
                Promise.resolve({ data: params.ids.map(id => ({ id })) })
            ),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn((_resource, { data }) => Promise.resolve({ data })),
            delete: jest.fn(() => Promise.resolve({ data: undefined })),
            deleteMany: jest.fn((_resource, _params) =>
                Promise.resolve({ data: undefined })
            ),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.softDeleteMany('posts', {
                ids: [1, 5, 12],
                authorId: 'johndoe',
            })
        ).toMatchObject({
            deletedRecords: [
                {
                    resource: 'posts',
                    deleted_by: 'johndoe',
                    data: {
                        id: 1,
                    },
                },
                {
                    resource: 'posts',
                    deleted_by: 'johndoe',
                    data: {
                        id: 5,
                    },
                },
                {
                    resource: 'posts',
                    deleted_by: 'johndoe',
                    data: {
                        id: 12,
                    },
                },
            ],
        });

        expect(mockDataProvider.getMany).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.getMany.mock.calls[0][0]).toBe('posts');
        expect(mockDataProvider.getMany.mock.calls[0][1]).toStrictEqual({
            ids: [1, 5, 12],
        });

        expect(mockDataProvider.create).toHaveBeenCalledTimes(3);
        expect(mockDataProvider.create.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.create.mock.calls[0][1]).toMatchObject({
            data: {
                resource: 'posts',
                deleted_by: 'johndoe',
                data: {
                    id: 1,
                },
            },
        });
        expect(mockDataProvider.create.mock.calls[1][1]).toMatchObject({
            data: {
                resource: 'posts',
                deleted_by: 'johndoe',
                data: {
                    id: 5,
                },
            },
        });
        expect(mockDataProvider.create.mock.calls[2][1]).toMatchObject({
            data: {
                resource: 'posts',
                deleted_by: 'johndoe',
                data: {
                    id: 12,
                },
            },
        });

        expect(mockDataProvider.deleteMany).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.deleteMany.mock.calls[0][0]).toBe('posts');
        expect(mockDataProvider.deleteMany.mock.calls[0][1]).toStrictEqual({
            ids: [1, 5, 12],
        });
    });

    it('should get one deleted record', async () => {
        const deletionDate = new Date().toISOString();
        const mockDataProvider = {
            getOne: jest.fn((_resource, params) =>
                Promise.resolve({
                    data: {
                        id: params.id,
                        resource: 'posts',
                        data: {
                            id: 1,
                        },
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    } as DeletedRecordType,
                })
            ),
            getMany: jest.fn(() => Promise.resolve({ data: undefined })),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn(() => Promise.resolve({ data: undefined })),
            delete: jest.fn(() => Promise.resolve({ data: undefined })),
            deleteMany: jest.fn(() => Promise.resolve({ data: undefined })),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(await dataProvider.getOneDeleted({ id: 1 })).toStrictEqual({
            data: {
                id: 1,
                resource: 'posts',
                deleted_at: deletionDate,
                deleted_by: 'johndoe',

                data: {
                    id: 1,
                },
            },
        });

        expect(mockDataProvider.getOne).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.getOne.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.getOne.mock.calls[0][1]).toStrictEqual({
            id: 1,
        });
    });

    it('should get a list of deleted records', async () => {
        const deletionDate = new Date().toISOString();
        const mockDataProvider = {
            getOne: jest.fn(() => Promise.resolve({ data: undefined })),
            getMany: jest.fn(() => Promise.resolve({ data: undefined })),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn((_resource, _params) =>
                Promise.resolve({
                    data: [
                        {
                            id: 1,
                            resource: 'posts',
                            data: { id: 1 },
                            deleted_at: deletionDate,
                            deleted_by: 'johndoe',
                        } as DeletedRecordType,
                        {
                            id: 2,
                            resource: 'comments',
                            data: { id: 5 },
                            deleted_at: deletionDate,
                            deleted_by: 'johndoe',
                        } as DeletedRecordType,
                    ],
                })
            ),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn(() => Promise.resolve({ data: undefined })),
            delete: jest.fn(() => Promise.resolve({ data: undefined })),
            deleteMany: jest.fn(() => Promise.resolve({ data: undefined })),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.getListDeleted({
                sort: {
                    field: 'id',
                    order: 'ASC',
                },
            })
        ).toStrictEqual({
            data: [
                {
                    id: 1,
                    resource: 'posts',
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',

                    data: {
                        id: 1,
                    },
                },
                {
                    id: 2,
                    resource: 'comments',
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',

                    data: {
                        id: 5,
                    },
                },
            ],
        });

        expect(mockDataProvider.getList).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.getList.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.getList.mock.calls[0][1]).toStrictEqual({
            sort: { field: 'id', order: 'ASC' },
        });

        await dataProvider.getListDeleted({
            sort: {
                field: 'id',
                order: 'ASC',
            },
            filter: {
                data: {
                    id: 5,
                },
            },
        });
        expect(mockDataProvider.getList.mock.calls[1][1]).toStrictEqual({
            sort: { field: 'id', order: 'ASC' },
            filter: {
                data: {
                    id: 5,
                },
            },
        });
    });

    it('should restore one deleted record', async () => {
        const deletionDate = new Date().toISOString();
        const mockDataProvider = {
            getOne: jest.fn((resource, params) =>
                Promise.resolve({
                    data: {
                        id: params.id,
                        resource: 'posts',
                        data: {
                            id: 1,
                        },
                        deleted_at: deletionDate,
                        deleted_by: 'johndoe',
                    } as DeletedRecordType,
                })
            ),
            getMany: jest.fn(() => Promise.resolve({ data: undefined })),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn((resource, params) =>
                Promise.resolve({ data: { id: params.data.id } })
            ),
            delete: jest.fn((resource, { previousData }) =>
                Promise.resolve({ data: previousData })
            ),
            deleteMany: jest.fn(() => Promise.resolve({ data: undefined })),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.restoreOne({
                id: 4,
            })
        ).toStrictEqual({
            data: {
                id: 4,
                resource: 'posts',
                data: {
                    id: 1,
                },
                deleted_at: deletionDate,
                deleted_by: 'johndoe',
            },
        });

        expect(mockDataProvider.getOne).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.getOne.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.getOne.mock.calls[0][1]).toStrictEqual({
            id: 4,
        });

        expect(mockDataProvider.create).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.create.mock.calls[0][0]).toBe('posts');
        expect(mockDataProvider.create.mock.calls[0][1]).toStrictEqual({
            data: {
                id: 1,
            },
        });

        expect(mockDataProvider.delete).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.delete.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.delete.mock.calls[0][1]).toStrictEqual({
            id: 4,
        });
    });

    it('should restore many deleted records', async () => {
        const deletionDate = new Date().toISOString();
        const mockDataProvider = {
            getOne: jest.fn(() => Promise.resolve({ data: undefined })),
            getMany: jest.fn((_resource, _params) =>
                Promise.resolve({
                    data: [
                        {
                            id: 1,
                            resource: 'posts',
                            data: { id: 1 },
                            deleted_at: deletionDate,
                            deleted_by: 'johndoe',
                        } as DeletedRecordType,
                        {
                            id: 2,
                            resource: 'comments',
                            data: { id: 5 },
                            deleted_at: deletionDate,
                            deleted_by: 'johndoe',
                        } as DeletedRecordType,
                    ],
                })
            ),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn((_resource, { data }) => Promise.resolve({ data })),
            delete: jest.fn(() => Promise.resolve({ data: undefined })),
            deleteMany: jest.fn((_resource, _params) =>
                Promise.resolve({ data: undefined })
            ),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.restoreMany({
                ids: [1, 2],
            })
        ).toStrictEqual({
            data: [
                {
                    id: 1,
                    resource: 'posts',
                    data: { id: 1 },
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
                {
                    id: 2,
                    resource: 'comments',
                    data: { id: 5 },
                    deleted_at: deletionDate,
                    deleted_by: 'johndoe',
                },
            ],
        });

        expect(mockDataProvider.getMany).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.getMany.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.getMany.mock.calls[0][1]).toStrictEqual({
            ids: [1, 2],
        });

        expect(mockDataProvider.create).toHaveBeenCalledTimes(2);
        expect(mockDataProvider.create.mock.calls[0][0]).toBe('posts');
        expect(mockDataProvider.create.mock.calls[0][1]).toStrictEqual({
            data: {
                id: 1,
            },
        });
        expect(mockDataProvider.create.mock.calls[1][1]).toStrictEqual({
            data: {
                id: 5,
            },
        });

        expect(mockDataProvider.deleteMany).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.deleteMany.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.deleteMany.mock.calls[0][1]).toStrictEqual({
            ids: [1, 2],
        });
    });

    it('should hard delete one deleted record', async () => {
        const mockDataProvider = {
            getOne: jest.fn(() => Promise.resolve({ data: undefined })),
            getMany: jest.fn(() => Promise.resolve({ data: undefined })),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn(() => Promise.resolve({ data: undefined })),
            delete: jest.fn((resource, { id }) =>
                Promise.resolve({ data: { id } })
            ),
            deleteMany: jest.fn(() => Promise.resolve({ data: undefined })),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.hardDelete({
                id: 4,
            })
        ).toStrictEqual({
            data: {
                id: 4,
            },
        });

        expect(mockDataProvider.delete).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.delete.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.delete.mock.calls[0][1]).toStrictEqual({
            id: 4,
        });
    });

    it('should hard delete many deleted records', async () => {
        const mockDataProvider = {
            getOne: jest.fn(() => Promise.resolve({ data: undefined })),
            getMany: jest.fn(() => Promise.resolve({ data: undefined })),
            getManyReference: jest.fn(() =>
                Promise.resolve({ data: undefined })
            ),
            getList: jest.fn(() => Promise.resolve({ data: undefined })),
            update: jest.fn(() => Promise.resolve({ data: undefined })),
            updateMany: jest.fn(() => Promise.resolve({ data: undefined })),
            create: jest.fn(() => Promise.resolve({ data: undefined })),
            delete: jest.fn(() => Promise.resolve({ data: undefined })),
            deleteMany: jest.fn((_resource, { ids }) =>
                Promise.resolve({ data: ids })
            ),
        };
        const dataProvider = addSoftDeleteBasedOnResource(
            mockDataProvider as DataProvider
        );

        expect(
            await dataProvider.hardDeleteMany({
                ids: [4, 5, 6],
            })
        ).toStrictEqual({
            data: [4, 5, 6],
        });

        expect(mockDataProvider.deleteMany).toHaveBeenCalledTimes(1);
        expect(mockDataProvider.deleteMany.mock.calls[0][0]).toBe(
            'deleted_records'
        );
        expect(mockDataProvider.deleteMany.mock.calls[0][1]).toStrictEqual({
            ids: [4, 5, 6],
        });
    });
});
