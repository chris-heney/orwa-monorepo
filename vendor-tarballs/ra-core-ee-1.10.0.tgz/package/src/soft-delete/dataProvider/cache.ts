import {
    QueryClient,
    InfiniteData,
    UseInfiniteQueryResult,
    QueryKey,
} from '@tanstack/react-query';
import {
    GetInfiniteListResult,
    GetListResult as OriginalGetListResult,
    Identifier,
    RaRecord,
} from 'ra-core';
import { DeletedRecordType, GetListDeletedResult } from './types';

export const deleteFromCollection = <RecordType extends RaRecord = any>(
    old: RecordType[],
    id: Identifier
) => {
    if (!old) return old;
    const index = old.findIndex(
        // eslint-disable-next-line eqeqeq
        record => record.id == id
    );
    if (index === -1) {
        return old;
    }
    return [...old.slice(0, index), ...old.slice(index + 1)];
};

export const updateListsCacheOnDeletion = <
    ResourceType extends string = string,
    RecordType extends RaRecord = any,
>({
    queryClient,
    resource,
    ids,
    undoable,
}: {
    queryClient: QueryClient;
    resource: ResourceType;
    ids: Identifier[];
    undoable: boolean;
}) => {
    // hack: only way to tell react-query not to fetch this query for the next 5 seconds
    // because setQueryData doesn't accept a stale time option
    const now = Date.now();
    const updatedAt = undoable ? now + 5 * 1000 : now;

    const updateCollection = <CollectionItem extends RaRecord = RecordType>(
        old: CollectionItem[]
    ) => {
        let newCollection = [...old];
        ids.forEach(
            id =>
                (newCollection = deleteFromCollection<CollectionItem>(
                    newCollection,
                    id
                ))
        );
        return newCollection;
    };

    type GetListResult = Omit<OriginalGetListResult, 'data'> & {
        data?: RecordType[];
    };

    queryClient.setQueriesData(
        { queryKey: [resource, 'getList'] },
        (res: GetListResult) => {
            if (!res || !res.data) return res;
            const newCollection = updateCollection(res.data);
            const lengthDiff = res.data.length - newCollection.length;
            const recordWasFound = lengthDiff > 0;
            return recordWasFound
                ? {
                      data: newCollection,
                      total: res.total ? res.total - lengthDiff : undefined,
                      pageInfo: res.pageInfo,
                  }
                : res;
        },
        { updatedAt }
    );
    queryClient.setQueriesData(
        { queryKey: [resource, 'getInfiniteList'] },
        (
            res: UseInfiniteQueryResult<
                InfiniteData<GetInfiniteListResult>
            >['data']
        ) => {
            if (!res || !res.pages) return res;
            return {
                ...res,
                pages: res.pages.map(page => {
                    const newCollection = updateCollection(page.data);
                    const lengthDiff = page.data.length - newCollection.length;
                    const recordWasFound = lengthDiff > 0;
                    return recordWasFound
                        ? {
                              ...page,
                              data: newCollection,
                              total: page.total
                                  ? page.total - lengthDiff
                                  : undefined,
                              pageInfo: page.pageInfo,
                          }
                        : page;
                }),
            };
        },
        { updatedAt }
    );
    queryClient.setQueriesData(
        { queryKey: [resource, 'getMany'] },
        (coll: RecordType[]) =>
            coll && coll.length > 0 ? updateCollection(coll) : coll,
        { updatedAt }
    );
    queryClient.setQueriesData(
        { queryKey: [resource, 'getManyReference'] },
        (res: GetListResult) => {
            if (!res || !res.data) return res;
            const newCollection = updateCollection(res.data);
            const lengthDiff = res.data.length - newCollection.length;
            const recordWasFound = lengthDiff > 0;
            return recordWasFound
                ? {
                      data: newCollection,
                      total: res.total! - lengthDiff,
                  }
                : res;
        },
        { updatedAt }
    );
};
export const updateGetOneCache = <
    ResourceType extends string = string,
    RecordType extends RaRecord = any,
>({
    queryClient,
    resource,
    id,
    data,
    meta,
    undoable,
}: {
    queryClient: QueryClient;
    resource: ResourceType;
    id: Identifier;
    data: Partial<RecordType>;
    meta: any;
    undoable: boolean;
}) => {
    // hack: only way to tell react-query not to fetch this query for the next 5 seconds
    // because setQueryData doesn't accept a stale time option
    const now = Date.now();
    const updatedAt = undoable ? now + 5 * 1000 : now;

    // Stringify and parse the data to remove undefined values.
    // If we don't do this, an update with { id: undefined } as payload
    // would remove the id from the record, which no real data provider does.
    const clonedData = JSON.parse(JSON.stringify(data));
    queryClient.setQueryData(
        [resource, 'getOne', { id: String(id), meta }],
        (record: RecordType) => ({ ...record, ...clonedData }),
        { updatedAt }
    );
};

export const updateListDeletedCacheOnDeletion = <
    RecordType extends RaRecord = any,
>({
    queryClient,
    ids,
    undoable,
}: {
    queryClient: QueryClient;
    ids: Identifier[];
    undoable: boolean;
}) => {
    // hack: only way to tell react-query not to fetch this query for the next 5 seconds
    // because setQueryData doesn't accept a stale time option
    const now = Date.now();
    const updatedAt = undoable ? now + 5 * 1000 : now;

    const updateCollection = <
        CollectionItem extends RaRecord = DeletedRecordType<RecordType>,
    >(
        old: CollectionItem[]
    ) => {
        let newCollection = [...old];
        ids.forEach(
            id =>
                (newCollection = deleteFromCollection<CollectionItem>(
                    newCollection,
                    id
                ))
        );
        return newCollection;
    };

    queryClient.setQueriesData(
        { queryKey: ['getListDeleted'] },
        (res: GetListDeletedResult) => {
            if (!res || !res.data) return res;
            const newCollection = updateCollection<
                DeletedRecordType<RecordType>
            >(res.data);
            const lengthDiff = res.data.length - newCollection.length;
            const recordWasFound = lengthDiff > 0;
            return recordWasFound
                ? {
                      data: newCollection,
                      total: res.total ? res.total - lengthDiff : undefined,
                      pageInfo: res.pageInfo,
                  }
                : res;
        },
        { updatedAt }
    );
};

export const updateGetOneDeletedCacheOnDeletion = ({
    queryClient,
    id,
    meta,
    undoable,
}: {
    queryClient: QueryClient;
    id: Identifier;
    meta: any;
    undoable: boolean;
}) => {
    // hack: only way to tell react-query not to fetch this query for the next 5 seconds
    // because setQueryData doesn't accept a stale time option
    const now = Date.now();
    const updatedAt = undoable ? now + 5 * 1000 : now;

    // we're not using removeQueries to be able to set `updatedAt`.
    queryClient.setQueryData(
        ['getOneDeleted', { id: String(id), meta }],
        null,
        { updatedAt }
    );
};

export const updateGetOneDeletedCache = <RecordType extends RaRecord = any>({
    queryClient,
    id,
    data,
    meta,
    undoable,
}: {
    queryClient: QueryClient;
    id: Identifier;
    data: Partial<DeletedRecordType<RecordType>>;
    meta: any;
    undoable: boolean;
}) => {
    // hack: only way to tell react-query not to fetch this query for the next 5 seconds
    // because setQueryData doesn't accept a stale time option
    const now = Date.now();
    const updatedAt = undoable ? now + 5 * 1000 : now;

    // Stringify and parse the data to remove undefined values.
    // If we don't do this, an update with { id: undefined } as payload
    // would remove the id from the record, which no real data provider does.
    const clonedData = JSON.parse(JSON.stringify(data));

    queryClient.setQueryData(
        ['getOneDeleted', { id: String(id), meta }],
        (record: DeletedRecordType<RecordType>) => ({
            ...record,
            ...clonedData,
        }),
        { updatedAt }
    );
};

export type CacheSnapshot = [key: QueryKey, value: any][];

/**
 * Snapshot the previous values via queryClient.getQueriesData()
 *
 * The snapshotData ref will contain an array of tuples [query key, associated data]
 *
 * @example
 * [
 *   [['posts', 'getList'], { data: [{ id: 1, title: 'Hello' }], total: 1 }],
 *   [['posts', 'getMany'], [{ id: 1, title: 'Hello' }]],
 * ]
 *
 * @see https://tanstack.com/query/v5/docs/react/reference/QueryClient#queryclientgetqueriesdata
 */
export const createSnapshot = (
    queryClient: QueryClient,
    queryKeys: QueryKey[]
) => {
    return queryKeys.reduce(
        (snapshot: CacheSnapshot, queryKey) =>
            snapshot.concat(queryClient.getQueriesData({ queryKey })),
        []
    ) as CacheSnapshot;
};

export const applySnapshot = (
    queryClient: QueryClient,
    cacheSnapshot: CacheSnapshot
) => {
    cacheSnapshot.forEach(([key, value]) => {
        queryClient.setQueryData(key, value);
    });
};
