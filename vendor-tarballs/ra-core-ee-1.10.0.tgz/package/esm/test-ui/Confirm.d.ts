export declare const Confirm: ({ isOpen, content, onClose, onConfirm, title, translateOptions, titleTranslateOptions, contentTranslateOptions, }: {
    isOpen: boolean;
    title: string;
    content: string;
    onConfirm: () => void;
    onClose: () => void;
    translateOptions?: Record<string, any>;
    titleTranslateOptions?: Record<string, any>;
    contentTranslateOptions?: Record<string, any>;
}) => import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=Confirm.d.ts.map