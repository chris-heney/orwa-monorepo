import * as React from 'react';
import { InputProps } from 'ra-core';
export declare const TextInput: ({ multiline, type, ...props }: InputProps & {
    type?: React.HTMLInputTypeAttribute;
    multiline?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TextInput.d.ts.map