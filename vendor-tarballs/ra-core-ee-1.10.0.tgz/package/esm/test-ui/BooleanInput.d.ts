import { InputProps } from 'ra-core';
export declare const BooleanInput: (props: InputProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BooleanInput.d.ts.map