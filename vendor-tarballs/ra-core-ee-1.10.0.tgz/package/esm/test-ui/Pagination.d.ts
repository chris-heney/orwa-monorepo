export declare const Pagination: () => import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=Pagination.d.ts.map