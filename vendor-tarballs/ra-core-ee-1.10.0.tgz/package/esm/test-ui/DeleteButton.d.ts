import * as React from 'react';
import { UseDeleteControllerParams } from 'ra-core';
export declare const DeleteButton: (props: UseDeleteControllerParams & {
    label: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DeleteButton.d.ts.map