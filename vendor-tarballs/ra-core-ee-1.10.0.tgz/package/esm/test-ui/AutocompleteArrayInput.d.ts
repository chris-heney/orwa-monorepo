import { ChoicesProps, InputProps } from 'ra-core';
export declare const AutocompleteArrayInput: (props: Partial<InputProps> & Partial<ChoicesProps>) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AutocompleteArrayInput.d.ts.map