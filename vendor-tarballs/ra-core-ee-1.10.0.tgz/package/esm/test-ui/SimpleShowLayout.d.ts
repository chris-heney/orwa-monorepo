import * as React from 'react';
export declare const SimpleShowLayout: ({ children, }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SimpleShowLayout.d.ts.map