import { RaRecord } from 'ra-core';
export declare const ShowButton: (props: {
    record?: RaRecord;
    resource?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=ShowButton.d.ts.map