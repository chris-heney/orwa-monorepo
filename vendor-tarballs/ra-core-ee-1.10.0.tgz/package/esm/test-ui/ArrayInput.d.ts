import { InputProps } from 'ra-core';
import * as React from 'react';
export declare const ArrayInput: (props: ArrayInputProps) => import("react/jsx-runtime").JSX.Element | null;
export interface ArrayInputProps extends Omit<InputProps, 'disabled' | 'readOnly'> {
    className?: string;
    children: React.ReactNode;
    isFetching?: boolean;
    isLoading?: boolean;
    isPending?: boolean;
}
//# sourceMappingURL=ArrayInput.d.ts.map