import * as React from 'react';
export declare const SimpleList: ({ children, render, inline, }: {
    children?: React.ReactNode;
    render?: (record: any) => React.ReactNode;
    inline?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SimpleList.d.ts.map