import * as React from 'react';
import { type ReactElement, type ReactNode } from 'react';
import { type RaRecord, ArrayInputContextValue } from 'ra-core';
import { type UseFieldArrayReturn } from 'react-hook-form';
export type DisableRemoveFunction = (record: RaRecord) => boolean;
export declare const SimpleFormIteratorItem: React.ForwardRefExoticComponent<Partial<ArrayInputContextValue> & {
    children?: ReactNode;
    disabled?: boolean;
    disableRemove?: boolean | DisableRemoveFunction;
    disableReordering?: boolean;
    getItemLabel?: boolean | GetItemLabelFunc;
    index: number;
    inline?: boolean;
    onRemoveField: (index: number) => void;
    onReorder: (origin: number, destination: number) => void;
    record: RaRecord;
    removeButton?: ReactElement;
    reOrderButtons?: ReactElement;
    resource?: string;
    source?: string;
} & React.RefAttributes<any>>;
export declare const SimpleFormIterator: (props: SimpleFormIteratorProps) => import("react/jsx-runtime").JSX.Element | null;
type GetItemLabelFunc = (index: number) => string | ReactElement;
export interface SimpleFormIteratorProps extends Partial<UseFieldArrayReturn> {
    addButton?: ReactElement;
    children?: ReactNode;
    className?: string;
    readOnly?: boolean;
    disabled?: boolean;
    disableAdd?: boolean;
    disableClear?: boolean;
    disableRemove?: boolean | DisableRemoveFunction;
    disableReordering?: boolean;
    fullWidth?: boolean;
    getItemLabel?: boolean | GetItemLabelFunc;
    inline?: boolean;
    meta?: {
        error?: any;
        submitFailed?: boolean;
    };
    record?: RaRecord;
    removeButton?: ReactElement;
    reOrderButtons?: ReactElement;
    resource?: string;
    source?: string;
}
export {};
//# sourceMappingURL=SimpleFormIterator.d.ts.map