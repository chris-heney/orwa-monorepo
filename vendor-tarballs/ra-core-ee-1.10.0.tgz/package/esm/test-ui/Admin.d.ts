import { CoreAdminProps } from 'ra-core';
export declare const Admin: (props: CoreAdminProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Admin.d.ts.map