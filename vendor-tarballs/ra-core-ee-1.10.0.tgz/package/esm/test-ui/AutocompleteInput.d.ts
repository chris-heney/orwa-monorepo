import { ChoicesProps, InputProps } from 'ra-core';
export declare const AutocompleteInput: (props: Partial<InputProps> & Partial<ChoicesProps> & {
    multiple?: boolean;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AutocompleteInput.d.ts.map