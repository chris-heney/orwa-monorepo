import { FormProps } from 'ra-core';
export declare const SimpleForm: ({ children, ...props }: FormProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SimpleForm.d.ts.map