import { RaRecord, UsePrevNextControllerProps } from 'ra-core';
export declare const PrevNextButtons: <RecordType extends RaRecord = any>(props: PrevNextButtonProps<RecordType>) => import("react/jsx-runtime").JSX.Element | null;
export interface PrevNextButtonProps<RecordType extends RaRecord = any> extends UsePrevNextControllerProps<RecordType> {
}
//# sourceMappingURL=PrevNextButtons.d.ts.map