import * as React from 'react';
import { DataTableBaseProps, RaRecord } from 'ra-core';
export declare const DataTable: {
    (props: Omit<DataTableBaseProps, "hasBulkActions" | "empty" | "loading"> & {
        hasBulkActions?: boolean;
    }): import("react/jsx-runtime").JSX.Element;
    Col: (props: {
        children?: React.ReactNode;
        render?: (record: RaRecord) => React.ReactNode;
        field?: React.ElementType;
        source?: string;
        label?: React.ReactNode;
    }) => import("react/jsx-runtime").JSX.Element | undefined;
};
//# sourceMappingURL=DataTable.d.ts.map