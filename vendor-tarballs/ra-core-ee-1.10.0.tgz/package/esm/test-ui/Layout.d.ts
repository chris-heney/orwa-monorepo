import * as React from 'react';
export declare const Layout: ({ children }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Layout.d.ts.map