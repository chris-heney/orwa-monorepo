import { RaRecord } from 'ra-core';
export declare const EditButton: (props: {
    record?: RaRecord;
    resource?: string;
}) => import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=EditButton.d.ts.map