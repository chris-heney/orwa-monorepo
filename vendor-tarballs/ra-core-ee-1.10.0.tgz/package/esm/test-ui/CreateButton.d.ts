export declare const CreateButton: (props: {
    resource?: string;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CreateButton.d.ts.map