import RaRealTimeTranslationMessages from './RaRealTimeTranslationMessages';
export declare const raRealTimeLanguageFrench: RaRealTimeTranslationMessages;
export default raRealTimeLanguageFrench;
//# sourceMappingURL=raRealTimeLanguageFrench.d.ts.map