import RaRealTimeTranslationMessages from './RaRealTimeTranslationMessages';
export declare const raRealTimeLanguageEnglish: RaRealTimeTranslationMessages;
export default raRealTimeLanguageEnglish;
//# sourceMappingURL=raRealTimeLanguageEnglish.d.ts.map