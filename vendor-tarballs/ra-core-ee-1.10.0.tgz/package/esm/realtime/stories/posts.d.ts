export declare const posts: {
    id: number;
    title: string;
    headline: string;
    author: string;
}[];
//# sourceMappingURL=posts.d.ts.map