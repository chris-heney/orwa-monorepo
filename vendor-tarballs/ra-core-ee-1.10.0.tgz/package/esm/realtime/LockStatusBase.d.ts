import * as React from 'react';
import { UseLockCallbacksParams, UseLockCallbacksResult } from './controller';
export declare const LockStatusBase: (props: LockStatusBaseProps) => React.ReactNode;
export type LockState = 'lockedByUser' | 'lockedByAnotherUser' | 'unlocked';
export type LockStatusRenderParams = UseLockCallbacksResult & {
    isLocking: boolean;
    lockStatus: LockState;
    message: string;
};
export type LockStatusBaseProps = UseLockCallbacksParams & {
    render: (params: LockStatusRenderParams) => React.ReactNode;
};
//# sourceMappingURL=LockStatusBase.d.ts.map