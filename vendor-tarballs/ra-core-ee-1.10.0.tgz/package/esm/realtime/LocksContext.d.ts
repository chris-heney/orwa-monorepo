import { Lock } from './types';
export declare const LocksContext: import("react").Context<Lock[]>;
export declare const useLocksContext: () => Lock[];
//# sourceMappingURL=LocksContext.d.ts.map