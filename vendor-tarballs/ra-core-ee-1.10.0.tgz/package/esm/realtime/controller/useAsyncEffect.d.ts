/**
 * Hook to run an async effect on mount and another on unmount.
 *
 * This is necessary because of intricacies of useEffect and StrictMode
 * @see https://beta.reactjs.org/learn/synchronizing-with-effects#fetching-data
 */
export declare const useAsyncEffect: (mountCallback: () => Promise<any>, unmountCallback: () => Promise<any>, deps?: any[]) => UseAsyncEffectResult;
export interface UseAsyncEffectResult {
    result: any;
    error: any;
    isLoading: boolean;
}
//# sourceMappingURL=useAsyncEffect.d.ts.map