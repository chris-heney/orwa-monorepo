import { RecordListEvent, SubscriptionCallback } from './types';
/**
 * Watches for events related to a record list in a ListContext, and triggers a refetch when one occurs.
 *
 * To be used e.g. in a `<ListBase>` to trigger a refetch when a record is created, updated, or deleted.
 *
 * Requires ra-core 4.7.0 or later.
 *
 * @example
 * import { ListBase } from 'ra-core';
 * import { ListLiveUpdate } from '@react-admin/ra-core-ee';
 *
 * const PostList = () => (
 *     <ListBase>
 *         <ListLiveUpdate />
 *        ... other children
 *     </ListBase>
 * );
 */
export declare const ListLiveUpdate: ({ onEventReceived }: ListLiveUpdateProps) => null;
export interface ListLiveUpdateProps {
    onEventReceived?: SubscriptionCallback<RecordListEvent>;
}
//# sourceMappingURL=ListLiveUpdate.d.ts.map