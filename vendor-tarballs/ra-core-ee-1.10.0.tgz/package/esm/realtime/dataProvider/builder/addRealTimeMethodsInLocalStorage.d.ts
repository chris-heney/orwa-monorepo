import { DataProvider } from 'ra-core';
import { RealTimeDataProvider } from '../../types';
/**
 * Add realTime methods to a dataProvider based on a localstorage event bus.
 *
 * The publish/subscribe events happen only in the current browser - no event
 * broadcasting to other clients, except on other tabs of the same browser.
 * This is done only for testing purposes.
 *
 * @param {DataProvider} dataProvider The dataProvider to augment
 * @returns {DataProvider}
 *
 * @warning Do not use in production.
 *
 * @example
 *
 * const realTimeDataProvider = addRealTimeMethodsInLocalStorage(dataProvider);
 *
 * await realTimeDataProvider.subscribe('resource/post', (event) => {
 *    console.log(`Post ${event.payload.id} modified`);
 * });
 *
 * await realTimeDataProvider.publish('resource/post', {
 *     type: 'updated',
 *     payload: { id: 1234 }
 * })
 */
export declare const addRealTimeMethodsInLocalStorage: (dataProvider: DataProvider) => DataProvider & RealTimeDataProvider;
//# sourceMappingURL=addRealTimeMethodsInLocalStorage.d.ts.map