import { DataProvider } from 'ra-core';
export declare const addLocalCRUDEvents: (dataProvider: DataProvider) => {
    create: (resource: any, params: any) => Promise<import("ra-core").CreateResult<any>>;
    update: (resource: any, params: any) => Promise<import("ra-core").UpdateResult<any>>;
    delete: (resource: any, params: any) => Promise<import("ra-core").DeleteResult<any>>;
    getList: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetListParams & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetListResult<RecordType>>;
    getOne: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetOneParams<RecordType> & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetOneResult<RecordType>>;
    getMany: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetManyParams<RecordType> & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetManyResult<RecordType>>;
    getManyReference: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetManyReferenceParams & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetManyReferenceResult<RecordType>>;
    updateMany: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").UpdateManyParams) => Promise<import("ra-core").UpdateManyResult<RecordType>>;
    deleteMany: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").DeleteManyParams<RecordType>) => Promise<import("ra-core").DeleteManyResult<RecordType>>;
    supportAbortSignal?: boolean;
};
//# sourceMappingURL=addLocalCRUDEvents.d.ts.map