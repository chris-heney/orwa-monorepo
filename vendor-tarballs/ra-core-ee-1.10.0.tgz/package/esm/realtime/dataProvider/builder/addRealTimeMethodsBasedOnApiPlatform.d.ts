import { ApiPlatformAdminDataProvider } from '@api-platform/admin';
import { DataProvider } from 'ra-core';
import { RealTimeDataProvider } from '../../types';
/**
 * Add realTime methods to a dataProvider based on a Mercure Hub inside API-Platform.
 *
 * @see https://mercure.rocks/
 * @see https://api-platform.com/docs/core/mercure/#creating-async-apis-using-the-mercure-protocol
 *
 * @param {DataProvider} dataProvider The dataProvider to augment
 * @param {string} mercureURL The adress of the Mercure Hub
 * @param {string} jwt The JWT to connect to the Mercure Hub
 * @param {string} topicPrefix The prefix used for each subcription topic
 *
 * @example
 *
 * const realTimeDataProvider = addRealTimeMethodsBasedOnApiPlatform(
 *     dataProvider,
 *     'eyJhbGciOiJIUzI1NiJ9.eyJtZXJjdXJlIjp7InB1Ymxpc2giOlsiKiJdLCJzdWJzY3JpYmUiOlsiKiJdfX0.SWKHNF9wneXTSjBg81YN5iH8Xb2iTf_JwhfUY5Iyhsw',
 *     'http://path.to.my.api/.well-known/mercure'
 * );
 *
 * await realTimeDataProvider.subscribe('resource/post', (event) => {
 *    console.log(`Post ${event.payload.id} modified`);
 * });
 *
 * await realTimeDataProvider.publish('resource/post', {
 *     type: 'updated',
 *     payload: { id: 1234 }
 * })
 */
export declare const addRealTimeMethodsBasedOnApiPlatform: (dataProvider: DataProvider, mercureURL?: string, jwt?: null, topicPrefix?: string, transformTopicFromRaRealtime?: (topic: string) => string) => DataProvider & RealTimeDataProvider & ApiPlatformAdminDataProvider;
/**
 * Transform a topic written using the ra-realtime convention
 * into a topic following the API-Platform convention
 *
 * @param {*} topic The topic in ra-realtime format
 *
 * @returns A topic translated using API-Platform convention
 *
 * @example Subscribe to a record
 *
 * => Format of the ra-realtime topic: `resource/${resource}/${id}`
 * => Format of the id: `/${resource}/${originId}`
 * Should be passed to API-Platform as: `/${resource}/${originId}`
 *
 * @example Subscribe to a list:
 *
 * Format of the ra-realtime topic: `resource/${resource}`
 * => Should be passed to API-Platform as: `/${resource}/{id}`
 *
 * Note that {id} is not interpreted. It's a string meaning all the resource events.
 *
 */
export declare function defaultTransformTopicFromRaRealtime(topic: string): string;
//# sourceMappingURL=addRealTimeMethodsBasedOnApiPlatform.d.ts.map