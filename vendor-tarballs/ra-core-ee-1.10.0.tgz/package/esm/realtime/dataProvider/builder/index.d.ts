export * from './addLocksMethodsBasedOnALockResource';
export * from './addRealTimeMethodsBasedOnSupabase';
export * from './addRealTimeMethodsBasedOnApiPlatform';
export * from './addRealTimeMethodsBasedOnMercure';
export * from './addRealTimeMethodsInLocalBrowser';
export * from './addRealTimeMethodsInLocalStorage';
export * from './addLocalCRUDEvents';
//# sourceMappingURL=index.d.ts.map