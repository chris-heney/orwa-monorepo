import { SupabaseClient, RealtimePostgresChangesPayload } from '@supabase/supabase-js';
import { DataProvider, Identifier } from 'ra-core';
import { RealTimeDataProvider } from '../../types';
/**
 * Add real time methods to a dataProvider based on a Supabase client.
 *
 * @see https://supabase.com/docs/guides/realtime
 * @see https://supabase.com/docs/guides/realtime/extensions/postgres-changes
 *
 * @param dataProvider The dataProvider to augment
 * @param supabaseClient The Supabase client
 *
 * @example
 * ```tsx
 * import { addRealTimeMethodsBasedOnSupabase } from '@react-admin/ra-core-ee';
 * import { supabaseDataProvider } from 'ra-supabase';
 * import { CoreAdmin, Resource } from 'ra-core';
 * import { supabaseClient, instanceUrl, apiKey } from './supabaseClient';
 * import { SaleList } from './sales';
 *
 * const dataProvider = supabaseDataProvider({
 *     instanceUrl, apiKey, supabaseClient
 * });
 *
 * const realTimeDataProvider = addRealTimeMethodsBasedOnSupabase({
 *     dataProvider,
 *     supabaseClient,
 * });
 *
 * export const App = () => (
 *     <CoreAdmin dataProvider={realTimeDataProvider}>
 *         <Resource name="sales" list={SaleList} />
 *     </CoreAdmin>
 * );
 * ```
 */
export declare const addRealTimeMethodsBasedOnSupabase: ({ dataProvider, supabaseClient, }: AddRealTimeMethodsBasedOnSupabaseParams) => DataProvider & RealTimeDataProvider;
export interface AddRealTimeMethodsBasedOnSupabaseParams {
    dataProvider: DataProvider;
    supabaseClient: SupabaseClient;
}
export declare const getCRUDEventTypeFromSupabaseType: (eventType: string) => string;
export declare const getTableFromTopic: (topic: string) => string;
export declare const getIdFromTopic: (topic: string) => Identifier;
export declare const getIdsFromPayload: (payload: RealtimePostgresChangesPayload<{
    [key: string]: any;
}>) => Identifier[];
//# sourceMappingURL=addRealTimeMethodsBasedOnSupabase.d.ts.map