export declare class ErrorMissingEventType extends Error {
    constructor(message?: string);
}
//# sourceMappingURL=ErrorMissingEventType.d.ts.map