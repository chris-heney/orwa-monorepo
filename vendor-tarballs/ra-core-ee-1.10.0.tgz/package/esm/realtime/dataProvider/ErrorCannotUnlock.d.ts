export declare class ErrorCannotUnlock extends Error {
    constructor(message?: string);
}
//# sourceMappingURL=ErrorCannotUnlock.d.ts.map