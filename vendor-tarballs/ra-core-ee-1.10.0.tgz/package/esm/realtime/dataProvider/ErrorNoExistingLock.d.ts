export declare class ErrorNoExistingLock extends Error {
    constructor(message?: string);
}
//# sourceMappingURL=ErrorNoExistingLock.d.ts.map