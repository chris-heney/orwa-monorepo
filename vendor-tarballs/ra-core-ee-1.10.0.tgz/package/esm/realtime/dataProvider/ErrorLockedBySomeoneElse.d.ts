export declare class ErrorLockedBySomeoneElse extends Error {
    constructor(message?: string);
}
//# sourceMappingURL=ErrorLockedBySomeoneElse.d.ts.map