export declare class ErrorMissingTopic extends Error {
    constructor(message?: string);
}
//# sourceMappingURL=ErrorMissingTopic.d.ts.map