import { UseLockOnMountParams } from './controller/useLockOnMount';
export declare const LockOnMount: (props: LockOnMountProps) => null;
export type LockOnMountProps = UseLockOnMountParams;
//# sourceMappingURL=LockOnMount.d.ts.map