export * from './detectChangedFields';
//# sourceMappingURL=index.d.ts.map