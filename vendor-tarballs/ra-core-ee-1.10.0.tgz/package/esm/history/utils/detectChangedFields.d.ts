export declare const detectChangedFields: (object1: any, object2: any) => string[];
//# sourceMappingURL=detectChangedFields.d.ts.map