import { RaHistoryTranslationMessages } from './RaHistoryTranslationMessages';
export declare const raHistoryLanguageFrench: RaHistoryTranslationMessages;
//# sourceMappingURL=raHistoryLanguageFrench.d.ts.map