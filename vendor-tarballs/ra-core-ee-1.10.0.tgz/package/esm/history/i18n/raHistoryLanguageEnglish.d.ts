import { RaHistoryTranslationMessages } from './RaHistoryTranslationMessages';
export declare const raHistoryLanguageEnglish: RaHistoryTranslationMessages;
//# sourceMappingURL=raHistoryLanguageEnglish.d.ts.map