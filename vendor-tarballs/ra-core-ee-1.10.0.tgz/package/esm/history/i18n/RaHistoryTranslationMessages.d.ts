export interface RaHistoryTranslationMessages {
    'ra-history': {
        revisions: {
            name: string;
            name_with_count: string;
        };
        info: {
            changes_applied: string;
        };
        on_save: {
            title: string;
            message: string;
            description: string;
            author: string;
            initial_changes: string;
            no_changes: string;
            one_change: string;
            many_changes: string;
            missing_revision_message: string;
        };
        revision_details: {
            title: string;
            revert: string;
            compare: string;
            compare_with: string;
            revision: string;
            revision_selected: string;
        };
    };
}
//# sourceMappingURL=RaHistoryTranslationMessages.d.ts.map