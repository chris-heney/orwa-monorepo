declare const _default: {
    title: string;
};
export default _default;
export declare const CallTime: ({ dataProvider: overrides, }: {
    dataProvider?: any;
}) => import("react/jsx-runtime").JSX.Element;
export declare const HookTime: ({ dataProvider: overrides, }: {
    dataProvider?: any;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=dataProviderHooks.stories.d.ts.map