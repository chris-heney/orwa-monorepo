import { Identifier } from 'ra-core';
import { UseMutationResult, MutateOptions } from '@tanstack/react-query';
import { RecordRevision } from '../types';
export declare const useAddRevision: (resource?: string, params?: {
    recordId: Identifier;
    data: any;
    date: string;
    authorId?: Identifier;
    message?: string;
    description?: string;
}, options?: any) => UseAddRevisionResult<boolean>;
export interface UseAddRevisionParams {
    recordId: Identifier;
    data: any;
    date: string;
    authorId?: Identifier;
    message?: string;
    description?: any;
}
export interface UseAddRevisionMutateParams extends UseAddRevisionParams {
    resource: string;
}
export type AddRevisionMutationFunction<TReturnPromise extends boolean = boolean> = (resource?: string, params?: Partial<UseAddRevisionParams>, options?: MutateOptions<{
    data: RecordRevision;
}, unknown, Partial<UseAddRevisionMutateParams>, unknown> & {
    returnPromise?: TReturnPromise;
}) => Promise<TReturnPromise extends true ? {
    data: RecordRevision;
} : void>;
export type UseAddRevisionResult<TReturnPromise extends boolean = boolean> = [
    AddRevisionMutationFunction<TReturnPromise>,
    UseMutationResult<{
        data: RecordRevision;
    }, unknown, Partial<UseAddRevisionParams & {
        resource?: string;
    }>, unknown>
];
//# sourceMappingURL=useAddRevision.d.ts.map