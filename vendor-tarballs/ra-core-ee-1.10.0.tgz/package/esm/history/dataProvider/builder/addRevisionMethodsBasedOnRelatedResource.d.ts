import { DataProvider } from 'ra-core';
export declare const addRevisionMethodsBasedOnRelatedResource: (dataProvider: DataProvider, { getRevisionResourceName }?: {
    getRevisionResourceName: (resource: any) => string;
}) => {
    getRevisions: (resource: any, { recordId }: {
        recordId: any;
    }) => Promise<{
        data: any[];
        total?: number;
        pageInfo?: {
            hasNextPage?: boolean;
            hasPreviousPage?: boolean;
        };
        meta?: any;
    }>;
    addRevision: (resource: any, { recordId, data, authorId, message, description }: {
        recordId: any;
        data: any;
        authorId: any;
        message: any;
        description: any;
    }) => Promise<{
        data: any;
        meta?: any;
    }>;
    deleteRevisions: (resource: any, { recordId }: {
        recordId: any;
    }) => Promise<import("ra-core").DeleteManyResult<any>>;
    getList: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetListParams & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetListResult<RecordType>>;
    getOne: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetOneParams<RecordType> & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetOneResult<RecordType>>;
    getMany: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetManyParams<RecordType> & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetManyResult<RecordType>>;
    getManyReference: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").GetManyReferenceParams & import("ra-core").QueryFunctionContext) => Promise<import("ra-core").GetManyReferenceResult<RecordType>>;
    update: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").UpdateParams) => Promise<import("ra-core").UpdateResult<RecordType>>;
    updateMany: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").UpdateManyParams) => Promise<import("ra-core").UpdateManyResult<RecordType>>;
    create: <RecordType extends Omit<import("ra-core").RaRecord, "id"> = any, ResultRecordType extends import("ra-core").RaRecord = RecordType & {
        id: import("ra-core").Identifier;
    }>(resource: string, params: import("ra-core").CreateParams) => Promise<import("ra-core").CreateResult<ResultRecordType>>;
    delete: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").DeleteParams<RecordType>) => Promise<import("ra-core").DeleteResult<RecordType>>;
    deleteMany: <RecordType extends import("ra-core").RaRecord = any>(resource: string, params: import("ra-core").DeleteManyParams<RecordType>) => Promise<import("ra-core").DeleteManyResult<RecordType>>;
    supportAbortSignal?: boolean;
};
//# sourceMappingURL=addRevisionMethodsBasedOnRelatedResource.d.ts.map