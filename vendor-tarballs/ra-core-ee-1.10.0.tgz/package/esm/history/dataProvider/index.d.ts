export * from './useGetRevisions';
export * from './useAddRevision';
export * from './useDeleteRevisions';
export * from './builder/addRevisionMethodsBasedOnSingleResource';
export * from './builder/addRevisionMethodsBasedOnRelatedResource';
//# sourceMappingURL=index.d.ts.map