import { Identifier } from 'ra-core';
export interface UseAddRevisionAfterMutationParams {
    /**
     * A function that returns the revision metadata (message, description, authorId) in a promise
     */
    getMetadata: (params: {
        resource: string;
        data: any;
    }) => Promise<{
        message: string;
        description?: string;
        authorId?: Identifier;
    }>;
}
/**
 * Modify the save handler of a create or edit view to add a revision on save
 *
 * Registers a mutation middleware that asks revision metadata before the
 * mutation, and creates a revision with the save data after the mutation.
 */
export declare const useAddRevisionAfterMutation: () => void;
export declare const REVISION_FIELD = "@ra-history/revision";
//# sourceMappingURL=useAddRevisionAfterMutation.d.ts.map