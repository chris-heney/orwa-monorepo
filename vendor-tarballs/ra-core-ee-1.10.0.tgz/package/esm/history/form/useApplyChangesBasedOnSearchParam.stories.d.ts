declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=useApplyChangesBasedOnSearchParam.stories.d.ts.map