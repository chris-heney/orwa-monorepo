export declare const useApplyChangesBasedOnSearchParam: () => boolean;
//# sourceMappingURL=useApplyChangesBasedOnSearchParam.d.ts.map