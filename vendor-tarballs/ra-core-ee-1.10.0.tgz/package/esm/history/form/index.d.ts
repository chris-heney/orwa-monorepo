export * from './useApplyChangesBasedOnSearchParam';
//# sourceMappingURL=index.d.ts.map