declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: ({ dataProvider }: {
    dataProvider?: any;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=useAddRevisionAfterMutation.stories.d.ts.map