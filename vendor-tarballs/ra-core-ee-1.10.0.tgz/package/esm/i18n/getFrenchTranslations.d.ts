import { Module, RaCoreEETranslations } from './types';
export declare const getFrenchTranslations: <Modules extends Module[]>(...modules: Modules) => RaCoreEETranslations<Modules>;
//# sourceMappingURL=getFrenchTranslations.d.ts.map