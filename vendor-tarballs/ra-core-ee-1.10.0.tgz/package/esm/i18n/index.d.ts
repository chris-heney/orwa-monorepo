export * from './getEnglishTranslations';
export * from './getFrenchTranslations';
export * from './types';
//# sourceMappingURL=index.d.ts.map