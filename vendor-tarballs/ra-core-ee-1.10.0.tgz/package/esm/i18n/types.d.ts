import { RaFormLayoutTranslationMessages } from '../form-layout';
import { RaHistoryTranslationMessages } from '../history';
import { RaRealTimeTranslationMessages } from '../realtime';
import { RaRelationshipsTranslationMessages } from '../relationships';
import { RaSoftDeleteTranslationMessages } from '../soft-delete';
export type Module = 'ra-history' | 'ra-realtime' | 'ra-relationships' | 'ra-soft-delete' | 'ra-form-layout';
type Merge<Destination, Source> = {
    [Key in keyof Destination as Key extends keyof Source ? never : Key]: Destination[Key];
} & Source;
type Simplify<T> = {
    [KeyType in keyof T]: T[KeyType];
} & {};
type MergeModuleTranslations<Modules extends Module[], MergedTranslations extends any = unknown> = Modules extends [
    infer First extends Module,
    ...infer Rest extends Module[]
] ? First extends 'ra-history' ? Merge<MergeModuleTranslations<Rest, MergedTranslations>, RaHistoryTranslationMessages> : First extends 'ra-realtime' ? Merge<MergeModuleTranslations<Rest, MergedTranslations>, RaRealTimeTranslationMessages> : First extends 'ra-relationships' ? Merge<MergeModuleTranslations<Rest, MergedTranslations>, RaRelationshipsTranslationMessages> : First extends 'ra-form-layout' ? Merge<MergeModuleTranslations<Rest, MergedTranslations>, RaFormLayoutTranslationMessages> : First extends 'ra-soft-delete' ? Merge<MergeModuleTranslations<Rest, MergedTranslations>, RaSoftDeleteTranslationMessages> : MergedTranslations : MergedTranslations;
export type RaCoreEETranslations<Modules extends Module[]> = Simplify<MergeModuleTranslations<Modules>>;
export {};
//# sourceMappingURL=types.d.ts.map