import { Module, RaCoreEETranslations } from './types';
export declare const getEnglishTranslations: <Modules extends Module[]>(...modules: Modules) => RaCoreEETranslations<Modules>;
//# sourceMappingURL=getEnglishTranslations.d.ts.map