export declare const concerts: {
    id: number;
    artist: string;
    date: string;
    city: string;
    country: string;
    venue: string;
}[];
export declare const farmProducts: ({
    id: number;
    product: string;
    farmer: string;
    location: string;
    price_per_kg: number;
    harvest_date: string;
    certified_organic: boolean;
    price_per_dozen?: undefined;
    price_per_jar?: undefined;
    price_per_liter?: undefined;
    price_per_bunch?: undefined;
    price_per_piece?: undefined;
} | {
    id: number;
    product: string;
    farmer: string;
    location: string;
    price_per_dozen: number;
    harvest_date: string;
    certified_organic: boolean;
    price_per_kg?: undefined;
    price_per_jar?: undefined;
    price_per_liter?: undefined;
    price_per_bunch?: undefined;
    price_per_piece?: undefined;
} | {
    id: number;
    product: string;
    farmer: string;
    location: string;
    price_per_jar: number;
    harvest_date: string;
    certified_organic: boolean;
    price_per_kg?: undefined;
    price_per_dozen?: undefined;
    price_per_liter?: undefined;
    price_per_bunch?: undefined;
    price_per_piece?: undefined;
} | {
    id: number;
    product: string;
    farmer: string;
    location: string;
    price_per_liter: number;
    harvest_date: string;
    certified_organic: boolean;
    price_per_kg?: undefined;
    price_per_dozen?: undefined;
    price_per_jar?: undefined;
    price_per_bunch?: undefined;
    price_per_piece?: undefined;
} | {
    id: number;
    product: string;
    farmer: string;
    location: string;
    price_per_bunch: number;
    harvest_date: string;
    certified_organic: boolean;
    price_per_kg?: undefined;
    price_per_dozen?: undefined;
    price_per_jar?: undefined;
    price_per_liter?: undefined;
    price_per_piece?: undefined;
} | {
    id: number;
    product: string;
    farmer: string;
    location: string;
    price_per_piece: number;
    harvest_date: string;
    certified_organic: boolean;
    price_per_kg?: undefined;
    price_per_dozen?: undefined;
    price_per_jar?: undefined;
    price_per_liter?: undefined;
    price_per_bunch?: undefined;
})[];
//# sourceMappingURL=dummy-data.d.ts.map