import { DataProvider, RaRecord } from 'ra-core';
import { CreateManyParams, CreateManyResult } from './types';
/**
 * Make a default createMany using the provided data provider.
 * @param dataProvider
 */
export declare const defaultCreateMany: <ResourceType extends string = string>(dataProvider: DataProvider<ResourceType>) => <RecordType extends RaRecord = any>(resource: ResourceType, { data, ...params }: CreateManyParams<RecordType>) => Promise<CreateManyResult<RecordType>>;
//# sourceMappingURL=createMany.d.ts.map