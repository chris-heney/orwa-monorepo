import { QueryClient, QueryKey } from '@tanstack/react-query';
import { Identifier, RaRecord } from 'ra-core';
import { DeletedRecordType } from './types';
export declare const deleteFromCollection: <RecordType extends RaRecord = any>(old: RecordType[], id: Identifier) => RecordType[];
export declare const updateListsCacheOnDeletion: <ResourceType extends string = string, RecordType extends RaRecord = any>({ queryClient, resource, ids, undoable, }: {
    queryClient: QueryClient;
    resource: ResourceType;
    ids: Identifier[];
    undoable: boolean;
}) => void;
export declare const updateGetOneCache: <ResourceType extends string = string, RecordType extends RaRecord = any>({ queryClient, resource, id, data, meta, undoable, }: {
    queryClient: QueryClient;
    resource: ResourceType;
    id: Identifier;
    data: Partial<RecordType>;
    meta: any;
    undoable: boolean;
}) => void;
export declare const updateListDeletedCacheOnDeletion: <RecordType extends RaRecord = any>({ queryClient, ids, undoable, }: {
    queryClient: QueryClient;
    ids: Identifier[];
    undoable: boolean;
}) => void;
export declare const updateGetOneDeletedCacheOnDeletion: ({ queryClient, id, meta, undoable, }: {
    queryClient: QueryClient;
    id: Identifier;
    meta: any;
    undoable: boolean;
}) => void;
export declare const updateGetOneDeletedCache: <RecordType extends RaRecord = any>({ queryClient, id, data, meta, undoable, }: {
    queryClient: QueryClient;
    id: Identifier;
    data: Partial<DeletedRecordType<RecordType>>;
    meta: any;
    undoable: boolean;
}) => void;
export type CacheSnapshot = [key: QueryKey, value: any][];
/**
 * Snapshot the previous values via queryClient.getQueriesData()
 *
 * The snapshotData ref will contain an array of tuples [query key, associated data]
 *
 * @example
 * [
 *   [['posts', 'getList'], { data: [{ id: 1, title: 'Hello' }], total: 1 }],
 *   [['posts', 'getMany'], [{ id: 1, title: 'Hello' }]],
 * ]
 *
 * @see https://tanstack.com/query/v5/docs/react/reference/QueryClient#queryclientgetqueriesdata
 */
export declare const createSnapshot: (queryClient: QueryClient, queryKeys: QueryKey[]) => CacheSnapshot;
export declare const applySnapshot: (queryClient: QueryClient, cacheSnapshot: CacheSnapshot) => void;
//# sourceMappingURL=cache.d.ts.map