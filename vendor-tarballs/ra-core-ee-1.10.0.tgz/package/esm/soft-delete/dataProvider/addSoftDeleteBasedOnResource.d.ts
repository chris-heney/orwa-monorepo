import { DataProvider } from 'ra-core';
import { SoftDeleteDataProvider } from './types';
/**
 * Add soft delete based on a resource for a provided data provider.
 * All soft deleted records will be stored in the configured resource (`deleted_records` by default).
 */
export declare function addSoftDeleteBasedOnResource<ResourceType extends string = string>(dataProvider: DataProvider<ResourceType>, { deletedRecordsResourceName, }?: {
    deletedRecordsResourceName: ResourceType | string;
}): SoftDeleteDataProvider<ResourceType>;
//# sourceMappingURL=addSoftDeleteBasedOnResource.d.ts.map