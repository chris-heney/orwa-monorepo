import { CreateParams, CreateResult, DataProvider, DeleteManyParams, DeleteManyResult, DeleteParams, DeleteResult, GetListParams, GetListResult, GetOneParams, GetOneResult, Identifier, QueryFunctionContext, RaRecord } from 'ra-core';
export interface DeletedRecordType<DeletedDataType extends RaRecord = any> extends RaRecord {
    resource: string;
    deleted_at: string;
    deleted_by: Identifier;
    data: DeletedDataType;
}
export type CreateManyParams<T = any> = {
    data: Partial<T>[];
    meta?: any;
};
export type CreateManyResult<RecordType extends RaRecord = any> = {
    data: RecordType[];
    meta?: any;
};
export type SoftDeleteParams<RecordType extends RaRecord = any> = DeleteParams<RecordType> & {
    authorId: Identifier;
};
export type SoftDeleteResult<RecordType extends RaRecord = any> = DeleteResult<RecordType> & {
    deletedRecord: DeletedRecordType<RecordType>;
};
export type SoftDeleteManyParams<RecordType extends RaRecord = any> = DeleteManyParams<RecordType> & {
    authorId: Identifier;
};
export type SoftDeleteManyResult<RecordType extends RaRecord = any> = DeleteManyResult<RecordType> & {
    deletedRecords: DeletedRecordType<RecordType>[];
};
export type GetOneDeletedParams<DeletedDataType extends RaRecord = any> = GetOneParams<DeletedRecordType<DeletedDataType>>;
export type GetOneDeletedResult<DeletedDataType extends RaRecord = any> = GetOneResult<DeletedRecordType<DeletedDataType>>;
export type GetListDeletedParams = GetListParams;
export type GetListDeletedResult<DeletedDataType extends RaRecord = any> = GetListResult<DeletedRecordType<DeletedDataType>>;
export type RestoreOneParams<DeletedDataType extends RaRecord = any> = Omit<CreateParams<DeletedRecordType<DeletedDataType>>, 'data'> & {
    id: DeletedRecordType<DeletedDataType>['id'];
};
export type RestoreOneResult<DeletedDataType extends RaRecord = any> = CreateResult<DeletedRecordType<DeletedDataType>>;
export type RestoreManyParams<DeletedDataType extends RaRecord = any> = {
    meta?: any;
    ids: DeletedRecordType<DeletedDataType>['id'][];
};
export type RestoreManyResult<DeletedDataType extends RaRecord = any> = {
    data: DeletedRecordType<DeletedDataType>[];
    meta?: any;
};
export type HardDeleteParams<RecordType extends RaRecord = any> = DeleteParams<DeletedRecordType<RecordType>>;
export type HardDeleteResult<RecordType extends RaRecord = any> = DeleteResult<DeletedRecordType<RecordType>>;
export type HardDeleteManyParams<RecordType extends RaRecord = any> = DeleteManyParams<DeletedRecordType<RecordType>>;
export type HardDeleteManyResult<RecordType extends RaRecord = any> = DeleteManyResult<DeletedRecordType<RecordType>>;
export interface SoftDeleteDataProvider<ResourceType extends string = string> extends DataProvider<ResourceType> {
    createMany?: <RecordType extends RaRecord = any>(resource: ResourceType, params: CreateManyParams<RecordType>) => Promise<CreateManyResult<RecordType>>;
    softDelete: <RecordType extends RaRecord = any>(resource: ResourceType, params: SoftDeleteParams<RecordType>) => Promise<SoftDeleteResult<RecordType>>;
    softDeleteMany: <RecordType extends RaRecord = any>(resource: ResourceType, params: SoftDeleteManyParams<RecordType>) => Promise<SoftDeleteManyResult<RecordType>>;
    getOneDeleted: <RecordType extends RaRecord = any>(params: GetOneDeletedParams<RecordType> & QueryFunctionContext) => Promise<GetOneDeletedResult<RecordType>>;
    getListDeleted: <RecordType extends RaRecord = any>(params: GetListDeletedParams & QueryFunctionContext) => Promise<GetListDeletedResult<RecordType>>;
    restoreOne: <RecordType extends RaRecord = any>(params: RestoreOneParams<RecordType>) => Promise<RestoreOneResult<RecordType>>;
    restoreMany: <RecordType extends RaRecord = any>(params: RestoreManyParams<RecordType>) => Promise<RestoreManyResult<RecordType>>;
    hardDelete: <RecordType extends RaRecord = any>(params: HardDeleteParams<RecordType>) => Promise<HardDeleteResult<RecordType>>;
    hardDeleteMany: <RecordType extends RaRecord = any>(params: HardDeleteManyParams<RecordType>) => Promise<HardDeleteManyResult<RecordType>>;
}
//# sourceMappingURL=types.d.ts.map