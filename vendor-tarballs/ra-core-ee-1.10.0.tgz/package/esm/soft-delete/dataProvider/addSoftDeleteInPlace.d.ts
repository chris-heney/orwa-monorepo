import { DataProvider, GetListParams, GetListResult, GetManyParams, GetOneParams, Identifier, QueryFunctionContext, RaRecord } from 'ra-core';
import { DeletedRecordType, GetListDeletedParams, HardDeleteManyParams, HardDeleteParams, RestoreManyParams, RestoreOneParams, SoftDeleteManyParams, SoftDeleteParams } from './types';
/**
 * Add soft delete based on a `deleted_at` field in the same resource.
 * All soft deleted records will be stored in the same resource, with a not null `deleted_at`.
 */
export declare function addSoftDeleteInPlace<ResourceType extends string = string>(dataProvider: DataProvider<ResourceType>, resourcesWithSoftDelete?: Record<string, {
    deletedAtFieldName?: string;
    deletedByFieldName?: string;
}>): {
    getOne: <RecordType extends RaRecord = any>(resource: ResourceType, params: GetOneParams<RecordType> & QueryFunctionContext) => Promise<import("ra-core").GetOneResult<RecordType>>;
    getMany: <RecordType extends RaRecord = any>(resource: ResourceType, params: GetManyParams<RecordType> & QueryFunctionContext) => Promise<import("ra-core").GetManyResult<RecordType>>;
    getList: <RecordType extends RaRecord = any>(resource: ResourceType, params: GetListParams & QueryFunctionContext) => Promise<GetListResult<RecordType>>;
    softDelete: <DeletedDataType extends RaRecord = any>(resource: ResourceType, { authorId, previousData, ...params }: SoftDeleteParams<DeletedDataType>) => Promise<{
        data: DeletedDataType;
        deletedRecord: DeletedRecordType<any>;
        meta?: any;
    }>;
    softDeleteMany: <DeletedDataType extends RaRecord = any>(resource: ResourceType, { authorId, ...params }: SoftDeleteManyParams<DeletedDataType>) => Promise<{
        data: Identifier[];
        deletedRecords: DeletedRecordType<DeletedDataType>[];
        meta?: any;
    }>;
    getOneDeleted: (params: any) => Promise<{
        data: DeletedRecordType<any>;
        meta?: any;
    }>;
    getListDeleted: (params: GetListDeletedParams) => Promise<{
        data: DeletedRecordType<any>[];
        total?: number;
        pageInfo?: {
            hasNextPage?: boolean;
            hasPreviousPage?: boolean;
        };
        meta?: any;
    }>;
    restoreOne: <DeletedDataType extends RaRecord = any>({ id, ...params }: RestoreOneParams<DeletedDataType>) => Promise<{
        data: DeletedRecordType<any>;
        meta?: any;
    }>;
    restoreMany: <DeletedDataType extends RaRecord = any>({ ids, ...params }: RestoreManyParams<DeletedDataType>) => Promise<{
        data: DeletedRecordType<any>[];
    }>;
    hardDelete: <DeletedDataType extends RaRecord = any>(params: HardDeleteParams<DeletedDataType>) => Promise<{
        data: DeletedRecordType<DeletedRecordType<DeletedDataType>>;
        meta?: any;
    }>;
    hardDeleteMany: <DeletedDataType extends RaRecord = any>({ ids, ...params }: HardDeleteManyParams<DeletedDataType>) => Promise<{
        data: Identifier[];
        meta: any[];
    }>;
    getManyReference: <RecordType extends RaRecord = any>(resource: ResourceType, params: import("ra-core").GetManyReferenceParams & QueryFunctionContext) => Promise<import("ra-core").GetManyReferenceResult<RecordType>>;
    update: <RecordType extends RaRecord = any>(resource: ResourceType, params: import("ra-core").UpdateParams) => Promise<import("ra-core").UpdateResult<RecordType>>;
    updateMany: <RecordType extends RaRecord = any>(resource: ResourceType, params: import("ra-core").UpdateManyParams) => Promise<import("ra-core").UpdateManyResult<RecordType>>;
    create: <RecordType extends Omit<RaRecord, "id"> = any, ResultRecordType extends RaRecord = RecordType & {
        id: Identifier;
    }>(resource: ResourceType, params: import("ra-core").CreateParams) => Promise<import("ra-core").CreateResult<ResultRecordType>>;
    delete: <RecordType extends RaRecord = any>(resource: ResourceType, params: import("ra-core").DeleteParams<RecordType>) => Promise<import("ra-core").DeleteResult<RecordType>>;
    deleteMany: <RecordType extends RaRecord = any>(resource: ResourceType, params: import("ra-core").DeleteManyParams<RecordType>) => Promise<import("ra-core").DeleteManyResult<RecordType>>;
    supportAbortSignal?: boolean;
};
//# sourceMappingURL=addSoftDeleteInPlace.d.ts.map