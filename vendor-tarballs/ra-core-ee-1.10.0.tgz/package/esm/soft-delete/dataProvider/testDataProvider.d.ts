import { SoftDeleteDataProvider } from './types';
export declare const testDataProvider: (overrides?: Partial<SoftDeleteDataProvider>) => SoftDeleteDataProvider;
//# sourceMappingURL=testDataProvider.d.ts.map