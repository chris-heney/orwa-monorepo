import { ReactEventHandler, SyntheticEvent } from 'react';
import { UseMutationOptions } from '@tanstack/react-query';
import { MutationMode, RaRecord, RedirectionSideEffect } from 'ra-core';
import { DeletedRecordType, HardDeleteManyParams } from '../dataProvider';
/**
 * Prepare a set of callbacks for a bulk delete permanently button guarded by confirmation dialog
 *
 * @example
 *
 * const BulkDeletePermanentlyButton = ({
 *     redirect,
 *     onClick,
 *     ...rest
 * }) => {
 *     const {
 *         ids,
 *         open,
 *         isPending,
 *         handleDialogOpen,
 *         handleDialogClose,
 *         handleDeleteManyPermanently,
 *     } = useBulkDeletePermanentlyWithConfirmController({
 *         redirect,
 *         onClick,
 *     });
 *
 *     return (
 *         <Fragment>
 *             <Button
 *                 onClick={handleDialogOpen}
 *                 label="ra.action.delete"
 *                 {...rest}
 *             >
 *                 {icon}
 *             </Button>
 *             <Confirm
 *                 isOpen={open}
 *                 loading={isPending}
 *                 title="ra.message.delete_title"
 *                 content="ra.message.delete_content"
 *                 titleTranslateOptions={{
 *                     smart_count: ids.length,
 *                 }}
 *                 contentTranslateOptions={{
 *                     smart_count: ids.length,
 *                 }}
 *                 onConfirm={handleDeleteManyPermanently}
 *                 onClose={handleDialogClose}
 *             />
 *         </Fragment>
 *     );
 * };
 */
export declare const useBulkDeletePermanentlyWithConfirmController: <RecordType extends RaRecord = any, ErrorType = Error>(props: UseBulkDeletePermanentlyWithConfirmControllerParams<RecordType, ErrorType>) => UseBulkDeletePermanentlyWithConfirmControllerReturn<RecordType>;
export interface UseBulkDeletePermanentlyWithConfirmControllerParams<RecordType extends RaRecord = any, MutationOptionsError = unknown> {
    mutationMode?: MutationMode;
    redirect?: RedirectionSideEffect;
    ids?: DeletedRecordType<RecordType>['id'][];
    onClick?: ReactEventHandler<any>;
    mutationOptions?: UseMutationOptions<DeletedRecordType<RecordType>['id'][], MutationOptionsError, HardDeleteManyParams<RecordType>>;
    successMessage?: string;
}
export interface UseBulkDeletePermanentlyWithConfirmControllerReturn<RecordType extends RaRecord = any> {
    ids: DeletedRecordType<RecordType>['id'][];
    open: boolean;
    isLoading: boolean;
    isPending: boolean;
    handleDialogOpen: (e: SyntheticEvent) => void;
    handleDialogClose: (e: SyntheticEvent) => void;
    handleDeleteManyPermanently: ReactEventHandler<any>;
}
//# sourceMappingURL=useBulkDeletePermanentlyWithConfirmController.d.ts.map