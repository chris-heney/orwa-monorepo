import { ReactEventHandler } from 'react';
import { UseMutationOptions } from '@tanstack/react-query';
import { RaRecord, RedirectionSideEffect } from 'ra-core';
import { DeletedRecordType, HardDeleteManyParams } from '../dataProvider';
/**
 * Prepare a set of callbacks for a bulk delete permanently button with undo support
 *
 * @example
 *
 * const BulkDeletePermanentlyButton = ({
 *     ids,
 *     redirect,
 *     onClick,
 *     ...rest
 * }) => {
 *     const {
 *         isPending,
 *         handleDeleteManyPermanently,
 *     } = useBulkDeletePermanentlyWithUndoController({
 *         ids,
 *         redirect,
 *         onClick,
 *     });
 *
 *     return (
 *         <Button
 *             onClick={handleDeleteManyPermanently}
 *             label="ra.action.delete"
 *             {...rest}
 *         >
 *             {icon}
 *         </Button>
 *     );
 * };
 */
export declare const useBulkDeletePermanentlyWithUndoController: <RecordType extends RaRecord = any, ErrorType = Error>(props: UseBulkDeletePermanentlyWithUndoControllerParams<RecordType, ErrorType>) => UseBulkDeletePermanentlyWithUndoControllerReturn<RecordType>;
export interface UseBulkDeletePermanentlyWithUndoControllerParams<RecordType extends RaRecord = any, MutationOptionsError = unknown> {
    redirect?: RedirectionSideEffect;
    ids?: DeletedRecordType<RecordType>['id'][];
    onClick?: ReactEventHandler<any>;
    mutationOptions?: UseMutationOptions<DeletedRecordType<RecordType>['id'][], MutationOptionsError, HardDeleteManyParams<RecordType>>;
    successMessage?: string;
}
export interface UseBulkDeletePermanentlyWithUndoControllerReturn<RecordType extends RaRecord = any> {
    ids: DeletedRecordType<RecordType>['id'][];
    isLoading: boolean;
    isPending: boolean;
    handleDeleteManyPermanently: ReactEventHandler<any>;
}
//# sourceMappingURL=useBulkDeletePermanentlyWithUndoController.d.ts.map