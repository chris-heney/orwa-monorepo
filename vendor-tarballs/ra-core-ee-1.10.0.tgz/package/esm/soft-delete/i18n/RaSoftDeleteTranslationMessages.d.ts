export interface RaSoftDeleteTranslationMessages {
    'ra-soft-delete': {
        message: {
            bulk_soft_delete_title: string;
            bulk_soft_delete_content: string;
            bulk_delete_permanently_title: string;
            bulk_delete_permanently_content: string;
            bulk_restore_title: string;
            bulk_restore_content: string;
            soft_delete_title: string;
            soft_delete_content: string;
            delete_permanently_title: string;
            delete_permanently_content: string;
            restore_title: string;
            restore_content: string;
        };
        action: {
            restore: string;
            soft_delete: string;
            delete_permanently: string;
        };
        notification: {
            restored: string;
            soft_deleted: string;
            deleted_permanently: string;
        };
        deleted_records_list: {
            menu: string;
            title: string;
            resource_title: string;
            resource: string;
            deleted_at: string;
            empty: string;
            no_filtered_results: string;
        };
    };
}
//# sourceMappingURL=RaSoftDeleteTranslationMessages.d.ts.map