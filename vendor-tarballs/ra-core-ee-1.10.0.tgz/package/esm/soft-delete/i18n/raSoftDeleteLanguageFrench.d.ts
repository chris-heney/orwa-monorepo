import { RaSoftDeleteTranslationMessages } from './RaSoftDeleteTranslationMessages';
export declare const raSoftDeleteLanguageFrench: RaSoftDeleteTranslationMessages;
//# sourceMappingURL=raSoftDeleteLanguageFrench.d.ts.map