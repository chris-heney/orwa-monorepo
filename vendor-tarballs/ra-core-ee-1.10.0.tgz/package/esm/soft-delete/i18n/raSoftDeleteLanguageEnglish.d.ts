import { RaSoftDeleteTranslationMessages } from './RaSoftDeleteTranslationMessages';
export declare const raSoftDeleteLanguageEnglish: RaSoftDeleteTranslationMessages;
//# sourceMappingURL=raSoftDeleteLanguageEnglish.d.ts.map