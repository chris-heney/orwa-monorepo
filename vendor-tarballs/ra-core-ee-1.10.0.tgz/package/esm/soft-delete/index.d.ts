export declare const raSoftDeleteResource = "ra-soft-delete";
export * from './controllers';
export * from './dataProvider';
export * from './i18n';
export * from './list';
//# sourceMappingURL=index.d.ts.map