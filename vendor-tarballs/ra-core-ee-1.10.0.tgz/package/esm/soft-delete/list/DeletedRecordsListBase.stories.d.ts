import { DeletedRecordsListBaseProps } from './DeletedRecordsListBase';
declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: (props: DeletedRecordsListBaseProps) => import("react/jsx-runtime").JSX.Element;
export declare const Empty: () => import("react/jsx-runtime").JSX.Element;
export declare const WithResource: (props: DeletedRecordsListBaseProps) => import("react/jsx-runtime").JSX.Element;
export declare const FullApp: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DeletedRecordsListBase.stories.d.ts.map