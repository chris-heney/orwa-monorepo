import { DeletedRecordType } from '../dataProvider';
export declare const DeletedRecordRepresentation: (props: {
    deletedRecord?: DeletedRecordType;
    record?: DeletedRecordType;
}) => import("react").ReactNode;
//# sourceMappingURL=DeletedRecordRepresentation.d.ts.map