import * as React from 'react';
import { DeletedRecordType } from '../dataProvider/types';
/**
 * Page component for the view of a deleted record.
 */
export declare const ShowDeletedBase: (props: ShowDeletedBaseProps) => import("react/jsx-runtime").JSX.Element;
export interface ShowDeletedBaseProps {
    children: React.ReactNode;
    record?: DeletedRecordType;
}
//# sourceMappingURL=ShowDeletedBase.d.ts.map