import React, { ReactNode } from 'react';
import { ListControllerSuccessResult, RaRecord } from 'ra-core';
import { DeletedRecordsListControllerParams, DeletedRecordType } from '..';
export declare const DeletedRecordsListBase: <RecordType extends RaRecord = any>({ emptyWhileLoading, authLoading, loading, offline, error, empty, children, render, ...props }: DeletedRecordsListBaseProps) => import("react/jsx-runtime").JSX.Element;
export interface DeletedRecordsListBaseProps<RecordType extends RaRecord = any> extends DeletedRecordsListControllerParams<RecordType> {
    emptyWhileLoading?: boolean;
    authLoading?: ReactNode;
    loading?: ReactNode;
    offline?: ReactNode;
    error?: ReactNode;
    empty?: ReactNode;
    children?: React.ReactNode;
    render?: (context: ListControllerSuccessResult<DeletedRecordType<RecordType>>) => React.ReactNode;
}
//# sourceMappingURL=DeletedRecordsListBase.d.ts.map