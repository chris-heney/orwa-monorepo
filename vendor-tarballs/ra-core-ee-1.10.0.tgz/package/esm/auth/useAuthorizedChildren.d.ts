import { ReactElement, ReactNode } from 'react';
import { UseCanAccessResourcesResult } from 'ra-core';
/**
 * A hook that filters children based on the user's permissions.
 * Note that it requires the children to be valid React elements and having a `source` prop.
 * It will always render children that are not React elements or that do not have a `source` prop.
 * @param options {Object} The hook props
 * @param options.children {ReactNode} The children to filter
 * @param options.action {string} The action to check for. Defaults to 'read'
 * @param options.record {Object} The record to check for. Defaults to the record from RecordContext
 * @param options.resource {string} The resource to check for. Defaults to the resource from ResourceContext
 * @param options.getResourceKey {Function} A function to get the resource key from a child. Defaults to `${resource}.${child.props.source}`
 * @param options.filterChildren {Function} A function to filter children for which to check permissions. Defaults to `child => child.props.source != null`
 * @returns {Object} An array of the children users have access to, the pending state, and the error
 *
 * @example
 * // in src/MyCustomShowLayout.tsx
 * import * as React from 'react';
 * import { useAuthorizedChildren } from '@react-admin/ra-core-ee';
 * import { Stack } from 'react-admin';
 *
 * const MyCustomShowLayout = ({ children }: { children: React.ReactNode }) => {
 *   const { authorizedChildren, isPending, error } = useAuthorizedChildren({
 *     children,
 *   });
 *   if (error) {
 *     return <div>Error</div>;
 *   }
 *   if (isPending) {
 *     return <div>Loading...</div>;
 *   }
 *   return (
 *     <Stack>
 *       {authorizedChildren}
 *     </Stack>
 *   );
 * };
 *
 * // in src/posts/PostShow.tsx
 * import * as React from 'react';
 * import { TextField, Show } from 'react-admin';
 * import { MyCustomShowLayout } from '../MyCustomShowLayout';
 *
 * export const PostShow = (props) => (
 *   <Show>
 *     <MyCustomShowLayout>
 *       <TextField source="title" />
 *       <TextField source="body" />
 *     </MyCustomShowLayout>
 *   </Show>
 */
export declare const useAuthorizedChildren: (options: UseAuthorizedChildrenProps) => UseAuthorizedChildrenResult;
export interface UseAuthorizedChildrenProps {
    children: ReactNode;
    enabled?: boolean;
    action?: string;
    record?: any;
    resource?: string;
    getResourceKey?: UseAuthorizedChildrenGetResourceKey;
    filterChildren?: UseAuthorizedChildrenFilterChildren;
}
export type UseAuthorizedChildrenGetResourceKey = (child: ReactElement<any>, resource: string) => string;
export type UseAuthorizedChildrenFilterChildren = (child: ReactElement<any>, resource: string) => boolean;
export interface UseAuthorizedChildrenResult extends Pick<UseCanAccessResourcesResult, 'error' | 'isPending'> {
    authorizedChildren: ReactNode;
}
//# sourceMappingURL=useAuthorizedChildren.d.ts.map