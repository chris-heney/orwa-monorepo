import { Meta } from '@storybook/react';
declare const _default: Meta;
export default _default;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomResourceKey: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomFilter: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=useAuthorizedChildren.stories.d.ts.map