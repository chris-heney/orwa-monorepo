import type { Permission, Permissions } from './types';
/**
 * Checks if an array of permissions allows to execute the given action on the given resource.
 *
 * @example
 * canAccess({
 *     permissions: [
 *         { resource: 'user', action: 'read' },
 *         { resource: 'posts', action: ['read', 'edit', 'create', 'delete'] },
 *     ],
 *     action: "edit",
 *     resource: "posts"
 * }); // true
 */
export declare const canAccessWithPermissions: ({ permissions, action, resource, record, }: {
    permissions: Permissions;
    action?: string;
    resource: string;
    record?: any;
}) => boolean;
/**
 * @deprecated use canAccessWithPermissions instead
 */
export declare const canAccess: ({ permissions, action, resource, record, }: {
    permissions: Permissions;
    action?: string;
    resource: string;
    record?: any;
}) => boolean;
/**
 * Checks is a permission matches a target (action, resource, record)
 *
 * @example
 * matchTarget({ resource: 'user', action: 'read' }, 'user', 'read'); // true
 * matchTarget({ resource: 'user', action: 'read' }, 'user', 'edit'); // false
 */
export declare const matchTarget: (permission: Permission, resource: string, action?: string, record?: any) => boolean;
/**
 * Checks if a permission matches a wildcard.
 *
 * @param permission The permission to check, e.g. 'posts.*'
 * @param resource The resource to check, e.g. 'posts'
 *
 * @example
 * matchWildCard('*', 'posts'); // true
 * matchWildCard('posts', 'posts'); // true
 * matchWildcard('posts.*', 'posts'); // true
 * matchWildcard('comments', 'posts'); // false
 */
export declare const matchWildcard: (pattern: string, resource: string) => boolean;
//# sourceMappingURL=canAccessWithPermissions.d.ts.map