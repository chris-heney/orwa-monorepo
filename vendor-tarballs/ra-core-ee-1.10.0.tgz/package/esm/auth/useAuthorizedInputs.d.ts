import type { UseAuthorizedChildrenProps, UseAuthorizedChildrenResult } from './useAuthorizedChildren';
export declare const useAuthorizedInputs: (options: UseAuthorizedInputsProps) => UseAuthorizedChildrenResult;
export interface UseAuthorizedInputsProps extends Omit<UseAuthorizedChildrenProps, 'action'> {
    showReadOnly?: boolean;
}
//# sourceMappingURL=useAuthorizedInputs.d.ts.map