import { Meta } from '@storybook/react';
declare const _default: Meta;
export default _default;
export declare const DatagridColumns: () => import("react/jsx-runtime").JSX.Element;
export declare const Pages: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=canAccessWithPermissions.stories.d.ts.map