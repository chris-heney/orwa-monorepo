export interface Permission {
    /**
     * @default 'allow'
     */
    type?: 'allow' | 'deny';
    action: string | string[];
    resource: string | string[];
    record?: any;
}
export type Permissions = Permission[];
export type Roles = string[];
export type RoleDefinitions<T extends string = string> = Record<T, Permissions>;
//# sourceMappingURL=types.d.ts.map