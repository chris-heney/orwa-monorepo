declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: {
    ({ dataProvider, resource, source, reference, through, using, }: {
        dataProvider?: import("ra-core").DataProvider | undefined;
        resource: any;
        source: any;
        reference: any;
        through: any;
        using: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        resource: string;
        reference: string;
        through: string;
        using: string;
        source: string;
    };
};
export declare const FilterChoices: ({ dataProvider }: {
    dataProvider?: import("ra-core").DataProvider | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export declare const Undoable: {
    ({ dataProvider, resource, source, reference, through, using, }: {
        dataProvider?: import("ra-core").DataProvider | undefined;
        resource: any;
        source: any;
        reference: any;
        through: any;
        using: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        resource: string;
        reference: string;
        through: string;
        using: string;
        source: string;
    };
};
//# sourceMappingURL=ReferenceManyToManyInputBase.WithFilters.stories.d.ts.map