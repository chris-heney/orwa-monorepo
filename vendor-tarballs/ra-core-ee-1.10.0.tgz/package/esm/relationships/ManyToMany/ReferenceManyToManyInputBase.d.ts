import { ReactElement } from 'react';
import { InputProps, RaRecord, SortPayload } from 'ra-core';
import { UseReferenceManyToManyInputControllerOptions } from './useReferenceManyToManyInputController';
/**
 * Allows to edit reference records through a relations table.
 *
 * You must define the fields to be passed to the iterator component as children.
 *
 * @example Allowing to pick the tags of a post using a SelectArrayInput
 *  <ReferenceManyToManyInputBase
 *      label="Posts"
 *      reference="posts"
 *      through="posts_tags"
 *      using="tag_id,post_id"
 *  >
 *      <SelectArrayInput optionText="name" />
 *  </ReferenceManyToManyInputBase>
 *
 * @example Allowing to pick the tags of a post using a CheckboxGroupInput
 *  <ReferenceManyToManyInputBase
 *      label="Posts"
 *      reference="posts"
 *      through="posts_tags"
 *      using"tag_id,post_id"
 *  >
 *      <CheckboxGroupInput optionText="name" />
 *  </ReferenceManyToManyInputBase>
 */
export declare const ReferenceManyToManyInputBase: <RecordType extends RaRecord = RaRecord<import("ra-core").Identifier>>({ children, sort, ...props }: ReferenceManyToManyInputBaseProps<RecordType>) => import("react/jsx-runtime").JSX.Element;
export interface ReferenceManyToManyInputBaseProps<RecordType extends RaRecord = RaRecord> extends UseReferenceManyToManyInputControllerOptions<RecordType>, Omit<InputProps, 'source'> {
    children: ReactElement;
    filter?: Record<string, unknown>;
    perPage?: number;
    reference: string;
    sort?: SortPayload;
    through: string;
    using: string;
}
//# sourceMappingURL=ReferenceManyToManyInputBase.d.ts.map