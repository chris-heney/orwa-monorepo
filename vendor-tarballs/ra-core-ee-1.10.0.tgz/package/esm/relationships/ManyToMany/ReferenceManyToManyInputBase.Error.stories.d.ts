import { DataProvider } from 'ra-core';
declare const _default: {
    title: string;
};
export default _default;
export declare const Error: {
    ({ shouldFailMainMutation, shouldFailReferenceMutation, serverValidationErrorOnReferenceMutation, shouldFailDeleteMany, serverValidationErrorOnDeleteMany, customOnError, customOnErrorInput, createOnError, inputOnError, editOnError, editMutationMode, dataProvider, redirect, }: {
        shouldFailMainMutation?: boolean;
        shouldFailReferenceMutation?: boolean;
        serverValidationErrorOnReferenceMutation?: boolean;
        shouldFailDeleteMany?: boolean;
        serverValidationErrorOnDeleteMany?: boolean;
        customOnError?: boolean;
        customOnErrorInput?: boolean;
        createOnError?: (error: any, data: any) => void;
        inputOnError?: (error: any, step: string, data: any) => void;
        editOnError?: (error: any, data: any) => void;
        editMutationMode?: "pessimistic" | "optimistic";
        dataProvider?: DataProvider;
        redirect?: "list" | false;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        shouldFailMainMutation: boolean;
        shouldFailReferenceMutation: boolean;
        shouldFailDeleteMany: boolean;
        serverValidationErrorOnReferenceMutation: boolean;
        serverValidationErrorOnDeleteMany: boolean;
        customOnError: boolean;
        customOnErrorInput: boolean;
        editMutationMode: string;
    };
    argTypes: {
        shouldFailMainMutation: {
            control: {
                type: string;
            };
        };
        shouldFailReferenceMutation: {
            control: {
                type: string;
            };
        };
        shouldFailDeleteMany: {
            control: {
                type: string;
            };
        };
        serverValidationErrorOnReferenceMutation: {
            control: {
                type: string;
            };
        };
        serverValidationErrorOnDeleteMany: {
            control: {
                type: string;
            };
        };
        customOnError: {
            control: {
                type: string;
            };
        };
        customOnErrorInput: {
            control: {
                type: string;
            };
        };
        editMutationMode: {
            control: {
                type: string;
            };
            options: string[];
        };
        redirect: {
            control: {
                type: string;
            };
            options: (string | boolean)[];
            mapping: {
                list: string;
                false: boolean;
            };
        };
    };
};
//# sourceMappingURL=ReferenceManyToManyInputBase.Error.stories.d.ts.map