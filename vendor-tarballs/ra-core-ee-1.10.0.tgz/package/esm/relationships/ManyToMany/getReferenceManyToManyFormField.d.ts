export declare const getReferenceManyToManyFormField: ({ resource, through, reference, }: Options) => string;
interface Options {
    reference: string;
    resource: string;
    through: string;
}
export {};
//# sourceMappingURL=getReferenceManyToManyFormField.d.ts.map