export declare const ReferenceManyToManyUsingRegexp: RegExp;
export declare const ReferenceManyToManyFieldPrefix = "@@ra-many-to-many/";
//# sourceMappingURL=constants.d.ts.map