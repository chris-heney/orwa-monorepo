import { ReferenceManyToManyInputBaseProps } from '..';
declare const _default: {
    title: string;
};
export default _default;
export declare const LoadedWithData: {
    ({ resource, source, reference, through, using, dataProvider: dataProviderProp, queryOptions, mutationOptions, }: {
        resource: any;
        source: any;
        reference: any;
        through: any;
        using: any;
        dataProvider?: import("ra-core").DataProvider | undefined;
        queryOptions?: undefined;
        mutationOptions?: undefined;
    }): import("react/jsx-runtime").JSX.Element;
    args: Partial<ReferenceManyToManyInputBaseProps<import("ra-core").RaRecord<import("ra-core").Identifier>>>;
};
export declare const WithDefaultValue: {
    ({ resource, source, reference, through, using, }: {
        resource: any;
        source: any;
        reference: any;
        through: any;
        using: any;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        resource: string;
        reference: string;
        through: string;
        using: string;
        source: string;
    };
};
export declare const Meta: {
    (props: any): import("react/jsx-runtime").JSX.Element;
    args: {
        resource: string;
        reference: string;
        through: string;
        using: string;
        source: string;
        queryOptions: {
            meta: {
                foo: string;
            };
        };
        mutationOptions: {
            meta: {
                foo: string;
            };
        };
    };
};
//# sourceMappingURL=ReferenceManyToManyInputBase.stories.d.ts.map