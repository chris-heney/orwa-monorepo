declare const BandEdit: () => import("react/jsx-runtime").JSX.Element;
export default BandEdit;
//# sourceMappingURL=BandEdit.d.ts.map