declare const BandShow: () => import("react/jsx-runtime").JSX.Element;
export default BandShow;
//# sourceMappingURL=BandShow.d.ts.map