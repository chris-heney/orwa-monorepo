declare const BandList: () => import("react/jsx-runtime").JSX.Element;
export default BandList;
//# sourceMappingURL=BandList.d.ts.map