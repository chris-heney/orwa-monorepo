declare const BandCreate: () => import("react/jsx-runtime").JSX.Element;
export default BandCreate;
//# sourceMappingURL=BandCreate.d.ts.map