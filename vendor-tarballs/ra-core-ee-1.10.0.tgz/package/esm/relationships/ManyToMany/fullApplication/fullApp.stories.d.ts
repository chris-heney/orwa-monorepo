import { QueryClient } from '@tanstack/react-query';
import { DataProvider } from 'ra-core';
declare const _default: {
    title: string;
};
export default _default;
export declare const FullApplication: ({ dataProvider, queryClient, }: {
    dataProvider?: DataProvider;
    queryClient?: QueryClient;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DelayedDataProvider: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=fullApp.stories.d.ts.map