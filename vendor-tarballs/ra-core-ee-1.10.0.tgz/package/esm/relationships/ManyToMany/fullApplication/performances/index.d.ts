declare const _default: {
    list: () => import("react/jsx-runtime").JSX.Element;
};
export default _default;
//# sourceMappingURL=index.d.ts.map