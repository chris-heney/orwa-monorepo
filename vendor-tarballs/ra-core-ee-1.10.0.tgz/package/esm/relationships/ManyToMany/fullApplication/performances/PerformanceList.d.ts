declare const PerformanceList: () => import("react/jsx-runtime").JSX.Element;
export default PerformanceList;
//# sourceMappingURL=PerformanceList.d.ts.map