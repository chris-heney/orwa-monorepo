declare const ArtistCreate: () => import("react/jsx-runtime").JSX.Element;
export default ArtistCreate;
//# sourceMappingURL=ArtistCreate.d.ts.map