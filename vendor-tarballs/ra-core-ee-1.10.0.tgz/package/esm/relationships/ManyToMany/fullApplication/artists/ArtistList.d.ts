declare const BandList: () => import("react/jsx-runtime").JSX.Element;
export default BandList;
//# sourceMappingURL=ArtistList.d.ts.map