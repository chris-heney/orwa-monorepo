declare const ArtistEdit: () => import("react/jsx-runtime").JSX.Element;
export default ArtistEdit;
//# sourceMappingURL=ArtistEdit.d.ts.map