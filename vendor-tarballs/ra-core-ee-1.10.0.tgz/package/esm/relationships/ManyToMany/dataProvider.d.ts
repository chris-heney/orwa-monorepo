declare const dataProvider: (data?: any, delay?: number) => import("ra-core").DataProvider;
export default dataProvider;
//# sourceMappingURL=dataProvider.d.ts.map