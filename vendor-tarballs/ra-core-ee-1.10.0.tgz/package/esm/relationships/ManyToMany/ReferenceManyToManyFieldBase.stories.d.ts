import { ReferenceManyToManyFieldBaseProps } from './ReferenceManyToManyFieldBase';
declare const _default: {
    title: string;
    excludeStories: string[];
};
export default _default;
export declare const dataProvider: import("ra-core").DataProvider;
export declare const WithDataGrid: (additionalArgs: Partial<ReferenceManyToManyFieldBaseProps>) => import("react/jsx-runtime").JSX.Element;
export declare const WithDataGridDesc: () => import("react/jsx-runtime").JSX.Element;
export declare const Meta: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ReferenceManyToManyFieldBase.stories.d.ts.map