import { ReactNode } from 'react';
import { RaRecord } from 'ra-core';
import { UseReferenceManyToManyFieldOptions, UseReferenceManyToManyFieldValue } from './useReferenceManyToManyFieldController';
/**
 * Fetch reference record through a relations table using fields.
 *
 * You must define the fields to be passed to the iterator component as children.
 *
 * @example Display all the posts having the current tag as a datagrid
 *  <ReferenceManyToManyFieldBase
 *      label="Posts"
 *      reference="posts"
 *      through="posts_tags"
 *      using="tag_id,post_id"
 *  >
 *      <DataTable>
 *          <DataTable.Col label="Title" source="title" />
 *          <DataTable.Col label="Body"  source="body" />
 *      </DataTable>
 *  </ReferenceManyToManyFieldBase>
 *
 * @example Display all the tags of the current post as a SingleFieldList
 *  <ReferenceManyToManyFieldBase
 *      label="Tags"
 *      reference="tags"
 *      through="posts_tags"
 *      using="post_id,tag_id"
 *  >
 *      <SingleFieldList>
 *          <TextField label="name" source="name" />
 *      </SingleFieldList>
 *  </ReferenceManyToManyFieldBase>
 */
export declare const ReferenceManyToManyFieldBase: <RecordType extends RaRecord = any>(props: ReferenceManyToManyFieldBaseProps<RecordType>) => import("react/jsx-runtime").JSX.Element;
export interface ReferenceManyToManyFieldBaseProps<RecordType extends RaRecord = any> extends UseReferenceManyToManyFieldOptions<RecordType> {
    children?: ReactNode;
    render?: (props: UseReferenceManyToManyFieldValue<RecordType>) => ReactNode;
    error?: ReactNode;
    loading?: ReactNode;
}
//# sourceMappingURL=ReferenceManyToManyFieldBase.d.ts.map