import { EditBaseProps, DataProvider } from 'ra-core';
declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: ({ dataProvider, EditBaseProps, }: {
    dataProvider?: DataProvider;
    EditBaseProps?: Partial<EditBaseProps>;
}) => import("react/jsx-runtime").JSX.Element;
export declare const CreateView: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const Loading: () => import("react/jsx-runtime").JSX.Element;
export declare const Empty: () => import("react/jsx-runtime").JSX.Element;
export declare const RankSource: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValueInEditView: ({ id }: {
    id?: number | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValueInCreateView: () => import("react/jsx-runtime").JSX.Element;
export declare const Validate: () => import("react/jsx-runtime").JSX.Element;
export declare const NoRedirect: ({ dataProvider, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultI18n: () => import("react/jsx-runtime").JSX.Element;
export declare const FetchError: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const SaveError: ({ dataProvider, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const Meta: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const SetValue: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ReferenceManyInputBase.stories.d.ts.map