import { DataProvider } from 'ra-core';
export declare const rawDataProvider: () => DataProvider;
export declare const dataProvider: (delay?: number, baseDataProvider?: DataProvider) => DataProvider;
//# sourceMappingURL=dataProvider.d.ts.map