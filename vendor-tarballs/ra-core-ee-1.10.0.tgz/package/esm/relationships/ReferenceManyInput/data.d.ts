declare const _default: {
    teachers: {
        id: number;
        name: string;
    }[];
    students: {
        id: number;
        first_name: string;
        last_name: string;
        teacher_id: number;
    }[];
};
export default _default;
//# sourceMappingURL=data.d.ts.map