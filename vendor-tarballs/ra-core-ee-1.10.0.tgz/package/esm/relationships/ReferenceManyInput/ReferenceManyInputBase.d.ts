import * as React from 'react';
import { InputProps } from 'ra-core';
import { UseReferenceManyInputControllerOptions, UseReferenceManyInputControllerValue } from './useReferenceManyInputController';
/**
 * Use `<ReferenceManyInputBase>` in an `<Edit>` or `<Create>` view to edit one-to-many relationships,
 * e.g. to edit the variants of a product in the product edition view.
 *
 * @example
 * import { EditBase, Form, ReferenceInputBase } from 'ra-core';
 * import { TextInput, NumberInput, SelectInput, SimpleFormIterator } from 'my-react-admin-ui-library';
 * import { ReferenceManyInputBase } from '@react-admin/ra-core-ee';
 *
 * const ProductEdit = () => (
 *     <EditBase mutationMode="optimistic">
 *         <Form>
 *             <TextInput source="name" />
 *             <NumberInput source="price" />
 *             <ReferenceInputBase source="category_id" reference="categories" />
 *             <ReferenceManyInputBase reference="variants" target="product_id">
 *                 <SimpleFormIterator inline>
 *                     <TextInput source="sku" />
 *                     <SelectInput source="size" choices={sizes} />
 *                     <SelectInput source="color" choices={colors} />
 *                     <NumberInput source="stock" defaultValue={0} />
 *                 </SimpleFormIterator>
 *             </ReferenceManyInputBase>
 *         </Form>
 *     </EditBase>
 * );
 */
export declare const ReferenceManyInputBase: ({ children, error, loading, render, ...props }: ReferenceManyInputBaseProps) => import("react/jsx-runtime").JSX.Element;
export interface ReferenceManyInputBaseProps extends UseReferenceManyInputControllerOptions, Omit<InputProps, 'source' | 'defaultValue'> {
    children?: React.ReactNode;
    render?: (props: UseReferenceManyInputControllerValue) => React.ReactNode;
    className?: string;
    error?: React.ReactNode;
    loading?: React.ReactNode;
}
//# sourceMappingURL=ReferenceManyInputBase.d.ts.map