export declare const ReferenceManyInputPrefix = "@@ra-many/";
//# sourceMappingURL=constants.d.ts.map