declare const _default: {
    books: {
        id: number;
        title: string;
    }[];
    book_details: ({
        id: number;
        book_id: number;
        year: number;
        author: string;
        country: string;
        genre: string;
        pages: number;
        translations: {
            language: string;
            translator: string;
        }[];
        tag_ids: number[];
    } | {
        id: number;
        book_id: number;
        year: number;
        author: string;
        country: string;
        genre: string;
        pages: number;
        translations?: undefined;
        tag_ids?: undefined;
    })[];
    book_details_reviews: {
        id: number;
        book_detail_id: number;
        review_id: number;
    }[];
    reviews: {
        id: number;
        rating: number;
        comment: string;
        author: string;
    }[];
    tags: {
        id: number;
        name: string;
    }[];
};
export default _default;
//# sourceMappingURL=data.d.ts.map