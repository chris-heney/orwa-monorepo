import * as React from 'react';
import { InputProps, RaRecord } from 'ra-core';
import { UseReferenceOneInputControllerOptions, UseReferenceOneInputControllerValue } from './useReferenceOneInputController';
/**
 * Use `<ReferenceOneInputBase>` in an `<Edit>` or `<Create>` view to edit one-to-one relationships,
 * e.g. to edit the details of a book in the book edition view.
 *
 * @example
 * import { EditBase, Form } from 'ra-core';
 * import { TextInput, NumberInput } from 'my-react-admin-ui-library';
 * import { ReferenceOneInputBase } from '@react-admin/ra-core-ee';
 *
 * const BookEdit = () => (
 *     <EditBase mutationMode="optimistic">
 *         <Form>
 *             <TextInput source="title" />
 *             <ReferenceOneInputBase reference="book_details" target="book_id">
 *                 <NumberInput source="year" />
 *                 <TextInput source="author" />
 *                 <TextInput source="country" />
 *                 <TextInput source="genre" />
 *                 <NumberInput source="pages" />
 *             </ReferenceOneInputBase>
 *         </Form>
 *     </EditBase>
 * );
 */
export declare const ReferenceOneInputBase: <RecordType extends RaRecord = any>({ children, loading, error, render, ...props }: ReferenceOneInputBaseProps<RecordType>) => import("react/jsx-runtime").JSX.Element;
export interface ReferenceOneInputBaseProps<RecordType extends RaRecord = any> extends UseReferenceOneInputControllerOptions<RecordType>, Omit<InputProps, 'source' | 'defaultValue' | 'helperText' | 'validate' | 'margin'> {
    children?: React.ReactNode;
    loading?: React.ReactNode;
    error?: React.ReactNode;
    render?: (props: UseReferenceOneInputControllerValue<RecordType>) => React.ReactElement;
}
//# sourceMappingURL=ReferenceOneInputBase.d.ts.map