export declare const ReferenceOneInputPrefix = "@@ra-one/";
//# sourceMappingURL=constants.d.ts.map