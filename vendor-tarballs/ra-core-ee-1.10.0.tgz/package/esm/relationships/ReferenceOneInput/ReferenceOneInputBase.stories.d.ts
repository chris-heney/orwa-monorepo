declare const _default: {
    title: string;
};
export default _default;
export declare const Basic: ({ dataProvider, sort, filter, }: any) => import("react/jsx-runtime").JSX.Element;
export declare const Loading: () => import("react/jsx-runtime").JSX.Element;
export declare const CreateReference: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const CreateRecord: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValue: ({ id }: {
    id?: number | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultValueCreate: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultI18n: () => import("react/jsx-runtime").JSX.Element;
export declare const FetchError: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const SaveError: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const WithRelationalInputs: () => import("react/jsx-runtime").JSX.Element;
export declare const Meta: ({ dataProvider, sort, filter, }: any) => import("react/jsx-runtime").JSX.Element;
export declare const CreateRecordMeta: ({ dataProvider }: any) => import("react/jsx-runtime").JSX.Element;
export declare const ServerSideValidation: ({ dataProvider, }: any) => import("react/jsx-runtime").JSX.Element;
export declare const SetValue: ({ dataProvider, sort, filter, }: any) => import("react/jsx-runtime").JSX.Element;
export declare const WithDelete: ({ dataProvider, sort, filter, }: any) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ReferenceOneInputBase.stories.d.ts.map