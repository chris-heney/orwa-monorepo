import { RaRelationshipsTranslationMessages } from './RaRelationshipsTranslationMessages';
export declare const raRelationshipsLanguageFrench: RaRelationshipsTranslationMessages;
//# sourceMappingURL=raRelationshipsLanguageFrench.d.ts.map