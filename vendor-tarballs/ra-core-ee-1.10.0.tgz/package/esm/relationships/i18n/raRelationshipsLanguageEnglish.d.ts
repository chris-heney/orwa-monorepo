import { RaRelationshipsTranslationMessages } from './RaRelationshipsTranslationMessages';
export declare const raRelationshipsLanguageEnglish: RaRelationshipsTranslationMessages;
//# sourceMappingURL=raRelationshipsLanguageEnglish.d.ts.map