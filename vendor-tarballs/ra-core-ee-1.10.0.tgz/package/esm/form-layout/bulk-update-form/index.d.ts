export * from './BulkUpdateFormBase';
//# sourceMappingURL=index.d.ts.map