import * as React from 'react';
import { type RaRecord, type UseBulkUpdateControllerParams } from 'ra-core';
export declare const BulkUpdateFormBase: <RecordType extends RaRecord = any, MutationOptionsError = unknown>(props: BulkUpdateFormBaseProps<RecordType, MutationOptionsError>) => import("react/jsx-runtime").JSX.Element;
export interface BulkUpdateFormBaseProps<RecordType extends RaRecord = any, MutationOptionsError = unknown> extends UseBulkUpdateControllerParams<RecordType, MutationOptionsError> {
    children: React.ReactNode;
}
//# sourceMappingURL=BulkUpdateFormBase.d.ts.map