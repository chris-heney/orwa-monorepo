import { DataProvider } from 'ra-core';
import { BulkUpdateFormBaseProps } from './BulkUpdateFormBase';
declare const _default: {
    title: string;
    excludeStories: string[];
};
export default _default;
export declare const Basic: {
    ({ mutationMode, meta, dataProvider: dataProviderProp, }: {
        mutationMode?: BulkUpdateFormBaseProps["mutationMode"];
        meta?: any;
        dataProvider?: DataProvider;
    }): import("react/jsx-runtime").JSX.Element;
    argTypes: {
        mutationMode: {
            options: (string | undefined)[];
            control: {
                type: string;
            };
        };
        meta: {
            control: string;
        };
    };
};
export declare const SlowProvider: {
    ({ mutationMode }: {
        mutationMode: any;
    }): import("react/jsx-runtime").JSX.Element;
    argTypes: {
        mutationMode: {
            options: (string | undefined)[];
            control: {
                type: string;
            };
        };
    };
};
export declare const Validation: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const OnSuccess: ({ dataProvider: dataProviderProp, }: {
    dataProvider?: DataProvider;
}) => import("react/jsx-runtime").JSX.Element;
export declare const dataProvider: DataProvider;
//# sourceMappingURL=BulkUpdateFormBase.stories.d.ts.map