import { type UseAutoPersistInStoreParams } from './useAutoPersistInStore';
export declare const AutoPersistInStoreBase: (props: UseAutoPersistInStoreParams) => null;
//# sourceMappingURL=AutoPersistInStoreBase.d.ts.map