import React from 'react';
import { type Identifier, type RaRecord, type ResourceContextValue } from 'ra-core';
export type AutoPersistInStoreStoreValue = {
    values: Record<string, unknown>;
    date: string;
};
export declare const useAutoPersistInStore: ({ notification, getStoreKey, maxAge, }: UseAutoPersistInStoreParams) => void;
export type UseAutoPersistInStoreParams = {
    getStoreKey?: (resource: ResourceContextValue, record: RaRecord<Identifier> | undefined) => string;
    maxAge?: number;
    notification: React.ReactNode;
};
//# sourceMappingURL=useAutoPersistInStore.d.ts.map