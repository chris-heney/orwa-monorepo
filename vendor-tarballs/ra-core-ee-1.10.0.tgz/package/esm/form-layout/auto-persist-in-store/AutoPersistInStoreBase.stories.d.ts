import { RedirectionSideEffect } from 'ra-core';
import { AutoPersistInStoreStoreValue } from './useAutoPersistInStore';
declare const _default: {
    title: string;
};
export default _default;
export declare const AutoPersistInStore: {
    ({ redirect, displayStore, customStoreKey, initialPage, hasStoredValue, initialStoreValue, delay, maxAge, }: {
        redirect?: RedirectionSideEffect;
        customStoreKey?: boolean;
        displayStore?: boolean;
        initialPage?: string;
        hasStoredValue?: boolean;
        initialStoreValue?: AutoPersistInStoreStoreValue | Record<string, unknown>;
        delay?: number;
        maxAge?: number;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        redirect: undefined;
        displayStore: boolean;
        customStoreKey: boolean;
        delay: number;
        initialPage: string;
        hasStoredValue: boolean;
    };
    argTypes: {
        redirect: {
            control: {
                type: string;
            };
            options: (string | undefined)[];
            mapping: {
                undefined: undefined;
                list: string;
                edit: string;
                'no redirect': boolean;
            };
        };
        initialPage: {
            control: {
                type: string;
            };
            options: string[];
            mapping: {
                list: string;
                edit: string;
            };
        };
        displayStore: {
            control: {
                type: string;
            };
        };
        customStoreKey: {
            control: {
                type: string;
            };
        };
        hasStoredValue: {
            control: {
                type: string;
            };
        };
        delay: {
            control: {
                type: string;
            };
        };
        maxAge: {
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=AutoPersistInStoreBase.stories.d.ts.map