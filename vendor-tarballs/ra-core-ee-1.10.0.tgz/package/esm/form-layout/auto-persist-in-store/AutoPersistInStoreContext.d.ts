import * as React from 'react';
import { UseFormReset } from 'react-hook-form';
export type AutoPersistInStoreContextValue = {
    reset: UseFormReset<Record<string, any>>;
};
export declare const AutoPersistInStoreContext: React.Context<AutoPersistInStoreContextValue | null>;
export declare const AutoPersistInStoreContextProvider: React.Provider<AutoPersistInStoreContextValue | null>;
//# sourceMappingURL=AutoPersistInStoreContext.d.ts.map