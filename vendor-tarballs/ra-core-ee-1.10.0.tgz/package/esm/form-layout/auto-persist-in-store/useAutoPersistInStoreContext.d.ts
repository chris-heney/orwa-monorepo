import { AutoPersistInStoreContextValue } from './AutoPersistInStoreContext';
export declare const useAutoPersistInStoreContext: () => AutoPersistInStoreContextValue;
//# sourceMappingURL=useAutoPersistInStoreContext.d.ts.map