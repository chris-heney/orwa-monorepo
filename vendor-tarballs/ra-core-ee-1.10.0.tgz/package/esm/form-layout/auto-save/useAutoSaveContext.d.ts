export declare const useAutoSaveContext: () => import("./AutoSaveContext").AutoSaveContextValue;
//# sourceMappingURL=useAutoSaveContext.d.ts.map