import * as React from 'react';
import { UseAutoSaveParams } from './useAutoSave';
/**
 * A component that enables autosaving of the form and displays the last save date.
 *
 * @param debounce The interval in milliseconds between two autosaves. Defaults to 5000 (5s).
 *
 * @example
 * import { AutoSaveBase } from '@react-admin/ra-core-ee';
 * import { EditBase, Form } from 'ra-core';
 * import { TextInput } from 'my-react-admin-ui-library';
 *
 * const PostEdit = () => (
 *     <EditBase mutationMode="optimistic">
 *         <Form resetOptions={{ keepDirtyValues: true }}>
 *             <TextInput source="title" />
 *             <TextInput source="teaser" />
 *             <button type="submit">Save</button>
 *             <AutoSaveBase
 *                 render={({ error, isSaving, lastSaveAt }) => {
 *                     if (error) {
 *                         return <span>Error: {error}</span>;
 *                     }
 *                     if (isSaving) {
 *                         return <span>Saving...</span>;
 *                     }
 *                     if (lastSaveAt) {
 *                         return (
 *                             <span>
 *                                 Last saved at{' '}
 *                                 {new Intl.DateTimeFormat(undefined, {
 *                                     hour: '2-digit',
 *                                     minute: '2-digit',
 *                                     second: '2-digit',
 *                                 }).format(new Date(lastSaveAt))}
 *                             </span>
 *                         );
 *                     }
 *                 }}
 *             />
 *         </Form>
 *     </EditBase>
 * );
 */
export declare const AutoSaveBase: ({ children, onSuccess, onError, render, ...props }: AutoSaveBaseProps) => string | number | boolean | Iterable<React.ReactNode> | import("react/jsx-runtime").JSX.Element | null | undefined;
export interface AutoSaveBaseProps extends UseAutoSaveParams {
    render?: (params: {
        isSaving: boolean;
        lastSaveAt: Date | null;
        error: string | null;
    }) => React.ReactNode;
    children?: React.ReactNode;
}
//# sourceMappingURL=AutoSaveBase.d.ts.map