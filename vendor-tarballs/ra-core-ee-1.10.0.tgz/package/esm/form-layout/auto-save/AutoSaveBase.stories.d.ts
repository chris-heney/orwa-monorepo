import { DataProvider, MutationMode } from 'ra-core';
declare const _default: {
    title: string;
};
export default _default;
export declare const InSimpleForm: {
    ({ dataProvider, debounce, mutationMode, }: {
        dataProvider?: any;
        debounce?: number;
        mutationMode?: MutationMode;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        mutationMode: string;
        debounce: number;
    };
    argTypes: {
        mutationMode: {
            options: string[];
            mapping: {
                optimistic: string;
                pessimistic: string;
                undoable: string;
            };
            control: {
                type: string;
            };
        };
        debounce: {
            control: {
                type: string;
            };
        };
    };
};
export declare const WithServerSideValidation: {
    ({ debounce, mutationMode, }: {
        debounce?: number;
        mutationMode?: MutationMode;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        mutationMode: string;
        debounce: number;
    };
    argTypes: {
        mutationMode: {
            options: string[];
            control: {
                type: string;
            };
        };
        debounce: {
            control: {
                type: string;
            };
        };
    };
};
export declare const SubmissionError: () => import("react/jsx-runtime").JSX.Element;
export declare const FullApp: {
    ({ shouldReject, dataProvider: dataProviderProp, debounce, disableWarnWhenUnsavedChanges, mutationMode, }: {
        dataProvider?: DataProvider;
        debounce: number;
        shouldReject?: boolean;
        disableWarnWhenUnsavedChanges?: boolean;
        mutationMode?: MutationMode;
    }): import("react/jsx-runtime").JSX.Element;
    args: {
        debounce: number;
        shouldReject: boolean;
        disableWarnWhenUnsavedChanges: boolean;
        mutationMode: string;
    };
    argTypes: {
        mutationMode: {
            options: string[];
            control: {
                type: string;
            };
        };
        debounce: {
            control: {
                type: string;
            };
        };
        shouldReject: {
            control: {
                type: string;
            };
        };
        disableWarnWhenUnsavedChanges: {
            control: {
                type: string;
            };
        };
    };
};
//# sourceMappingURL=AutoSaveBase.stories.d.ts.map