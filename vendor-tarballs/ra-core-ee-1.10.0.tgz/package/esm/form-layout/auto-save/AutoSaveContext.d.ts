import * as React from 'react';
export type AutoSaveContextValue = {
    isSaving: boolean;
    lastSaveAt: Date | null;
    error: string | null;
};
export declare const AutoSaveContext: React.Context<AutoSaveContextValue | null>;
export declare const AutoSaveContextProvider: React.Provider<AutoSaveContextValue | null>;
//# sourceMappingURL=AutoSaveContext.d.ts.map